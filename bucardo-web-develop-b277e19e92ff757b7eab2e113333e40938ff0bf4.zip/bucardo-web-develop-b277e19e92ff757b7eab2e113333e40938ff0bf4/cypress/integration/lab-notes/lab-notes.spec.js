import {TestTools} from '../test-tools';
import {LabNotesPage} from "./lab-notes.po";

const tools = new TestTools();
const po = new LabNotesPage(tools);

describe('Lab Notes', () => {

    const random = '' + Math.floor(Math.random() * 1000) + 1;

    beforeEach(() => {
        cy.server();
        cy.route('/LabNote/$perms').as('getPerms');
        cy.route('/Patient/*').as('getPatient');
        cy.route('/LabNote?patient=*').as('getLabNotes');
        cy.route('/Request?patient=*').as('getRequest');
        cy.route('/Doctor/*').as('getDoctor');
        cy.route('POST', '/Proc/$logEvent').as('logError');

        tools.navigateToWaiting();
    });

    describe('Typical patient', () => {

        beforeEach(() => {
            po.navToLabNotes();
            cy.wait(['@getPerms', '@getPatient', '@getLabNotes', '@getRequest']);
        });

        it('should navigate to url', () => {
            cy.contains('Lab Notes');
        });

        it('should add note successfully with button', () => {
            po.submitNoteText(random);

            po.firstNote.contains(random);
        });

        it('should add note successfully with hotkey', () => {
            po.noteInput.type(`Bob ${random} {ctrl}{enter}`);

            cy.wait('@getLabNotes');

            po.firstNote.contains(random);
        });


        it('should add notes in reverse chronological order', () => {
            po.submitNoteText('NoteA');
            po.submitNoteText('NoteB');

            po.firstNote.contains('NoteB');
            po.secondNote.contains('NoteA');
        });

        it('should cancel request entry if cancel button clicked', () => {
            po.noteInput.type(`Bob ${random}`);
            po.requestSearch.type('16-100437').wait(1000).type('{uparrow}{enter}');

            cy.wait('@getDoctor');
            po.cancelButton.click();
            cy.wait('@getPatient');
            po.requestSearch.should('have.value', '');
            po.requestDetails.should('have.value', '');
        });

        it('should add note successfully with a request ID assigned', () => {
            po.noteInput.type(`Bob ${random}`);
            po.requestSearch.type('16-100437').wait(1000).type('{uparrow}{enter}');
            po.submitButton.click();

            cy.wait('@getLabNotes');

            po.firstNoteRequestId.contains('16-100437');
            po.firstNote.contains(random);
        });

        it('should load a patient`s details successfully', () => {
            po.patientId.contains('1234567890');
        });

        it('should enable button if there is text in the note box', () => {
            po.noteInput.type('Bob');
            po.submitButton.should('not.be.disabled');
        });
    });

    describe('with request id that does not exist', () => {

        beforeEach(() => {
            po.navToLabNotes('boat', 'cats1122', '72', 'UNKNOWN_REQUEST');
        });

        it('should show a toast when an error message is received', () => {
            tools.errorToast.contains('UNKNOWN_REQUEST');
        });

    });

    describe('Request ID pre-populated', () => {

        beforeEach(() => {
            po.navToLabNotes('boat', 'cats1122', '72', '716');
            cy.wait(['@getPerms', '@getPatient', '@getLabNotes', '@getRequest', '@getDoctor']);
        });

        it('should load a patients`s notes successfully with request pre-populated', () => {
            po.patientId.contains('1234567890');
            po.requestSearch.should('have.value', '16-100437');
        });

        it('should show a request', () => {
            po.requestId.contains('16-100437');
        });

        it('should show a doctor', () => {
            po.doctor.contains('HAY, ALBERT');
        });

        it('should clear value of input for search box when request populated and search input gains focus', () => {
            po.requestSearch.click();
            po.requestSearch.should('have.value', '');
        });

    });

    describe('with patient who has no usual doctor', () => {

        beforeEach(() => {
            po.navToLabNotes('boat', 'cats1122', '118');
        });

        it('should not populate doctor details', () => {
            po.doctor.should("not.exist");
        });

    });

    describe('Special characters', () => {
        beforeEach(() => {
            po.navToLabNotes();
            cy.wait(['@getPerms', '@getPatient', '@getLabNotes', '@getRequest']);
        });

        it.skip('should add a note with a chinese character', () => {
            po.submitNoteText('灰');
            po.firstNote.contains('灰');
        });

        it('should add a note with JSON reserved characters', () => {
            po.submitNoteText('"hello": ["world"]}{');
            po.firstNote.contains('"hello": ["world"]}{');
        });

    });

    describe('Restricted access', () => {
        describe('View only permissions', () => {
            beforeEach(() => {
                po.navToLabNotes('permf', 'test1234');
                cy.wait(['@getPerms', '@getPatient', '@getLabNotes', '@getRequest']);
            });

            it('does not display add note form', () => {
                po.noteInput.should('not.exist');
                po.patientId.contains('1234567890');
            });
        });

        describe('No permissions for this page', () => {
            beforeEach(() => {
                po.navToLabNotes('permno', 'test1234');
                cy.wait(['@getPerms']);
            });

            it('does not display add note form or patient details', () => {
                po.noteInput.should('not.exist');
                po.patientId.should('not.exist');
            });
        });
    });

    describe('Switch between patients', () => {
        beforeEach(() => {
            po.navToLabNotes('boat', 'cats1122', '72');
            cy.wait(['@getPerms', '@getPatient', '@getLabNotes', '@getRequest']);
        });

        it('should switch to another patient', () => {
            po.switchToPatient('71');
            cy.wait(['@getPatient', '@getLabNotes', '@getRequest']);

            po.patientId.contains('1205604098'); // Changed from 1234567890
        });

    });

    describe('Network Failures', () => {

        function loadPatient72() {
            po.navToLabNotes('boat', 'cats1122', '72', '716');
            cy.wait(['@getPatient', '@getRequest', '@getDoctor']);
        }

        function shouldClearEverything() {
            po.firstNote.should('not.exist');
            po.patientId.should('not.exist');
            po.requestId.should('not.exist');
            po.doctor.should('not.exist');
        }

        describe('fail to get lab notes', () => {

            function loadPatient71() {
                po.switchToPatient('71', 'boat', '3822');
                cy.wait('@getLabNotesError');
            }

            beforeEach(() => {
                loadPatient72();

                // Stub the queryReport call to fail
                cy.route({
                    method: 'GET',
                    url: '/LabNote?patient=*',
                    response: '',
                    status: 500
                }).as('getLabNotesError');

                loadPatient71();
            });

            it('should show an error and log it', () => {
                tools.errorToast.should('be.visible');
                cy.wait('@logError');
            });

            it('should not show any patient / request / doctor / lab notes', () => {
                shouldClearEverything();
            });
        });

        describe('fail to get doctor record', () => {

            function loadPatient71() {
                po.switchToPatient('71', 'boat', '3822');
                cy.wait(['@getDoctorError']);
            }

            beforeEach(() => {
                loadPatient72();

                // Stub the queryReport call to fail
                cy.route({
                    method: 'GET',
                    url: '/Doctor/*',
                    response: '',
                    status: 500
                }).as('getDoctorError');

                loadPatient71();
            });

            it('should show an error and log it', () => {
                tools.errorToast.should('be.visible');
                cy.wait('@logError');
            });

            it('should not show any patient / request / doctor / lab notes', () => {
                shouldClearEverything();
            });
        });

        describe('fail to get patient record', () => {

            function loadPatient71() {
                po.switchToPatient('71', 'boat', '3822');
                cy.wait(['@getPatientError']);
            }

            beforeEach(() => {
                loadPatient72();

                // Stub the queryReport call to fail
                cy.route({
                    method: 'GET',
                    url: '/Patient/*',
                    response: '',
                    status: 500
                }).as('getPatientError');

                loadPatient71();
            });

            it('should show an error and log it', () => {
                tools.errorToast.should('be.visible');
                cy.wait('@logError');
            });

            it('should not show any patient / request / doctor / lab notes', () => {
                shouldClearEverything();
            });
        });
    });


});
