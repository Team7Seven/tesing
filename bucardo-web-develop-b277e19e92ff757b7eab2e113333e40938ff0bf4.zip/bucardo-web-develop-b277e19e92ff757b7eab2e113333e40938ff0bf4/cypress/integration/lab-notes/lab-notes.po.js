/** @type {TestTools} */
let tools;

export class LabNotesPage {

  constructor(testTools) {
    tools = testTools;
  }

  navToLabNotes(bid = 'boat', pass = 'cats1122', patient = '72', request = null) {
    tools.navigateToWaiting(bid, pass);
    this.switchToPatient(patient, bid, request);
  }

  switchToPatient(patient, bid = 'boat', request = null) {
    const body = {patient: patient};
    if (request) {
      body.request = request;
    }

    tools.navigateToPage('labnote', body, bid);
  }

  submitNoteText(text) {
    this.noteInput.type(text).wait(500);
    this.submitButton.click();
    cy.wait('@getLabNotes');
  }

  get noteInput() {
    return cy.get('#note-entry');
  }

  get submitButton() {
    return cy.get('#submit-note');
  }

  get firstNote() {
    return cy.get('div#note0');
  }

  get firstNoteRequestId() {
    return cy.get('#noteheader0>div>span.requestId');
  }

  get secondNote() {
    return cy.get('div#note1');
  }

  get requestSearch() {
    return cy.get('#search-box-input');
  }

  get patientId() {
    return cy.get('.display-heading-section');
  }

  get requestId() {
    return cy.get('.patient-request-doctor-panel-heading');
  }

  get requestDetails() {
    return cy.get('.request-details');
  }

  get doctor() {
    return cy.get('doctor-details-data');
  }

  get cancelButton() {
    return cy.get('#cancel-button');
  }

}
