export const KRILL_URL = process.env.TEST_KRILL_BASE || 'http://192.168.103.92:8686';
export const LABAPI_URL = process.env.TEST_LAB_API_BASE || 'http://192.168.103.92:8282';
export const SITE_URL = process.env.E2E_URL || 'http://192.168.103.92:9292';

export class TestTools {

    randomBid;

    constructor() {
        this.randomBid = this.randomStringOfLength(10);
    }

    sendKrillEvent(path, body, bid = 'boat') {
        cy.request(
            {
                method: 'POST',
                url: `${KRILL_URL}/${path}?bid=${bid}_${this.randomBid}`,
                headers: {
                    'Content-Type': 'plain/text'
                },
                body: body
            }).wait(500);
    }

    syncToken(token, bid) {
        cy.request(
            {
                method: 'POST',
                url: `${KRILL_URL}/login?bid=${bid}_${this.randomBid}`,
                headers: {
                    'Content-Type': 'plain/text'
                },
                body: {token: token}
            });
    }

    loginAs(bid, password) {
        this.authenticate(bid, password).wait(500).then((response) => {
            this.syncToken(response.body.token, bid);
        });

        cy.wait('@getUser');
        cy.contains(bid); // Waits until we see a username in the header
    }

    authenticate(username, password) {
        cy.log('Authenticating to: ', LABAPI_URL);
        return this.login(username, password).then((loginResponse) => loginResponse.token);
    }

    login(username, password) {
        const auth = new Buffer(`${username}:${password}`).toString('base64');

        return cy.request(
            {
                method: 'POST',
                url: `${LABAPI_URL}/User/$auth`,
                headers: {
                    'Authorization': 'Basic ' + auth,
                    'Content-Type': 'plain/text'
                },
                body: ''
            });
    }

    navigateToWaiting(bid = 'boat', password='cats1122') {
        cy.server();

        cy.route('/assets/config/preConfig.json').as('preconfig');
        cy.route('/Proc/$sysconfig').as('sysconfig');
        cy.route(`/User/${bid}`).as('getUser');
        cy.route(`${LABAPI_URL}/User/$auth`).as('authUser');

        cy.visit(`${SITE_URL}/?bid=${bid}_${this.randomBid}`);
        cy.wait(['@preconfig', '@sysconfig']);
        this.loginAs(bid, password);
    }

    navigateToPage(path, body, bid) {
        this.sendKrillEvent(path, body, bid);
    }

    makeId(prefix, size) {
        return prefix + this.randomStringOfLength(size - prefix.length);
    }

    randomStringOfLength(size) {
        let text = '';
        const possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

        for (let i = 0; i < size; i++) {
            text += possible.charAt(Math.floor(Math.random() * possible.length));
        }

        return text;
    }

    iFrameContains(text) {
        return cy.get('iframe')
            .then(function ($iframe) {
                return cy.wait(1000).then(() => { // Because we are doing something outside cy
                    expect($iframe.contents().find("body").html()).to.have.string(text);
                });

            });
    }

    iFrameDoesntContain(text) {
        return cy.get('iframe')
            .then(function ($iframe) {
                return cy.wait(1000).then(() => { // Because we are doing something outside cy
                    expect($iframe.contents().find("body").html()).not.to.have.string(text);
                });

            });
    }

    iFrameShouldBeEmpty() {
        return cy.get('iframe')
            .then(function ($iframe) {
                return cy.wait(1000).then(() => { // Because we are doing something outside cy
                    expect($iframe.contents().find("body").html().trim()).to.eq('');
                });

            });
    }

    iFrameShouldContainInitialValue() {
        return cy.get('iframe')
            .then(function ($iframe) {
                return cy.wait(1000).then(() => { // Because we are doing something outside cy
                    expect($iframe.contents().find("body").html().trim()).to.eq('<p><br></p>');
                });

            });
    }

    setIFrameContents(text) {
        return cy.get('iframe')
            .then(function ($iframe) {
                return cy.wait(1000).then(() => { // Because we are doing something outside cy
                    $iframe.contents().find("body").html(text);
                });

            }).wait(1000);
    }

    get errorToast() {
        return cy.get('.toast.toast-error');
    }

    get warningToast() {
        return cy.get('.toast.toast-warning');
    }

    get successToast() {
        return cy.get('.toast.toast-success');
    }

    get toast() {
        return cy.get('.toast');
    }
}