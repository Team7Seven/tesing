/** @type {TestTools} */
let tools;

export class TemplateEditorPage {

    constructor(testTools) {
        tools =  testTools;
    }

    navToTemplate(code, bid = 'boat') {
        tools.navigateToPage('template', 'where=' + JSON.stringify({code: code}), bid);
    }

    navToPage(bid = 'boat') {
        const body = '{"app": "gmaster","formname": "editor/template"}';
        tools.navigateToPage('menu', body, bid);

        cy.wait(['@getPerms', '@getClassList', '@getTemplateList']);
    }

    navToDefaultTemplateWithUser(bid) {
        tools.navigateToWaiting(bid, 'test1234');
        this.navToTemplate('E2ESINGLE', bid);

        cy.wait(['@getStyleList', '@getTemplateList', '@getTemplate', '@getClassList']);
    }

    clickNew() {
        this.newButton.click();
        this.code.should('have.value', '');
    }

    clickSave(isUpdate) {
        this.saveButton.click();

        if (isUpdate) {
            cy.wait('@updateTemplate');
        }else {
            cy.wait('@createTemplate');
        }

        cy.wait('@getTemplateList');
    }

    get newButton() {
        return cy.get('#newButton');
    }

    get saveButton() {
        return cy.get('#saveButton');
    }

    get editorControls() {
        return cy.get('editor-template-controls');
    }

    get htmlEditor() {
        return cy.get('html-editor');
    }

    get templateList() {
        return cy.get('#formatsTemplates');
    }

    get code() {
        return cy.get('#codeInput');
    }

    get name() {
        return cy.get('#nameInput');
    }

    get clazz() {
        return cy.get('#classInput');
    }

    get script() {
        return cy.get('#scriptInput');
    }

    get style() {
        cy.wait(1000);
        cy.get('#styleInput>option').should('not.be.empty');
        return cy.get('#styleInput');
    }

    get leftColumn() {
        return cy.get('#left-column');
    }

    get templateForm() {
        return cy.get('#template-form');
    }
}