import {TestTools} from '../test-tools';
import {ManagementReportsPage} from "./management-reports.po";


const tools = new TestTools();
const po = new ManagementReportsPage(tools);

describe('Management Reports', () => {

    beforeEach(() => {
        cy.server();
        cy.route('/MngRptTemplate/$perms').as('getPerms');
        cy.route('/MngRptTemplate?_summary=short').as('getLabReportsList');
        cy.route('POST', '/MngRptTemplate/$rptParams').as('getParams');
        cy.route('POST', '/MngRptTemplate/$rptRender').as('renderReport');
        cy.route('/MngRptTemplate/m*').as('getReport');
        cy.route('/MngRptTemplate/PAB*').as('getPorkAndBeans');
        cy.route('/MngRptTemplate/AGD1').as('getAgedDebtors');
        cy.route('POST', '/Proc/$logEvent').as('logError');
    });

    function loadReport(reportName, type = 'html') {
        po.reportFilter.clear().type(reportName);
        po.treeNodes.first().click();

        cy.wait('@getParams');

        if (type === 'html') {
            po.htmlButton.click({force: true});
        } else {
            po.pdfButton.click({force: true});
        }

        cy.wait('@renderReport');

        if (type === 'html') {
            tools.iFrameContains(reportName);
        } else {
            po.pdfSvgHolder.contains(reportName);
        }
    }

    describe('without permissions', () => {
        beforeEach(() => {
            po.navigateToReports('permno', 'test1234');
            cy.wait('@getPerms');
            cy.contains('Management Reports');
        });

        it('should not display anything on the page when the user has no permissions', () => {
            tools.warningToast.contains('You do not have permission to view this page');
        });
    });

    describe('with permissions', () => {
        beforeEach(() => {
            po.navigateToReports();
            cy.wait(['@getPerms', '@getLabReportsList']);
        });

        it('should show the list of reports', () => {
            po.reportTree.should('be.visible');
        });

        it('should filter reports correctly', () => {
            po.reportFilter.type('Beans');
            po.treeNodes.should('have.length', 2);
        });
    });

    describe('generating reports', () => {

        beforeEach(() => {
            po.navigateToReports();
            cy.wait(['@getPerms', '@getLabReportsList']);
        });

        it('should show the parameters to be entered when a report is selected', () => {
            po.reportFilter.type('Beans');
            po.treeNodes.first().click();
            cy.wait('@getParams');

            po.params.should('exist');
        });

        it('generate html button should be disabled when required parameters are missing', () => {
            po.reportFilter.type('manage 96');
            po.treeNodes.first().click();
            cy.wait('@getParams');

            po.htmlButton.should('be.disabled');
        });

        it('should display a report in the iframe when the report is successfully generated', () => {
            loadReport('Aged Debtors');
        });

        it('should display a pdf report the report is successfully generated using pdf button', () => {
            loadReport('Aged Debtors', 'pdf');
        });

        it('should be able to switch between reports', () => {
            loadReport('Aged Debtors');
            loadReport('Debtors Summary');
        });
    });

    describe('uploading report templates', () => {
        beforeEach(() => {
            po.navigateToReports();
            cy.wait(['@getPerms', '@getLabReportsList']);
        });

        it('should show the modal pop-up when upload button is clicked', () => {
            po.uploadButton.click();
            po.modalForm.should('be.visible');
        });

        it('should disable submit button if required fields are not populated', () => {
            po.uploadButton.click();
            po.reportUploadButton.should('be.disabled');
        });
    });


    describe('deleting report templates', () => {
        beforeEach(() => {
            cy.route({
                method: 'DELETE',
                url: 'MngRptTemplate/*',
                response: ''
            }).as('deleteReport');

            po.navigateToReports();
            cy.wait(['@getPerms', '@getLabReportsList']);
        });

        it('should disable the delete button until a report is clicked', () => {
            po.deleteButton.should('be.disabled');
        });

        it('should show the modal pop-up when delete button is clicked', () => {
            po.treeNodes.first().click();
            cy.wait('@getParams');

            po.deleteButton.click();
            po.modalForm.should('be.visible');
        });

        it('should be able to cancel the delete dialog by clicking outside', () => {
            po.treeNodes.first().click();
            cy.wait('@getParams');

            po.deleteButton.click();
            po.modalForm.should('be.visible');
            cy.get('body').click('topLeft');

            po.modalForm.should('not.be.visible');
        });

        it('should be able to cancel the delete dialog by clicking cancel', () => {
            po.treeNodes.first().click();
            cy.wait('@getParams');

            po.deleteButton.click();
            po.cancelButtonDelete.click();

            po.modalForm.should('not.be.visible');
        });

        it('should show a successful toast after deleting', () => {
            po.reportFilter.type('Beans');
            po.treeNodes.first().click();
            cy.wait('@getParams');

            po.deleteButton.click();

            cy.wait('@getPorkAndBeans');

            po.deleteConfirm.click();

            tools.successToast.contains('Successfully deleted');
        });

    });


    describe('updating report templates', () => {
        beforeEach(() => {
            cy.route({
                method: 'PUT',
                url: '/MngRptTemplate/*',
                response: ''
            }).as('updateReport');

            po.navigateToReports();
            cy.wait(['@getPerms', '@getLabReportsList']);
        });

        it('should disable the update button until a report is clicked', () => {
            po.updateButton.should('be.disabled');
        });

        it('should show the modal pop-up when update button is clicked', () => {
            po.treeNodes.first().click();
            cy.wait('@getParams');

            po.updateButton.click();
            po.modalForm.should('be.visible');
        });

        it('should be able to cancel the update dialog by clicking outside', () => {
            po.treeNodes.first().click();
            cy.wait('@getParams');

            po.updateButton.click();
            po.modalForm.should('be.visible');
            cy.get('body').click('topLeft');

            po.modalForm.should('not.be.visible');
        });

        it('should be able to cancel the update dialog by clicking cancel', () => {
            po.treeNodes.first().click();
            cy.wait('@getParams');

            po.updateButton.click();
            po.cancelButtonUpdate.click();

            po.modalForm.should('not.be.visible');
        });

        it('should show a successful toast after updating', () => {
            po.reportFilter.type('Aged Debtors');
            po.treeNodes.first().click();
            cy.wait('@getParams');

            po.updateButton.click();
            po.updateConfirm.click();

            cy.wait('@updateReport');

            tools.successToast.contains('Successfully updated');
        });

        it('should not allow update of name to use special characters', () => {
            po.reportFilter.type('Aged Debtors');
            po.treeNodes.first().click();
            cy.wait('@getParams');

            po.updateButton.click();

            cy.wait('@getAgedDebtors');
            po.modalForm.should('be.visible');

            po.reportName.clear().type('!"£$');
            po.updateConfirm.click();

            tools.warningToast.contains('invalid character detected');
        });

    });

    describe('Network Failures', () => {

        describe('fail to get list of reports', () => {

            beforeEach(() => {
                cy.route({
                    method: 'GET',
                    url: '/MngRptTemplate?_summary=short',
                    response: '',
                    status: 500
                }).as('getLabReportsListError');


                po.navigateToReports();

                cy.wait('@getLabReportsListError');
            });

            it('should show an error', () => {
                tools.errorToast.should('be.visible');
                cy.wait('@logError');
            });

            it('should not show parameters list', () => {
                po.params.should('not.be.visible');
            });
        });


        describe('List of reports loaded', () => {
            beforeEach(() => {
                po.navigateToReports();
                cy.wait(['@getPerms', '@getLabReportsList']);
                loadReport('Aged Debtors');
            });

            describe('fail to get report parameters', () => {

                beforeEach(() => {
                    cy.route({
                        method: 'POST',
                        url: '/MngRptTemplate/$rptParams',
                        response: '',
                        status: 500
                    }).as('getParamsError');


                    po.reportFilter.clear().type('Debtors Summary');
                    po.treeNodes.first().click();

                    cy.wait('@getParamsError');
                });

                it('should show an error', () => {
                    tools.errorToast.should('be.visible');
                    cy.wait('@logError');
                });

                it('should not show parameters list', () => {
                    po.params.should('not.be.visible');
                });

                it('should clear the filter text', () => {
                    po.reportFilter.should('have.value', '');
                });
            });

            describe('Render failures', () => {

                beforeEach(() => {
                    cy.route({
                        method: 'POST',
                        url: '/MngRptTemplate/$rptRender',
                        response: '',
                        status: 500
                    }).as('renderReportError');

                    po.reportFilter.clear().type('Debtors Summary');
                    po.treeNodes.first().click();
                    cy.wait('@getParams');
                });

                describe('fail to render html report', () => {

                    beforeEach(() => {
                        po.htmlButton.click({force: true});
                        cy.wait('@renderReportError');
                    });

                    it('should show and report an error', () => {
                        tools.errorToast.should('be.visible');
                        cy.wait('@logError');
                        po.loadingSpinner.should('not.be.visible');
                        po.pdfSvgHolder.should('not.be.visible');
                        po.iFrame.should('not.be.visible');
                    });

                    it('should enable buttons again after failure', () => {
                        po.htmlButton.should('be.enabled');
                        po.xlsButton.should('be.enabled');
                        po.pdfButton.should('be.enabled');
                    });
                });

                describe('fail to render pdf report', () => {

                    beforeEach(() => {
                        po.pdfButton.click({force: true});
                        cy.wait('@renderReportError');
                    });

                    it('should show and report an error', () => {
                        tools.errorToast.should('be.visible');
                        cy.wait('@logError');
                        po.loadingSpinner.should('not.be.visible');
                    });

                    it('should enable buttons again after failure', () => {
                        po.htmlButton.should('be.enabled');
                        po.xlsButton.should('be.enabled');
                        po.pdfButton.should('be.enabled');
                    });
                });

                describe('fail to render xls report', () => {

                    beforeEach(() => {
                        po.xlsButton.click({force: true});
                        cy.wait('@renderReportError');
                    });

                    it('should show and report an error', () => {
                        tools.errorToast.should('be.visible');
                        cy.wait('@logError');
                        po.loadingSpinner.should('not.be.visible');
                        po.pdfSvgHolder.should('not.be.visible');
                        po.iFrame.should('not.be.visible');
                    });

                    it('should enable buttons again after failure', () => {
                        po.htmlButton.should('be.enabled');
                        po.xlsButton.should('be.enabled');
                        po.pdfButton.should('be.enabled');
                    });
                });
            });


        });



    });


});