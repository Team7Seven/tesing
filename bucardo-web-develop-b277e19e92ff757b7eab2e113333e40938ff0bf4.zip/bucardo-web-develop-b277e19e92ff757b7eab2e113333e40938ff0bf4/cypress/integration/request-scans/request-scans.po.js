import {TestTools} from "../test-tools";

/** @type {TestTools} */
let tools;

export class RequestScansPage {

    constructor(testTools) {
        tools = testTools;
    }

    loadScanPage(bid = 'boat') {
        tools.navigateToPage('menu', JSON.stringify({
            app: 'gmaster',
            formname: 'request-scans'
        }), bid);
    }

    loadScanPageWithRequest(request, bid = 'boat') {
        tools.navigateToPage('document', JSON.stringify({request: request}), bid);
    }

    searchForRequest(requestId) {
        this.searchBox.clear();
        this.searchBox.type(`${requestId}{enter}`);

        cy.wait('@getRequest');
    }

    get searchBox() {
        return cy.get('.doc-lists input');
    }

    get patientNumber() {
        return cy.get('.display-heading-section');
    }

    waitForPatientRoute() {
        cy.wait('@getPatient');
    }

    get assignedDocs() {
        return cy.get('#assignedDocuments ul>li');
    }

    get unassignedDocs() {
        return cy.get('#unassignedDocuments ul>li');
    }

    get allUnassignedDocs() {
        return cy.get('#unassignedDocuments ul>li');
    }

    get firstUnassignedDocument() {
        return this.allUnassignedDocs.first();
    }

    get lastAssignedDoc() {
        return cy.get('#assignedDocuments ul>li').last();
    }

    get lastUnassignedDoc() {
        return cy.get('#unassignedDocuments ul>li').last();
    }

    get unassignButton() {
        return cy.get('#unassignButton');
    }

    get assignButton() {
        return cy.get('#assignButton');
    }

    get deleteButton() {
        return cy.get('#deleteButton');
    }

    get scanElement() {
        return cy.get('svg');
    }

    get requestName() {
        return cy.get('.request-details .patient-request-doctor-panel-heading');
    }

    get deleteDialog() {
        return cy.get('.modal-dialog');
    }

    get patientDetails() {
        return cy.get('#patient-details');
    }

    get doctorDetails() {
        return cy.get('doctor-details-data');
    }

    get requestDetails() {
        return cy.get('#request-details');
    }
}
