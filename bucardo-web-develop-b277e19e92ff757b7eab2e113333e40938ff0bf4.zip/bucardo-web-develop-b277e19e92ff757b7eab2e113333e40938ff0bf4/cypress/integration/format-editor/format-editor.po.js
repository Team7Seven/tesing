
/** @type {TestTools} */
let tools;

export class FormatEditorPage {

    constructor(testTools) {
        tools =  testTools;
    }

    navToFormat(code, lab = 'INV', key = '1', bid = 'boat', waitForFormatToLoad = true) {
        tools.navigateToPage('formats', 'where=' + JSON.stringify({
            'code': code,
            'lab': lab,
            'key_num': key
        }), bid);

        cy.contains('Lab Format Editor');

        if (waitForFormatToLoad) { // We want to skip this if user has no perms
            cy.wait('@getFormat');
            cy.wait('@getStyleList');
        } else {
            cy.wait('@getPerms');
        }
    }

    loadDefaultFormatAsUser(user, waitForFormatToLoad) {
        tools.navigateToWaiting(user, 'test1234');
        this.navToFormat('24COR', 'INV', '1', user, waitForFormatToLoad);
    }

    selectStyle(style) {
        cy.wait(2000);
        this.styles.should('have.length.above', 1);
        this.templateStyle.select(style);
        cy.wait('@getClasses');
        this.classes.should('have.length.above', 1);
        this.templateCode.should('not.be.disabled');
    }

    get cancelButton() {
      return cy.get('#cancel-button');
    }

    get formatCode() {
        return cy.get('#formatCode');
    }

    get formatName() {
        return cy.get('#formatName');
    }

    get formatProcessUsing() {
        return cy.get('#formatProcessUsing');
    }

    get templateStyle() {
        return cy.get('#templateStyle');
    }

    get styles() {
        return cy.get('#templateStyle option');
    }

    get classes() {
        return cy.get('#templateCode option', {timeout: 15000});
    }

    get templateCode() {
        return cy.get('#templateCode');
    }

    get loadInEditor() {
        return cy.get('#loadInEditor');
    }

    get items() {
        return cy.get('#items');
    }

    get generateFormat() {
        return cy.get('#generateFormat');
    }

    get formatForm() {
        return cy.get('editor-format-controls');
    }

    formInputsShouldBeVisible() {
        return cy.get('editor-format-controls input').should('have.length.above', 1); // Not just the search box;
    }

    formInputsShouldNotBeVisible() {
        return cy.get('editor-format-controls input').should('have.length', 1); // Just the search box
    }

    get htmlEditor() {
        return cy.get('html-editor');
    }

    get saveButton() {
        return cy.get('#saveButton');
    }
}
