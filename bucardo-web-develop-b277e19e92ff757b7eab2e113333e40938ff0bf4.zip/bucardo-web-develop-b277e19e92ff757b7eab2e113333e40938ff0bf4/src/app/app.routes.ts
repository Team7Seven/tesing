import {Routes} from '@angular/router';

import {HomeRoute} from './+home/home.routes';
import {LoginRoute} from './+login/login.routes';
import {ManagementReportRoute} from './+management-report/management-report.routes';

const DefaultRoute = {
  path: '**', redirectTo: '/'
};

export const routes: Routes = [
  HomeRoute,
  LoginRoute,
  DefaultRoute
];
