import {Route} from '@angular/router';
import {CumulativeReportsComponent} from './cumulative-reports.component';

export const CumulativeReportsRoutes: Route = {
  path: '',
  component: CumulativeReportsComponent
};
