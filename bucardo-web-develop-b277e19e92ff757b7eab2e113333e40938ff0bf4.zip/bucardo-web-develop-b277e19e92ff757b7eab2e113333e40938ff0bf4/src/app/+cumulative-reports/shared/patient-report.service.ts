import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {ConfigurationService} from '../../shared/services/configuration/configuration.service';
import {ApiClient} from '../../shared/services/api-client/api-client';

@Injectable()
export class PatientReportService {

  private baseUrl;

  constructor(private apiClient: ApiClient, private config: ConfigurationService) {
    this.baseUrl = config.getConfig().labapi_url;
  }

  getReport(payload: any): Observable<any> {
    return this.apiClient.postAndExpectText(`${this.baseUrl}/PatientReport/$queryReport`, payload);
  }

  getPermissions() {
    return this.apiClient.get(`${this.baseUrl}/PatientReport/$perms`);
  }

}
