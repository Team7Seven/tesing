import {Component, ElementRef, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {Subscription} from 'rxjs/Subscription';
import {PatientReportService} from './shared/patient-report.service';
import {PayloadDataService} from '../shared/services/payload-data/payload-data.service';
import {NavbarDataService} from '../shared/components/navigation/navbar/navbar-data-service';
import {ToasterService} from 'angular2-toaster';
import {PatientRequestDoctorHelper} from '../shared/component-helpers/patient-request-doctor.helper';

@Component({
  selector: 'cumulative-reports',
  templateUrl: './cumulative-reports.component.html',
  styleUrls: ['./cumulative-reports.component.scss'],
  providers: [PatientReportService]
})

export class CumulativeReportsComponent implements OnInit, OnDestroy {

  permissions: any = {};
  reportSub: Subscription;

  private payloadDataSubscription: Subscription;
  @ViewChild('contentFrame') contentFrame: ElementRef;

  constructor(private payloadDataService: PayloadDataService,
              private patientReportService: PatientReportService,
              public patientRequestDoctorHelper: PatientRequestDoctorHelper,
              private toastService: ToasterService,
              private navbarService: NavbarDataService) {
    navbarService.setPage('Patient Reports');
  }

  ngOnInit() {
    this.patientRequestDoctorHelper.resetObservables();
    this.patientRequestDoctorHelper.networkError.subscribe(() => this.onNetworkError());

    this.payloadDataSubscription = this.payloadDataService.payloadData.subscribe(data => {
      if (data && data.event === 'showpatreport') {
        this.patientReportService.getPermissions().subscribe(
          (permissions) => {
            this.permissions = permissions;
            if (this.permissions.find) {
              this.fetchReport(data.payload);
              this.patientRequestDoctorHelper.fetchPatientRequestDoctorFromRequestId(data.payload.request);
            } else {
              this.toastService.pop('warning', 'You do not have permission to view this page.');
            }
          }
        );
      }
    });
  }

  private onNetworkError() {
    if (this.reportSub) {
      this.reportSub.unsubscribe();
    }

    this.setReportHtml('');
  }

  private fetchReport(reportPayload) {
    this.reportSub = this.patientReportService.getReport(reportPayload).subscribe(
      reportContents => this.setReportHtml(reportContents),
      error => {
        this.patientRequestDoctorHelper.resetObservables();
        this.setReportHtml('');

        throw error;
      }
    );
  }

  private setReportHtml(contents) {
    if (this.contentFrame) {
      const newDoc = this.contentFrame.nativeElement.contentWindow.document.open('text/html', 'replace');
      newDoc.write(contents);
      newDoc.close();
    }
  }

  ngOnDestroy() {
    this.payloadDataSubscription.unsubscribe();
  }

}
