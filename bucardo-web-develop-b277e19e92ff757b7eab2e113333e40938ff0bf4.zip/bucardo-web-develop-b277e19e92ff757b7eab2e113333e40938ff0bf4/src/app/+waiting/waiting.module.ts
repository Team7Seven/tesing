import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {RouterModule} from '@angular/router';
import {WaitingRoute} from './waiting.routes';
import {SharedModule} from '../shared/shared.module';
import {WaitingComponent} from './waiting.component';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    RouterModule.forChild([WaitingRoute])
  ],
  declarations: [WaitingComponent]
})
export class WaitingModule {
}
