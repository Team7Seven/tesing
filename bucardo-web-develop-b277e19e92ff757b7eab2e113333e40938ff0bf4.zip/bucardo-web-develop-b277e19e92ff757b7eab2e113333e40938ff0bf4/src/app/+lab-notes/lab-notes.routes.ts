import {Route} from '@angular/router';
import {LabNotesComponent} from './lab-notes.component';

export const LabNotesRoute: Route = {
  path: '',
  component: LabNotesComponent
};
