import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {LabNotesComponent} from './lab-notes.component';
import {RouterModule} from '@angular/router';
import {LabNotesRoute} from './lab-notes.routes';
import {NoteFormComponent} from './note-form/note-form.component';
import {ReactiveFormsModule, FormsModule} from '@angular/forms';
import {NotePanelComponent} from './note-panel/note-panel.component';
import {SharedModule} from '../shared/shared.module';
import {SelectModule} from 'ng2-select';

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    SharedModule,
    SelectModule,
    RouterModule.forChild([LabNotesRoute]),
    FormsModule
  ],
  declarations: [LabNotesComponent,
    NoteFormComponent, NotePanelComponent]
})
export class LabNotesModule {
}
