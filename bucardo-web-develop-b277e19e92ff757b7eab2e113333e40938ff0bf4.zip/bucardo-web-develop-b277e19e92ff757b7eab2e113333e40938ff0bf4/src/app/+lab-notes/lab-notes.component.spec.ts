/* tslint:disable:no-unused-variable */
import {fakeAsync} from '@angular/core/testing';
import {LabNotesComponent} from './lab-notes.component';
import {Observable} from 'rxjs/Observable';
import {LabNoteModel} from './shared/models/lab-note.model';
import {PatientDetailsModel} from '../shared/components/patient-details/patient-details.model';
import {DoctorDetailsModel} from '../shared/components/doctor-details/doctor-details.model';
import {Subject} from 'rxjs/Subject';
import createSpy = jasmine.createSpy;

describe('LabNotesComponent', () => {
  const PATIENT_ID = '1234';
  const REQUEST_ID = 'REQ_ID';

  let component: LabNotesComponent;
  let serviceMock: LabNotesServiceMock;
  let payloadServiceMock: PayloadServiceMock;
  let navbarServiceMock: NavbarDataServiceMock;
  let toastServiceMock: ToasterServiceMock;
  let patientRequestDoctorHelperMock: PatientRequestDoctorHelperMock;
  let subscriptionMock: SubscriptionMock;

  const ERROR_MSG = 'An Error';
  const validNote: LabNoteModel = {noteText: 'This is a note'};
  const validPatient: PatientDetailsModel = {
    usual_doc: 'usual_doc',
    ri: '1234',
    surname: 'Bobertson',
    given_name: 'Bob',
    title: 'Mr.',
    sex: 'M',
    gender: 'Male',
    account_type: 'P',
    dob: '',
    mrn: []
  };

  const validDoctor: DoctorDetailsModel = {
    code: 'H8221',
    key_num: '1',
    num: '4408664',
    extended_code: 'H8221',
    status: ' ',
    title: 'DR',
    surname: 'FRASER (SOUTH)',
    given_name: 'JAMES',
    middle_name: 'HAMISH',
    address_1: '43 SOUTHSIDE ROAD',
    address_2: '',
    address_3: '',
    city: 'INVERNESS',
    state: '',
    postcode: 'IV2 4XA',
    area: 'SE',
    telephone: '01463 710222',
    coln_centre: 'H5587',
    home_phone: '01463 710222',
  };

  /** Mock Services **/
  class LabNotesServiceMock {
    createNote: Function;
    getNotesForPatient = createSpy('getNotesForPatient').and.returnValue(Observable.of([]));
    getRequestsForPatient = createSpy('getRequestsForPatient').and.returnValue(Observable.of([]));
    getPermissions = createSpy('getPermissions').and.returnValue(Observable.of({find: true, add: true}));
  }

  class PayloadServiceMock {
    payloadData: Observable<any> = Observable.of({event: 'labNote', payload: {patient: PATIENT_ID}});
  }

  class NavbarDataServiceMock {
    setPage = createSpy('setPage');
  }

  class ToasterServiceMock {
    pop = createSpy('pop');
  }

  class PatientRequestDoctorHelperMock {
    networkError = new Subject();
    resetObservables = createSpy('resetObservables');
    fetchPatientRequestDoctorFromRequestId = createSpy('fetchPatientRequestDoctorFromRequestId');
    fetchPatientDetails = createSpy('fetchPatientDetails');
  }

  class SubscriptionMock {
    unsubscribe = createSpy('unsub');
  }

  beforeEach(() => {
    serviceMock = new LabNotesServiceMock();
    payloadServiceMock = new PayloadServiceMock();
    navbarServiceMock = new NavbarDataServiceMock();
    toastServiceMock = new ToasterServiceMock();
    patientRequestDoctorHelperMock = new PatientRequestDoctorHelperMock();
    subscriptionMock = new SubscriptionMock();

    component = new LabNotesComponent(
      <any> serviceMock,
      <any> payloadServiceMock,
      <any> patientRequestDoctorHelperMock,
      <any> navbarServiceMock,
      <any> toastServiceMock);

    spyOn(payloadServiceMock.payloadData, 'subscribe').and.callThrough();
    jasmine.createSpy('getNotesForPatient').and.returnValue(Observable.of([]));

  });


  it('should create successfully', () => {
    expect(component).toBeTruthy();
  });

  it('should subscribe to payload data on initialisation', fakeAsync(() => {
    component.ngOnInit();
    expect(payloadServiceMock.payloadData.subscribe).toHaveBeenCalled();
  }));

  describe('Creating Notes', () => {

    describe('Creating Notes Successfully', () => {

      beforeEach(() => {
        serviceMock.createNote = jasmine.createSpy('createNote').and.callFake((note) => Observable.of(note));

        component.permissions = {add: true, find: true};
        component.patientId = PATIENT_ID;

      });

      it('should call the service when creating a note', () => {
        component.onNoteAdded(validNote);
        expect(serviceMock.createNote).toHaveBeenCalledWith(validNote, PATIENT_ID);
      });

      it('should refresh the list of notes from the server', () => {
        component.onNoteAdded(validNote);
        expect(serviceMock.getNotesForPatient).toHaveBeenCalledWith(PATIENT_ID);
      });

    });

    describe('error on service call', () => {

      beforeEach(() => {
        serviceMock.createNote = jasmine.createSpy('createNote').and.returnValue(Observable.throw(ERROR_MSG));
        spyOn(console, 'error'); // avoids error text in the test report
        component.permissions = {add: true, find: true};
        component.patientId = PATIENT_ID;
        // recreateComponent();
      });

      it('should throw an exception', () => {
        try {
          component.onNoteAdded(validNote);
          fail('Exception expected');
        } catch (e) {
          expect(e).toEqual(ERROR_MSG);
        }

      });

    });

  });

  describe('Getting patient/doctor/request details', () => {

    it('should call the API to get patient details on init with null if no request supplied', () => {
      payloadServiceMock.payloadData = Observable.of({event: 'labNote', payload: {patient: PATIENT_ID}});
      component.ngOnInit();
      expect(patientRequestDoctorHelperMock.fetchPatientDetails).toHaveBeenCalledWith(PATIENT_ID);
    });

    it('should call the API to get patient / doctor / request details on init with supplied REQUEST_ID', () => {
      payloadServiceMock.payloadData = Observable.of({
        event: 'labNote',
        payload: {patient: PATIENT_ID, request: REQUEST_ID}
      });
      component.ngOnInit();
      expect(patientRequestDoctorHelperMock.fetchPatientRequestDoctorFromRequestId).toHaveBeenCalledWith(REQUEST_ID);
    });

    describe('when there is an error on service call', () => {

      it('should pass on exception', () => {
        serviceMock.getNotesForPatient = jasmine.createSpy('getNotesForPatient').and.returnValue(Observable.throw(ERROR_MSG));

        try {
          component.ngOnInit();
          fail('should not get here');
        } catch (e) {
          expect(e).toEqual(ERROR_MSG);
        }
      });

    });

  });

  describe('Getting patient notes', () => {

    it('should call the API to get patient notes on init', () => {
      component.ngOnInit();
      expect(serviceMock.getNotesForPatient).toHaveBeenCalledWith(PATIENT_ID);
    });

    describe('when there is an error on service call', () => {

      it('should pass on exception', () => {
        serviceMock.getNotesForPatient = jasmine.createSpy('getNotesForPatient').and.returnValue(Observable.throw(ERROR_MSG));

        try {
          component.ngOnInit();
          fail('should not get here');
        } catch (e) {
          expect(e).toEqual(ERROR_MSG);
        }
      });

    });

  });


  describe('Getting requests for patient', () => {

    beforeEach(() => {
      component.ngOnInit();
    });

    it('should call the API to get patient notes on init', () => {
      expect(serviceMock.getRequestsForPatient).toHaveBeenCalledWith(PATIENT_ID);
    });

  });
  describe('On shutdown', () => {

    beforeEach(() => {
      component.ngOnInit();
    });

    it('should unsubscribe from params subscription', () => {
      spyOn(component.payloadDataSubscription, 'unsubscribe');
      component.ngOnDestroy();
      expect(component.payloadDataSubscription.unsubscribe).toHaveBeenCalled();
    });

  });

  describe('with no permissions', () => {
    beforeEach(() => {
      serviceMock.getPermissions = jasmine.createSpy('getPermissions').and.returnValue(Observable.of({}));
      serviceMock.getNotesForPatient = jasmine.createSpy('getNotesForPatient');
      component.ngOnInit();
    });

    it('does not make calls to any other services on initialization', () => {
      expect(serviceMock.getPermissions).toHaveBeenCalled();
      expect(serviceMock.getRequestsForPatient).not.toHaveBeenCalled();
      expect(serviceMock.getNotesForPatient).not.toHaveBeenCalled();
      expect(toastServiceMock.pop).toHaveBeenCalledWith('warning', 'You do not have permission to view this page');
    });
  });

  describe('with only \'find\' permissions', () => {
    beforeEach(() => {
      serviceMock.getPermissions = jasmine.createSpy('getPermissions').and.returnValue(Observable.of({find: true}));
      serviceMock.getNotesForPatient = jasmine.createSpy('getNotesForPatient').and.returnValue(Observable.of([]));
      serviceMock.createNote = jasmine.createSpy('createNote').and.callFake((note) => Observable.of(note));
      component.ngOnInit();
    });

    it('does not make a create note call to have been made', () => {
      const validNote1: LabNoteModel = {noteText: 'This is the first note'};
      component.onNoteAdded(validNote1);
      expect(serviceMock.createNote).not.toHaveBeenCalled();
      expect(component.notes[0]).not.toBe(validNote1);
    });

    it('makes calls to other services as normal on initialization', () => {
      expect(serviceMock.getPermissions).toHaveBeenCalled();
      expect(serviceMock.getRequestsForPatient).toHaveBeenCalled();
      expect(serviceMock.getNotesForPatient).toHaveBeenCalled();
      expect(patientRequestDoctorHelperMock.fetchPatientDetails).toHaveBeenCalled();
      expect(toastServiceMock.pop).not.toHaveBeenCalled();
    });
  });

  describe('with only \'add\' permissions', () => {
    beforeEach(() => {
      serviceMock.getPermissions = jasmine.createSpy('getPermissions').and.returnValue(Observable.of({}));
      serviceMock.getNotesForPatient = jasmine.createSpy('getNotesForPatient');
      component.ngOnInit();
    });

    it('does not make calls to any other services on initialization', () => {
      expect(serviceMock.getPermissions).toHaveBeenCalled();
      expect(serviceMock.getRequestsForPatient).not.toHaveBeenCalled();
      expect(serviceMock.getNotesForPatient).not.toHaveBeenCalled();
      expect(patientRequestDoctorHelperMock.fetchPatientRequestDoctorFromRequestId).not.toHaveBeenCalled();
      expect(toastServiceMock.pop).toHaveBeenCalledWith('warning', 'You do not have permission to view this page');
    });
  });

});
