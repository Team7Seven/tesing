import {Component, Input, OnChanges, SimpleChanges, OnInit, NgZone} from '@angular/core';
import {LabNoteModel} from '../shared/models/lab-note.model';
import * as moment from 'moment';

@Component({
  selector: 'note-panel',
  template: `

    <div class="container">
      <div class="row">
        <div class="col-xs-12">
          <div class="panel panel-default" [class]="evenOrOdd">
            <div [id]="'noteheader' + index" class="panel-heading">
              <span class="small-text pull-right">{{ formattedDate }}</span>
              <span class="note-user">
                {{note.username}}
                 <span *ngIf="note.userId" class="small-text">
                  ({{note.userId}})
                </span>
              </span>
              <span class="small-text" [title]="formattedDate">
                 {{relativeDate}}
              </span>
              <div *ngIf="note.requestId" class="small-text">
                <span class="requestId">{{note.requestId}}</span>
              </div>
            </div>
            <div [id]="'note' + index">
              <pre>{{note.noteText}}</pre>
            </div>
          </div>
        </div>
      </div>
    </div>`,

  styles: [
    '.small-text { font-size: 0.9em }',
    '.note-user { font-size: 1.1em; font-weight: bold;}',
      `pre {
      background-color: transparent;
      border: none;
      white-space: pre-wrap;
      white-space: -moz-pre-wrap;
      white-space: -o-pre-wrap;
      word-wrap: break-word;
    }

    .panel-heading {
      padding-bottom: 5px;
    }

    .even {
      background-color: white;
    }

    .odd {
      background-color: #f6f6f6;
    }
    `,
      `.panel {
      margin-bottom: 0;
      box-shadow: none;
      border: none;
    }`,
    '.requestId { font-style: italic }'
  ]
})
export class NotePanelComponent implements OnInit, OnChanges {
  @Input() note: LabNoteModel;
  @Input() index: number;

  formattedDate: string;
  relativeDate: string;
  evenOrOdd = 'even';

  constructor(private _ngZone: NgZone) {

  }

  ngOnInit() {
    this.repeatedlyUpdateRelativeTime();
    this.evenOrOdd = (this.index % 2) ? 'odd' : 'even';
  }

  private repeatedlyUpdateRelativeTime() {
    this.updateRelativeTime();

    this._ngZone.runOutsideAngular(() => {
      setInterval(() => {
        this._ngZone.run(() => this.updateRelativeTime());
      }, 10000);
    });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if ('note' in changes) {
      this.setFormattedDate();
      this.updateRelativeTime();
    }
  }

  private setFormattedDate() {
    this.formattedDate = moment(this.note.timestamp).format('L LTS');
  }

  private updateRelativeTime() {
    if (this.note && this.note.timestamp) {
      this.relativeDate = moment(this.note.timestamp).fromNow();
    }
  }
}
