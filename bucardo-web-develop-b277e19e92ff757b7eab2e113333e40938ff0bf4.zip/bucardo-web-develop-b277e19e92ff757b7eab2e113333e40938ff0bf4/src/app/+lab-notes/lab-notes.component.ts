import {Component, OnDestroy, OnInit} from '@angular/core';
import {LabNotesService} from './shared/lab-notes.service';
import {LabNoteModel} from './shared/models/lab-note.model';
import {PayloadDataService} from '../shared/services/payload-data/payload-data.service';
import {NavbarDataService} from '../shared/components/navigation/navbar/navbar-data-service';
import {ToasterService} from 'angular2-toaster';
import {PatientRequestDoctorHelper} from '../shared/component-helpers/patient-request-doctor.helper';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {Subscription} from 'rxjs/Subscription';

@Component({
  selector: 'lab-notes',
  templateUrl: 'lab-notes.component.html',
  styleUrls: ['lab-notes.component.scss'],
  providers: [LabNotesService]
})
export class LabNotesComponent implements OnInit, OnDestroy {

  payloadDataSubscription: any;
  notes: Array<LabNoteModel> = [];
  requests = new BehaviorSubject<Array<any>>([]);
  patientId: string;
  permissions: any = {};
  notesSub: Subscription;

  constructor(private service: LabNotesService,
              private payloadDataService: PayloadDataService,
              public patientRequestDoctorHelper: PatientRequestDoctorHelper,
              private navbarService: NavbarDataService,
              private toasterService: ToasterService) {
    navbarService.setPage('Lab Notes');
  }

  ngOnInit() {
    this.patientRequestDoctorHelper.resetObservables();
    this.patientRequestDoctorHelper.networkError.subscribe(() => this.onNetworkError());
    this.subPayloadChanges();
  }

  private subPayloadChanges() {
    this.payloadDataSubscription = this.payloadDataService.payloadData.subscribe(data => {
      if (data && data.event === 'labNote') {
        this.service.getPermissions().subscribe((response) => {
          this.permissions = response;
          if (this.permissions.find) {
            this.setPatientIdFromEvent(data);
            this.getPatientDetailsFromEvent(data);
          } else {
            this.toasterService.pop('warning', 'You do not have permission to view this page');
          }
        });
      }
    });
  }

  private onNetworkError() {
    if (this.notesSub) {
      this.notesSub.unsubscribe();
    }

    this.notes = [];
    this.patientRequestDoctorHelper.resetObservables();
  }

  private setPatientIdFromEvent(data) {
    this.patientId = data.payload.patient;
  }

  private getPatientDetailsFromEvent(data) {
    if (data.payload.request) {
      this.patientRequestDoctorHelper.fetchPatientRequestDoctorFromRequestId(data.payload.request || null);
    } else {
      this.patientRequestDoctorHelper.resetObservables();
      this.patientRequestDoctorHelper.fetchPatientDetails(this.patientId);
    }
    this.getPatientNotes();
    this.getPatientRequests();
  }

  onRequestChanged(req) {
    if (req) {
      this.patientRequestDoctorHelper.fetchPatientRequestDoctorFromRequestId(req.id);
    } else {
      this.patientRequestDoctorHelper.resetObservables();
      this.patientRequestDoctorHelper.fetchPatientDetails(this.patientId);
    }
  }

  private getPatientNotes() {
    this.notesSub = this.service.getNotesForPatient(this.patientId).subscribe(
      (notes) => this.notes = notes,
      (error) => {
        this.onNetworkError();
        throw error;
      }
    );
  }

  private getPatientRequests() {
    this.service.getRequestsForPatient(this.patientId).subscribe((reqs) => {
      this.requests.next(reqs);
    });
  }

  ngOnDestroy() {
    if (this.payloadDataSubscription) {
      this.payloadDataSubscription.unsubscribe();
    }
  }

  onNoteAdded(model: LabNoteModel) {
    if (this.permissions.add) {
      this.service.createNote(model, this.patientId).subscribe(
        (result) => this.getPatientNotes()
      );
    }
  }

}
