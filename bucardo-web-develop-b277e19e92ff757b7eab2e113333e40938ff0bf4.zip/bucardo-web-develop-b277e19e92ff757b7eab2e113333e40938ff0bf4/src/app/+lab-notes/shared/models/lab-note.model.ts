export interface LabNoteModel {
  id?: string;
  userId?: string;
  username?: string;
  requestId?: string;
  timestamp?: string;
  noteText: string;
}
