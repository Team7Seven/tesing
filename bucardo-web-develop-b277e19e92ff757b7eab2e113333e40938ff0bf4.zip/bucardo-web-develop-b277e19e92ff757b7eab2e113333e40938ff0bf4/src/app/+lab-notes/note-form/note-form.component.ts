import {
  Component, ElementRef, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges,
  ViewChild
} from '@angular/core';
import {LabNoteModel} from '../shared/models/lab-note.model';
import {RequestModel} from '../../shared/models/request.model';
import {SearchBoxComponent} from '../../shared/components/search-box/search-box.component';
import {SearchBoxItemModel} from '../../shared/components/search-box/search-box-item.model';
import {Observable} from 'rxjs/Observable';

@Component({
  selector: 'note-form',
  template: `
      <div class="panel panel-default">
          <div class="panel-heading fill">
          <label for="note-entry" class="label-small-margin">Add Lab Note</label>
            <textarea id="note-entry" (keydown)="handleNoteEntryKeyDown($event)"
                      placeholder="Type note here... (ctrl+enter to submit)" title="Lab Note Text"
                      class="form-control" [(ngModel)]="noteText" autofocus #noteInput>
            </textarea>
          
            <span id="requests">
              <search-box #searchBox [items]="requests" [filter]="requestFilter"
                          (selectedChanged)="requestSelected($event)" [autoSelected]="autoSelect"
                          (ctrlEnterPressed)="submitNote()" [placeholder]="'Search for request'" [multiple]="false" 
                          [dropUp]="true" [clearFilterOnFocus]="true"></search-box>
            </span>

            <span class="add-button">  
              <button id="submit-note" title="Ctrl+Enter to Submit" (click)="submitNote()"
                        [disabled]="!noteText.trim()" class="btn btn-primary notes-buttons">Add</button>
            </span>
            
            <div class="clearfix"></div>
          </div>
      </div>
  `
  ,
  styleUrls: ['./note-form.component.scss']
})
export class NoteFormComponent implements OnChanges, OnInit {
  @Input() requests: Observable<Array<any>>;
  @Input() selectedRequest: RequestModel;
  @Output() noteAdded = new EventEmitter<LabNoteModel>();
  @Output() requestIdChanged = new EventEmitter<string>();

  requestFilter = '';
  noteText = '';
  autoSelect: SearchBoxItemModel;
  currentRequest: SearchBoxItemModel;
  requestModels: SearchBoxItemModel[] = [];


  @ViewChild('noteInput') noteInput: ElementRef;
  @ViewChild('searchBox') searchBox: SearchBoxComponent;

  ngOnInit() {
    this.requests.subscribe((requests) => {
      this.requestModels = requests;
      this.autoSelectRequest();
    });
  }


  ngOnChanges(changes: SimpleChanges): void {
    if ('requests' in changes) {
      this.autoSelectRequest();
    }
    if ('selectedRequest' in changes) {
      // check it is not the currently selected request
      if (!this.currentRequest || !this.selectedRequest || this.currentRequest.id !== this.selectedRequest.ri) {
        this.autoSelectRequest();
      }
    }
  }

  autoSelectRequest() {
    if (this.selectedRequest) {
      this.requestModels.forEach((request) => {
        if (request.id === this.selectedRequest.ri) {
          this.currentRequest = this.autoSelect = request;
          this.requestFilter = `${this.selectedRequest.prefix}-${this.selectedRequest.num}`;
        }
      });
    } else {
      this.autoSelect = null;
      this.requestFilter = '';
    }
  }

  handleNoteEntryKeyDown($event) {
    if ($event.keyCode === 13 && $event.ctrlKey) {
      this.submitNote();
    }
  }

  submitNote() {
    if (this.noteText.trim()) {
      const requestInfo = (this.currentRequest) ? {requestId: this.currentRequest.id} : {};

      const modelToSubmit = Object.assign({}, {noteText: this.noteText}, requestInfo);
      this.noteAdded.emit(modelToSubmit);
      this.noteText = '';
      this.noteInput.nativeElement.focus();
      this.searchBox.clear();
    }
  }

  requestSelected($event) {
    if ($event && $event[0]) {
      this.selectedRequest = $event[0];
      this.currentRequest = $event[0];
      this.requestIdChanged.emit($event[0]);
    } else {
      this.selectedRequest = null;
      this.currentRequest = null;
      this.requestIdChanged.emit(null);
    }
  }


}
