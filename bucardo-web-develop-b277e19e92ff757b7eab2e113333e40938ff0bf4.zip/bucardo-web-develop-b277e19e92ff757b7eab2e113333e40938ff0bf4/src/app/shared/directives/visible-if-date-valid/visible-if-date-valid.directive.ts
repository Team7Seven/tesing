import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';

/**
 * Add the template content to the DOM unless the returned date is invalid / nonsensical value.
 *
 * If the date string passed to `visibleIfDateValid` evaluates to a truthy value
 * then the templated elements are removed removed from the DOM,
 * the templated elements are (re)inserted into the DOM.
 *
 * <div *visibleIfDateValid="dateVar" class="whateverClass">
 *   Display date
 * </div>
 *
 * ### Syntax
 *
 * - `<div *visibleIfDateValid="dateVar">...</div>`
 * - `<div template="visibleIfDateValid dateVar">...</div>`
 * - `<template [visibleIfDateValid]="dateVar"><div>...</div></template>`
 *
 */
@Directive({ selector: '[visibleIfDateValid]'})
export class VisibleIfDateValidDirective {
  private visible = false;

  constructor(
    private templateRef: TemplateRef<any>,
    private viewContainer: ViewContainerRef) { }

  @Input() set visibleIfDateValid(date: string) {
    if ((date.includes('0001-01-01T00:00:00Z') || !date) && this.visible) {
      this.viewContainer.clear();
      this.visible = false;
    } else if ((!date.includes('0001-01-01T00:00:00Z')) && date && !this.visible) {
      this.viewContainer.createEmbeddedView(this.templateRef);
      this.visible = true;
    }
  }
}
