import {async} from '@angular/core/testing';
import {ResizeDetectDirective} from './resize-detect.directive';
import createSpy = jasmine.createSpy;
import Spy = jasmine.Spy;

describe('OnResizeDirective', () => {

  class ElementRefStub {
    nativeElement: any;
  }

  class EventEmitterMock {
    emit: Spy = createSpy('eventEmitter');
  }

  let directive: ResizeDetectDirective;
  let elementRefMock: ElementRefStub;
  const eventEmitterMock = new EventEmitterMock();

  beforeEach(async(() => {
    elementRefMock = new ElementRefStub();
    elementRefMock.nativeElement = { clientHeight: 0};
    directive = new ResizeDetectDirective(elementRefMock);
    directive.resize = <any>eventEmitterMock;
  }));

  it('should emit event when clientHeight changes', () => {
    elementRefMock.nativeElement.clientHeight = 200;
    directive.ngDoCheck();
    expect(eventEmitterMock.emit).toHaveBeenCalledWith({previous: 0, current: 200});
  });

  it('should emit event with proper previous client height when called multiple times', () => {
    elementRefMock.nativeElement.clientHeight = 200;
    directive.ngDoCheck();
    eventEmitterMock.emit.calls.reset();

    elementRefMock.nativeElement.clientHeight = 400;
    directive.ngDoCheck();
    expect(eventEmitterMock.emit).toHaveBeenCalledWith({previous: 200, current: 400});
  });


  it('should not emit if client height hasn`t changed', () => {
    elementRefMock.nativeElement.clientHeight = 200;
    directive.ngDoCheck();
    eventEmitterMock.emit.calls.reset();

    elementRefMock.nativeElement.clientHeight = 200;
    directive.ngDoCheck();
    expect(eventEmitterMock.emit).not.toHaveBeenCalled();
  });
});
