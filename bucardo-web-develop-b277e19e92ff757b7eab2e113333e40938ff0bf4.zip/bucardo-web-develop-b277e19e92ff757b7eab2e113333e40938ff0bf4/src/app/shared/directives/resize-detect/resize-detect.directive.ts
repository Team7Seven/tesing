import {Directive, DoCheck, ElementRef, EventEmitter, Output} from '@angular/core';

@Directive({
  selector: '[resize-detect]'
})
export class ResizeDetectDirective implements DoCheck {
  @Output() resize = new EventEmitter<any>();

  private elementHeight = 0;

  constructor(private element: ElementRef) {

  }

  ngDoCheck(): void {
    if (this.element.nativeElement) {
      if (this.heightChanged()) {
        this.emitResizeEvent();
        this.storeNewElementHeight();
      }
    }
  }

  private heightChanged() {
    return this.element.nativeElement.clientHeight !== this.elementHeight;
  }

  private emitResizeEvent() {
    this.resize.emit({previous: this.elementHeight, current: this.element.nativeElement.clientHeight});
  }

  private storeNewElementHeight() {
    this.elementHeight = this.element.nativeElement.clientHeight;
  }
}
