
import {Subscription} from 'rxjs/Subscription';

export function unsub(sub: Subscription) {
  if (sub) {
    sub.unsubscribe();
  }
}

