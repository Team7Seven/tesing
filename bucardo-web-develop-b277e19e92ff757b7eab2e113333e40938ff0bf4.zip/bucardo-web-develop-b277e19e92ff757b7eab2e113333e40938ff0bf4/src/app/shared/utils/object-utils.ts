
export function removePropertiesFromObject(obj: Object, propertiesToRemove: Array<any>): any {
  const result = {};
  Object.keys(obj).forEach((key) => {
    if (propertiesToRemove.indexOf(key) === -1) {
      result[key] = obj[key];
    }
  });

  return result;
}

