
export function getEtagFromMeta(metaContainer: any) {
  if (metaContainer.meta) {
    return metaContainer.meta.eTag;
  } else {
    return '';
  }
}

