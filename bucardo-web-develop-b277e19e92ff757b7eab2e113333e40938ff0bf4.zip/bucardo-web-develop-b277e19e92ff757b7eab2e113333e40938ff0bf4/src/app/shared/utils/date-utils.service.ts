import { Injectable } from '@angular/core';

@Injectable()
export class DateUtilsService {

  getTimeMs() {
    return new Date().getTime();
  }

}
