import {Response} from '@angular/http';
import {Toast} from 'angular2-toaster';

export class HttpError extends Error {
  constructor(public response: Response, public message: string, public customToast?: Toast) {
    super(message);
  }
}
