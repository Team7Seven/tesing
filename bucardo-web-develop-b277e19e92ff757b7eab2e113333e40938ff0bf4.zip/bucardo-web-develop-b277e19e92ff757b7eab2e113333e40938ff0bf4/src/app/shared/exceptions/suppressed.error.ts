import {Response} from '@angular/http';

export class SuppressedError extends Error {
  constructor(public message = '') {
    super(message);
  }
}
