export class DuplicateKeyError extends Error {
  constructor() {
    super('A duplicate key was detected');
  }
}
