import { TestBed, inject } from '@angular/core/testing';
import { PayloadDataService } from './payload-data.service';

describe('Service: PayloadData', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PayloadDataService]
    });
  });

  it('should ...', inject([PayloadDataService], (service: PayloadDataService) => {
    expect(service).toBeTruthy();
  }));
});
