import {ApiErrorHandler} from './api-error-handler';
import {Response} from '@angular/http';
import createSpy = jasmine.createSpy;
import {HttpError} from '../../exceptions/http.error';

describe('Service: API Error Handler', () => {

  let errorHandler: ApiErrorHandler;

  const URL_CALLED = 'http://someurl.com';
  const NO_RESPONSE_MSG = 'No response from Ultra services, please try again once connectivity is restored';
  const PARSE_ERROR_MSG = 'An error occurred while parsing response';

  beforeEach(() => {
    errorHandler = new ApiErrorHandler();
    spyOn(console, 'error');
  });


  describe('when calling errorHandler.fail with an info message', () => {

    const infoResponse: Response = <any>{
      json: function () {
        return {
          text: 'info error message',
          severity: 'info'
        };
      },
      status: 412
    };

    it('throws an http error', () => {
      try {
        errorHandler.fail(infoResponse, URL_CALLED);
        fail('should not reach here');
      } catch (e) {
        expect(e instanceof HttpError).toBeTruthy();
      }
    });


    it('requests a info type toast', () => {
      try {
        errorHandler.fail(infoResponse, URL_CALLED);
        fail('should not reach here');
      } catch (e) {
        expect(e.customToast.type).toEqual('info');
      }
    });

    it('The body of the toast contains the response body text', () => {
      try {
        errorHandler.fail(infoResponse, URL_CALLED);
        fail('should not reach here');
      } catch (e) {
        expect(e.customToast.body).toEqual('info error message');
      }
    });

  });

  describe('when calling errorHandler.fail with a warning message', () => {

    const warningResponse = {
      json: function () {
        return {
          text: 'warning error message',
          severity: 'warning'
        };
      },
      status: 412
    };

    it('requests a warning type toast', () => {
      try {
        errorHandler.fail(warningResponse, URL_CALLED);
        fail('should not reach here');
      } catch (e) {
        expect(e.customToast.type).toEqual('warning');
      }
    });

    it('The body of the toast contains the response body text', () => {
      try {
        errorHandler.fail(warningResponse, URL_CALLED);
        fail('should not reach here');
      } catch (e) {
        expect(e.customToast.body).toEqual('warning error message');
      }
    });

    it('should have a timeout of 10000', () => {
      try {
        errorHandler.fail(warningResponse, URL_CALLED);
        fail('should not reach here');
      } catch (e) {
        expect(e.customToast.timeout).toEqual(10000);
      }
    });

  });

  describe('when calling errorHandler.fail with an error message', () => {

    const errorResponse = {
      json: function () {
        return {
          text: 'error message',
          severity: 'error'
        };
      },
      status: 412
    };

    it('requests a error type toast', () => {
      try {
        errorHandler.fail(errorResponse, URL_CALLED);
        fail('should not reach here');
      } catch (e) {
        expect(e.customToast.type).toEqual('error');
      }
    });

    it('The body of the toast contains the response body text', () => {
      try {
        errorHandler.fail(errorResponse, URL_CALLED);
        fail('should not reach here');
      } catch (e) {
        expect(e.customToast.body).toEqual('error message');
      }
    });

    it('should have an unlimited timeout (0)', () => {
      try {
        errorHandler.fail(errorResponse, URL_CALLED);
        fail('should not reach here');
      } catch (e) {
        expect(e.customToast.timeout).toEqual(0);
      }
    });

  });

  describe('when calling errorHandler.fail with a fatal message', () => {

    const fatalResponse = {
      json: function () {
        return {
          text: 'error message',
          severity: 'fatal'
        };
      },
      status: 412
    };

    it('requests a error type toast', () => {
      try {
        errorHandler.fail(fatalResponse, URL_CALLED);
        fail('should not reach here');
      } catch (e) {
        expect(e.customToast.type).toEqual('error');
      }
    });

    it('The body of the toast contains the response body text', () => {
      try {
        errorHandler.fail(fatalResponse, URL_CALLED);
        fail('should not reach here');
      } catch (e) {
        expect(e.customToast.body).toEqual('error message');
      }
    });

    it('should have an unlimited timeout (0)', () => {
      try {
        errorHandler.fail(fatalResponse, URL_CALLED);
        fail('should not reach here');
      } catch (e) {
        expect(e.customToast.timeout).toEqual(0);
      }
    });

  });

  describe('when a response is NOT received from server', () => {
    const response = {
      status: 0,
      json: function () {
        return 'FAILED';
      }
    };

    it('should throw an exception for the global error handler to receive', () => {

      try {
        errorHandler.fail(response, URL_CALLED);
      } catch (error) {
        expect(error.message).toEqual(NO_RESPONSE_MSG);
        expect(error.stack).toEqual(`No response from: ${URL_CALLED}`);
      }

    });
  });

  describe('incorrectly formatted error response', () => {

    it('shows a toast with a generic Ultra services error as the error coming back has an ' +
      'incorrect formatted response body or no body', () => {
      const response = new SyntaxError();

      try {
        errorHandler.fail(response, URL_CALLED);
      } catch (error) {
        expect(error.message).toEqual(PARSE_ERROR_MSG);
      }

    });

    it('should throw a connection error problem if response is not parseable', () => {
      const response = {
        status: 503,
        json: createSpy('json').and.throwError('ERROR')
      };

      try {
        errorHandler.fail(response, URL_CALLED);
      } catch (error) {
        expect(error.message).toEqual(NO_RESPONSE_MSG);
      }
    });

  });

});
