import {Injectable} from '@angular/core';
import {Response} from '@angular/http';
import {HttpError} from '../../exceptions/http.error';
import {DuplicateKeyError} from '../../exceptions/duplicate-key.error';
import {Toast} from 'angular2-toaster';
import {TimeoutError} from 'rxjs/Rx';

@Injectable()
export class ApiErrorHandler {

  static readonly noServiceMsg = 'No response from Ultra services, please try again once connectivity is restored';

  constructor() {
  }

  public fail(response: Response | any, url: string) {

    if (response.hasOwnProperty('status')) {
      this.handleHttpResponse(response, url);
    } else if (response instanceof SyntaxError) {
      this.handleSyntaxError();
    } else if (response instanceof TimeoutError) {
      this.handleServerConnectionProblems(url);
    }
  }

  handleHttpResponse(response: Response | any, url: string) {
    if (response.status < 200 || response.status > 226) {
        if (!response.status || !this.isValidJsonResponse(response)) {
          this.handleServerConnectionProblems(url);
        } else {
          this.handleHttpError(response);
        }
      }
  }

  private isValidJsonResponse(response: Response | any) {
    let validResponse = true;

    try {
      response.json();
    } catch (e) {
      validResponse = false;
    }
    return validResponse;
  }

  generateToastFromResponse(response: Response | any) {
    const responseBody = response.json();

    const toast: Toast = {
      type: 'error',
      title: '',
      body: (responseBody.text) ? responseBody.text : '',
      timeout: 0,
      showCloseButton: false
    };

    switch (responseBody.severity) {
      case 'warning':
        if (!toast.title) {
          toast.title = 'Warning';
        }
        toast.type = 'warning';
        toast.timeout = 10000;
        break;
      case 'info':
        toast.type = 'info';
        toast.timeout = 10000;
        break;
      case 'fatal':
      case 'error':
      default:
        if (!toast.title) {
          toast.title = 'Error';
        }
        toast.type = 'error';
        break;
    }
    return toast;
  }

  handleServerConnectionProblems(url: string, title = 'Error') {
    const errorReport = {
      message: ApiErrorHandler.noServiceMsg,
      stack: `No response from: ${url}`
    };

    throw errorReport; // Allow the error handler to pick up the error report
  }

  handleHttpError(response: Response | any) {
    throw new HttpError(response, 'An unknown http error occurred', this.generateToastFromResponse(response));
  }

  handleSyntaxError() {
    throw new Error('An error occurred while parsing response');
  }

}
