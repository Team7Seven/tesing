import {ApiClient} from '../api-client/api-client';
import {ConfigurationService} from '../configuration/configuration.service';
import {RequestDetailsService} from './request-details.service';
import {async} from '@angular/core/testing';
import {Observable} from 'rxjs/Observable';
import {RequestModel} from '../../models/request.model';
import createSpy = jasmine.createSpy;
import Spy = jasmine.Spy;

describe('RequestDetailsService', () => {

  class ApiClientMock {
    get: Spy;
  }

  const labApiUrl = 'http://labApiUrl:8000';
  const validId = '70';
  let configService: ConfigurationService;
  let apiClientMock: ApiClientMock;
  let requestDetailsService: RequestDetailsService;

  beforeEach(() => {
    apiClientMock = new ApiClientMock();
    configService = new ConfigurationService(<ApiClient><any>apiClientMock);
    requestDetailsService = new RequestDetailsService(<ApiClient><any>apiClientMock, configService);
    apiClientMock.get = jasmine.createSpy('get').and.returnValue(Observable.from([RequestModel]));
  });

  it('should initialise RequestDetailsService successfully', () => {
    expect(requestDetailsService).toBeTruthy();
  });

  it('should return request details from GET call to Lab API', async(() => {
    requestDetailsService.getDetails(validId).subscribe(
        () => {
          expect(apiClientMock.get).toHaveBeenCalledWith(`${this.labAPIUrl}/Request/${validId}`);
        }
      );
    })
  );

});





