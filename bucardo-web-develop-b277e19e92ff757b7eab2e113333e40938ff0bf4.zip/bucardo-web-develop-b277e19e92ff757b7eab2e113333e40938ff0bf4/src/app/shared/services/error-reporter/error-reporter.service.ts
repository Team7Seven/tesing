import {ErrorHandler, Injectable} from '@angular/core';
import {ApiClient} from '../api-client/api-client';
import {Toast, ToasterService} from 'angular2-toaster';
import {SuppressedError} from '../../exceptions/suppressed.error';

@Injectable()
export class ErrorReporterService implements ErrorHandler {

  public labApiUrl: string;

  constructor(private apiClient: ApiClient, private toasterService: ToasterService) {
  }

  handleError(error: any): void {
    if (error instanceof SuppressedError) {
      return;
    }

    this.reportErrorToTheConsole(error);
    this.reportErrorToTheLabApi(error);

    if (!error.noToast) {
      this.reportErrorAsToastMessage(error);
    }
  }

  public reportErrorToTheConsole(error: any) {
    console.error(error.stack);
  }

  public reportErrorToTheLabApi(error: any) {
    const payload = {
      severity: 'error',
      text: error.message,
      exception: error.stack
    };

    this.apiClient.post(`${this.labApiUrl}/Proc/$logEvent`, payload, null, false, true).subscribe(
      () => console.info('Successfully reported error'),
      (err) => console.error('Failed to report error', err));
  }

  public reportErrorAsToastMessage(error) {
    let toast: Toast;

    if (error.hasOwnProperty('customToast')) {
      toast = error.customToast;
    } else {
      toast = {
        type: 'error',
        title: 'Error',
        body: error.message,
        timeout: 0,
        showCloseButton: false
      };
    }

    this.toasterService.pop(toast);
  }
}

