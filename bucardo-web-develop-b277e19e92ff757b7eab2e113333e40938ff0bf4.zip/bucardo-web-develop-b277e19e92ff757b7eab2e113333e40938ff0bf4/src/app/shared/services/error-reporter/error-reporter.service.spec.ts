import {ErrorReporterService} from './error-reporter.service';
import {Observable} from 'rxjs/Observable';
import {Toast} from 'angular2-toaster';
import {SuppressedError} from '../../exceptions/suppressed.error';
import Spy = jasmine.Spy;

describe('ErrorReporterService', () => {
  let service: ErrorReporterService;
  let apiClientMock: ApiClientMock;
  let toasterMock: ToasterMock;

  const LAB_API_URL = 'LAB_API_URL';
  const APP_FAILURE = {
    message: 'pants',
    stack: 'pantaloons stack'
  };
  const APP_FAILURE_NO_TOAST = {
    message: 'pants',
    stack: 'pantaloons stack',
    noToast: true
  };

  class ApiClientMock {
    post: Spy;
  }

  class ToasterMock {
    pop = jasmine.createSpy('pop');
  }

  beforeEach(() => {
    apiClientMock = new ApiClientMock();
    toasterMock = new ToasterMock();
    apiClientMock.post = jasmine.createSpy('post').and.returnValue(Observable.of(null));

    service = new ErrorReporterService(<any>apiClientMock, <any>toasterMock);
    service.labApiUrl = LAB_API_URL;

    spyOn(console, 'error');
    spyOn(console, 'log');
    spyOn(console, 'info');
  });

  it('should report errors to the console', () => {
    service.handleError(APP_FAILURE);

    expect(console.error).toHaveBeenCalledWith('pantaloons stack');
  });

  it('should call the logEvent API', () => {
    service.handleError(APP_FAILURE);

    expect(apiClientMock.post).toHaveBeenCalledWith(`${LAB_API_URL}/Proc/$logEvent`,
      {
        severity: 'error',
        text: APP_FAILURE.message,
        exception: APP_FAILURE.stack
      }, null, false, true);
  });

  it('should log that we successfully reported error on API success', () => {
    service.handleError(APP_FAILURE);

    expect(console.info).toHaveBeenCalledWith('Successfully reported error');
  });

  it('should show a toast if noToast is not set', () => {
    service.handleError(APP_FAILURE);

    const toast: Toast = {
      type: 'error',
      title: 'Error',
      body: APP_FAILURE.message,
      timeout: 0,
      showCloseButton: false
    };

    expect(toasterMock.pop).toHaveBeenCalledWith(toast);
  });


  it('should NOT show a toast if noToast is true', () => {
    service.handleError(APP_FAILURE_NO_TOAST);

    expect(toasterMock.pop).not.toHaveBeenCalled();
  });

  it('should log that we failed to report error on API error', () => {
    const anError = new Error('HTTP ERROR');

    apiClientMock.post = jasmine.createSpy('post').and.returnValue(Observable.throw(anError));

    service.handleError(APP_FAILURE);

    expect(console.error).toHaveBeenCalledWith('Failed to report error', anError);
  });

  it('should ignore any suppressed errors', () => {
      service.handleError(new SuppressedError());

      expect(console.error).not.toHaveBeenCalled();
      expect(apiClientMock.post).not.toHaveBeenCalled();
      expect(toasterMock.pop).not.toHaveBeenCalled();
  });


});
