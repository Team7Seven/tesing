import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {ApiClient} from '../api-client/api-client';
import {ConfigurationService} from '../configuration/configuration.service';
import {UserModel} from '../../models/user.model';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';

@Injectable()
export class UserService {

  private labApiUrl: string;

  private userBS = new BehaviorSubject<UserModel>(null);
  user = this.userBS.share();

  constructor(private apiClient: ApiClient, private configService: ConfigurationService) {
    this.labApiUrl = configService.getConfig().labapi_url;
  }

  getUserDetails(username: string): Observable<UserModel> {
    return this.apiClient.get(`${this.labApiUrl}/User/${username}`).map((user) => {
      this.userBS.next(user);
      return user;
    });
  }

}
