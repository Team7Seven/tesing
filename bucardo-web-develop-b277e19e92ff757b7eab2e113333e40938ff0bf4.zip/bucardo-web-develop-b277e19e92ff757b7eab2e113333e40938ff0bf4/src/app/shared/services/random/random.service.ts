import { Injectable } from '@angular/core';

@Injectable()
export class RandomService {

  constructor() { }

  random(): number {
    return Math.random();
  }

}
