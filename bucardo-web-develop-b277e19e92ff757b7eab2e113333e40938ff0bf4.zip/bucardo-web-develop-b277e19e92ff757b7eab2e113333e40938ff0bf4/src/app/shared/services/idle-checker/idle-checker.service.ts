import {Injectable, NgZone} from '@angular/core';

@Injectable()
export class IdleCheckerService {
  timeoutCallback: Function;
  warningCallback: Function;
  timeoutHandle: any;
  warnTimeoutHandle: any;
  timeoutAfterSecs: number;
  warnAfterSecs: number;
  doCheck = true;

  constructor(private _ngZone: NgZone) {
  }

  setWarningCallback(f: Function) {
    this.warningCallback = f;
  }

  setTimeoutCallback(f: Function) {
    this.timeoutCallback = f;
  }

  setTimeoutTime(timeoutInSecs: number) {
    this.timeoutAfterSecs = timeoutInSecs;
  }

  setWarningTime(warningTime: number) {
    this.warnAfterSecs = warningTime;
  }

  setEnableCheck(doCheck: boolean) {
    this.doCheck = doCheck;
  }

  stopTimers() {
    clearTimeout(this.timeoutHandle);
    clearTimeout(this.warnTimeoutHandle);
  }

  startTimers() {
    this._ngZone.runOutsideAngular(() => {
      this.timeoutHandle = setTimeout(() => {
        this.emitTimeoutEvent();
      }, this.timeoutAfterSecs * 1000);

      this.warnTimeoutHandle = setTimeout(() => {
        this.emitWarnEvent();
      }, this.warnAfterSecs * 1000);
    });
  }

  resetTimers() {
    this.stopTimers();
    if (this.doCheck) {
      this.startTimers();
    }
  }

  emitTimeoutEvent() {
    this._ngZone.run(() => {
      if (this.timeoutCallback) {
        this.timeoutCallback();
      }
      this.resetTimers();
    });
  }

  emitWarnEvent() {
    this._ngZone.run(() => {
      if (this.warningCallback) {
        this.warningCallback();
      }
      clearTimeout(this.warnTimeoutHandle);
    });
  }
}
