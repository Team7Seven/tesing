import {Injectable} from '@angular/core';
import {Http, Headers, Response, RequestOptions} from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import {Login} from '../../../+login/shared/models/login.model';
import {Observable} from 'rxjs/Observable';

/**
 * This class provides the Authentication service with methods to login and logout.
 */

@Injectable()
export class AuthenticationService {
  private loggedIn = false;

  constructor(private _http: Http) {
    this.loggedIn = !!localStorage.getItem('Token ');
  }

  login(credentials: Login): Observable<boolean> {

    const loginToken: string = credentials.username + ':' + credentials.password;
    const encodedToken = btoa(loginToken);

    const body = JSON.stringify({username: credentials.username});
    const headers = new Headers({'Content-Type': 'application/json'});
    const authToken = 'Basic ' + encodedToken;
    headers.append('Authorization', authToken);
    const options = new RequestOptions({headers: headers});

    return this._http.post('http://hydra.cirdan.com:8080/Login', body, options)
      .map((response: Response) => {
        try {
          const token = response.json() && response.json().token;
          if (token) {
            localStorage.setItem('Token ', response.json().token);
            localStorage.setItem('currentUser', JSON.stringify({username: credentials.username, token: token}));
            this.loggedIn = true;
            return true;
          } else {
            return false;
          }
        } catch (err) {
          return false;
        }
      });
  }

  logout() {
    localStorage.removeItem('Token ');
    localStorage.removeItem('currentUser');
    this.loggedIn = false;
  }

  isLoggedIn() {
    // Disable login for the moment - not needed for HHB
    return true;
  }
}
