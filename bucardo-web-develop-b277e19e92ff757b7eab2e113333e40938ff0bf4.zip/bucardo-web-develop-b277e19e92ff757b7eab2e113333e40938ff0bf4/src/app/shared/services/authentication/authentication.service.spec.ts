import {Http, Response, ResponseOptions} from '@angular/http';
import {AuthenticationService} from './authentication.service';
import {async} from '@angular/core/testing';
import {Login} from '../../../+login/shared/models/login.model';
import {Observable} from 'rxjs/Observable';

describe('Authentication Service', () => {

  const validLoginCredentials = new Login('bobert', 'Jumbone', 'Bob', 'McConnell', '');
  const invalidLoginCredentials = new Login('bobert', 'Jumbone123', 'Bob', 'McConnell', '');

  const successResponseObj = {token: 'SomeTokenValue'};
  const successfulResponse = new Response(new ResponseOptions({body: JSON.stringify(successResponseObj)}));
  const errorResponse = new Response(new ResponseOptions({body: 'There has been a terrible error', status: 500}));

  const invalidCredsResponseObj = {error: 'Invalid Credentials'};
  const invalidCredsResponse = new Response(new ResponseOptions({body: JSON.stringify(invalidCredsResponseObj)}));

  let service: AuthenticationService;
  let httpMock: MockHttpService;

  class MockHttpService {
    post: Function;
  }

  beforeEach(() => {
    httpMock = new MockHttpService();
    service = new AuthenticationService(<Http><any>httpMock);
  });

  describe('Login', () => {

    describe('with valid credentials and success server response', () => {

      beforeEach(() => {
        httpMock.post = jasmine.createSpy('post').and.returnValue(Observable.from([successfulResponse]));
      });

      it('should return true', async(() => {
          service.login(validLoginCredentials).subscribe(
            data => {
              expect(data).toBe(true);
            }
          );
        })
      );

      it('should call out to server to log in', async(() => {
          service.login(validLoginCredentials).subscribe(
            () => {
              expect(httpMock.post).toHaveBeenCalled();
            }
          );
        })
      );

      it('should store the auth token in localstorage', async(() => {
          spyOn(localStorage, 'setItem');

          service.login(validLoginCredentials).subscribe(
            () => {
              expect(localStorage.setItem).toHaveBeenCalledWith('Token ', 'SomeTokenValue');
            }
          );
        })
      );

      it('should store the current user in localstorage', async(() => {
          spyOn(localStorage, 'setItem');

          service.login(validLoginCredentials).subscribe(
            () => {
              expect(localStorage.setItem).toHaveBeenCalledWith('currentUser', '{"username":"bobert","token":"SomeTokenValue"}');
            }
          );
        })
      );


    }); // Valid Credentials

    describe('with valid credentials and error server response', () => {

      beforeEach(() => {
        httpMock.post = jasmine.createSpy('post').and.returnValue(Observable.from([errorResponse]));
      });

      it('should return a result of false', () => {
        spyOn(localStorage, 'setItem');

        service.login(validLoginCredentials).subscribe(
          (result) => {
            expect(result).toBe(false);
          }
        );
      });

      it('should not set a token on local storage', () => {
        spyOn(localStorage, 'setItem');

        service.login(validLoginCredentials).subscribe(
          () => {
            expect(localStorage.setItem).not.toHaveBeenCalled();
          }
        );
      });

    }); // Server error

    describe('with invalid credentials', () => {

      beforeEach(() => {
        httpMock.post = jasmine.createSpy('post').and.returnValue(Observable.from([invalidCredsResponse]));
      });

      it('should return a result of false', () => {
        spyOn(localStorage, 'setItem');

        service.login(invalidLoginCredentials).subscribe(
          (result) => {
            expect(result).toBe(false);
          }
        );
      });

      it('should not set a token on local storage', () => {
        spyOn(localStorage, 'setItem');

        service.login(invalidLoginCredentials).subscribe(
          () => {
            expect(localStorage.setItem).not.toHaveBeenCalled();
          }
        );
      });

    }); // Invalid credentials
  });

  describe('Logout', () => {

    it('should remove token from local storage', () => {
      spyOn(localStorage, 'removeItem');

      service.logout();

      expect(localStorage.removeItem).toHaveBeenCalledWith('Token ');
    });

    it('should remove user from local storage', () => {
      spyOn(localStorage, 'removeItem');

      service.logout();

      expect(localStorage.removeItem).toHaveBeenCalledWith('currentUser');
    });
  });


});
