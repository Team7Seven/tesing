import {ConfigurationService} from './configuration.service';
import {Observable} from 'rxjs/Observable';
import {fakeAsync, tick} from '@angular/core/testing';
import {ApiClient} from '../api-client/api-client';
import createSpy = jasmine.createSpy;
import Spy = jasmine.Spy;
import anything = jasmine.anything;

describe('ConfigurationService', () => {

  class ApiClientMock {
    get: Spy;
  }

  class ErrorHandlerMock {
    labApiUrl = '';
  }

  // Const response objects
  const insecureResponseObj: any = {krill_url: 'http://KRILL'};
  const preAuthResponseObj: any = {labapi_url: 'http://labApiUrl:8000'};

  // Const test URL's to various configs
  const preConfigUrl = 'assets/config/preConfig.json';

  // Mock service variables
  let configService: ConfigurationService;
  let apiClientMock: ApiClientMock;
  let errorHandlerMock: ErrorHandlerMock;

  beforeEach(() => {
    apiClientMock = new ApiClientMock();
    errorHandlerMock = new ErrorHandlerMock();
    configService = new ConfigurationService(<ApiClient><any>apiClientMock);
  });

  it('should create the config service successfully', () => {
    expect(configService).toBeTruthy();
  });

  describe('loadPreconfiguration success', () => {
    beforeEach(() => {
      apiClientMock.get = createSpy('apiClientMock.get').and.callFake((url) => {
        if (url === preConfigUrl) {
          return Observable.of(preAuthResponseObj);
        } else {
          return Observable.of(insecureResponseObj);
        }
      });


    });

    it('should set the labApiUrl for the error handler', fakeAsync(() => {
      configService.loadPreconfiguration(<any>errorHandlerMock, '');
      tick();
      expect(errorHandlerMock.labApiUrl).toEqual('http://labApiUrl:8000');
    }));

    it('should perform a GET call with preConfigUrl', fakeAsync(() => {
      configService.loadPreconfiguration(<any>errorHandlerMock, '');
      tick();
      expect(apiClientMock.get).toHaveBeenCalledWith(preConfigUrl, null, false);
    }));

    it('should perform a GET call with to the lab API for insecure config', fakeAsync(() => {
      configService.loadPreconfiguration(<any>errorHandlerMock, '');
      tick();
      expect(apiClientMock.get).toHaveBeenCalledWith(preConfigUrl, null, false);
    }));

    it('should have a config object that contains both the pre auth and insecure data', fakeAsync(() => {
      configService.loadPreconfiguration(<any>errorHandlerMock, '').then(() => {
        expect(configService.getConfig().krill_url).toEqual('http://KRILL');
        expect(configService.getConfig().labapi_url).toEqual('http://labApiUrl:8000');
      });
      tick();
    }));

    it('should set initialised to true on success', fakeAsync(() => {
      configService.loadPreconfiguration(<any>errorHandlerMock, '').then(() => {
        expect(configService.isInitialised()).toEqual(true);
      });
      tick();
    }));
  });

  describe('loadPreconfigurations errors', () => {

    beforeEach(() => {
      spyOn(console, 'error');
    });

    describe('Failed to get preConfig.json', () => {
      beforeEach(() => {
        apiClientMock.get = createSpy('apiClientMock.get').and.returnValue(Observable.throw(new Error('AN_ERROR')));
        configService.loadPreconfiguration(<any>errorHandlerMock, '');
      });

      it('should not be initialised when we have an error getting pre config', fakeAsync(() => {
        tick();
        expect(configService.isInitialised()).toEqual(false);
      }));

      it('should log error to console', fakeAsync(() => {
        tick();
        expect(console.error).toHaveBeenCalledWith('Failed to get configuration:', anything());
      }));
    });


  });


  describe('Overrriding config with query string', () => {
    beforeEach(() => {
      apiClientMock.get = createSpy('apiClientMock.get').and.callFake((url) => {
        if (url === preConfigUrl) {
          return Observable.of(preAuthResponseObj);
        } else {
          return Observable.of(insecureResponseObj);
        }
      });
    });

    it('should overwrite the lab api', () => {
      const queryString = 'labapi_url=http%3A%2F%2Foverridden%3A35200';
      configService.loadPreconfiguration(<any>errorHandlerMock, queryString).then((config) => {
        expect(config.labapi_url).toEqual('http://overridden:35200');
      });
    });

    it('should overwrite the krill ws url', () => {
      const queryString = 'krill_ws=http%3A%2F%2Foverridden_krill%3A35200';
      configService.loadPreconfiguration(<any>errorHandlerMock, queryString).then((config) => {
        expect(config.krill_ws).toEqual('http://overridden_krill:35200');
      });
    });

    it('should overwrite when param is uppercase', () => {
      const queryString = 'KRILL_WS=http%3A%2F%2Foverridden_krill%3A35200';
      configService.loadPreconfiguration(<any>errorHandlerMock, queryString).then((config) => {
        expect(config.krill_ws).toEqual('http://overridden_krill:35200');
      });
    });

  });

});





