import {ErrorHandler, Injectable} from '@angular/core';
import {Headers, RequestOptions} from '@angular/http';
import 'rxjs/Rx';
import {Observable} from 'rxjs/Observable';
import {ApiClient} from '../api-client/api-client';
import {ErrorReporterService} from '../error-reporter/error-reporter.service';

const qs = require('querystring');

/**
 * This class provides the Configuration Service with methods to return values
 * from JSON config files, within a Promise.
 */

@Injectable()
export class ConfigurationService {

  private config: any = {};
  private preConfigUrl = 'assets/config/preConfig.json';
  private initialised = false;

  constructor(private apiClient: ApiClient) {

  }

  public isInitialised() {
    return this.initialised;
  }

  /**
   * Called by app.module.ts on application start-up;
   * Reads data from the config.preConfig.json file;
   * Sets config from JSON payload;
   */
  loadPreconfiguration(errorHandler: ErrorHandler, queryString: string): Promise<any> {

    return new Promise((resolve) => {
      this.setConfigFromSearchString(queryString);

      this.apiClient.get(this.preConfigUrl, null, false)
        .subscribe((config) => {
            this.mergeConfig(config);
            this.setErrorHandlerConfig(errorHandler, config);

            this.loadUnsecuredConfiguration().subscribe(
              (unsecuredConfig) => {
                this.mergeConfig(unsecuredConfig);
                this.initialised = true;
                resolve(this.config);
              },
              (error) => {
                this.logFailure(error);
                resolve({});
              });
          },
          (error) => {
            this.logFailure(error);
            resolve({});
          });
    });
  }

  private setConfigFromSearchString(queryString) {
    this.mergeConfig(qs.parse(queryString));
  }

  private mergeConfig(newConfig: any) {
    this.config = Object.assign({}, this.lowerCaseConfig(newConfig), this.config);
  }

  private logFailure(error) {
    console.error('Failed to get configuration:', error);
  }

  // This is a bit ugly, but necessary to ensure that the errorHandler has the lab api before the
  // application properly starts up (in order to report the error to the lab api)
  private setErrorHandlerConfig(errorHandler: ErrorHandler, config) {
    (<ErrorReporterService>errorHandler).labApiUrl = config.labapi_url;
  }


  private loadUnsecuredConfiguration(): Observable<any> {
    return this.apiClient.get(`${this.config.labapi_url}/Proc/$sysconfig`, this.buildHeaders(), false);
  }

  private lowerCaseConfig(config: any) {
    const result = {};

    if (config) {
      Object.keys(config).forEach((key) => {
        result[key.toLowerCase()] = config[key];
      });
    }

    return result;
  }

  private buildHeaders() {
    const headers = new Headers({'Content-Type': 'application/json'});
    return new RequestOptions({headers: headers});
  }

  public getConfig() {
    return this.config;
  }

}
