import {fakeAsync, tick} from '@angular/core/testing';

import {StatusService} from './status.service';
import {Observable} from 'rxjs/Observable';
import createSpy = jasmine.createSpy;
import Spy = jasmine.Spy;

describe('StatusService', () => {
  const LAB_API_URL = 'http://seahorse:9292';

  let service: StatusService;
  let apiClientMock: MockApiClient;
  let configMock: MockConfigService;
  let dateUtilMock: MockDateUtilService;

  class MockApiClient {
    get = createSpy('configMock').and.returnValue(Observable.of({}));
  }

  class MockConfigService {
    getConfig: Function;
  }

  class MockDateUtilService {
    getTimeMs: Spy;
  }

  beforeEach(() => {
    apiClientMock = new MockApiClient();
    dateUtilMock = new MockDateUtilService();
    configMock = new MockConfigService();
    configMock.getConfig = createSpy('configMock').and.returnValue({labapi_url: LAB_API_URL});
    service = new StatusService(<any>apiClientMock, <any>configMock, <any> dateUtilMock);
  });


  describe('Calling Ping', () => {
    const FAKE_PING_TIME = 1000;
    let currentTime;

    beforeEach(() => {
      currentTime = 0;
      dateUtilMock.getTimeMs = createSpy('getTimeMs').and.callFake(() => {
        currentTime += FAKE_PING_TIME;
        return currentTime;
      });
    });

    it('should call date utils to get start time and endtime', fakeAsync(() => {
      service.ping().subscribe(() => {
        expect(dateUtilMock.getTimeMs.calls.count()).toBe(2);
      });

      tick();
    }));

    it('should return an observable with the elapsed time in an object', fakeAsync(() => {
      service.ping().subscribe((result) => {
        expect(result.elapsedTime).toEqual(FAKE_PING_TIME);
      });

      tick();
    }));
  });

});
