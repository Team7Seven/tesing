import {Injectable} from '@angular/core';

@Injectable()
export class FileSaverService {
  save(fileName: string, contents: string, mediaType: string) {
    const blob = new Blob([contents], { type: mediaType});
    window['saveAs'](blob, fileName);
  }
}
