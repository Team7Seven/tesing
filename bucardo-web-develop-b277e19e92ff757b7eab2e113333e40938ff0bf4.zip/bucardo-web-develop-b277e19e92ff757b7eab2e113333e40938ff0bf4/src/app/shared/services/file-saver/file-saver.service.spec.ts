import {FileSaverService} from './file-saver.service';
import createSpy = jasmine.createSpy;

describe('FileSaverService', () => {

  it('should save file', () => {
    window['saveAs'] = createSpy('saveAs').and.callFake(() => {});
    const service = new FileSaverService();

    service.save('fileName', 'contents', 'mediaType');

    expect(window['saveAs']).toHaveBeenCalledTimes(1);
    const blob = new Blob(['contents'], { type: 'mediaType'});
    expect(window['saveAs']).toHaveBeenCalledWith(blob, 'fileName');
  });
});
