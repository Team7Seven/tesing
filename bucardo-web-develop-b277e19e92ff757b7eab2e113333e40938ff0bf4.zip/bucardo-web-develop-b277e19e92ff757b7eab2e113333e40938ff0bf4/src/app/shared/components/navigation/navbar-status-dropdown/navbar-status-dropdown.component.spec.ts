import {NavbarStatusDropdownComponent} from './navbar-status-dropdown.component';
import {fakeAsync, tick} from '@angular/core/testing';
import {Observable} from 'rxjs/Observable';
import Spy = jasmine.Spy;
import createSpy = jasmine.createSpy;

describe('NavbarStatusDropdownComponent', () => {
  const HEALTHY_PING_TIME = 100;
  const SLOW_PING_TIME = 700;
  const POLL_TIME = 5000;
  const ERROR_MESSAGE = 'ERROR_MESSAGE';

  let component: NavbarStatusDropdownComponent;

  let ngZoneMock: MockNgZone;
  let statusServiceMock: MockStatusService;
  let configServiceMock: MockConfigService;

  class MockNgZone {
    runOutsideAngular = createSpy('runOutsideAngular').and.callFake((fn) => fn());
    run = createSpy('run').and.callFake((fn) => fn());
  }

  class MockStatusService {
    ping: Spy;
  }

  class MockConfigService {
    getConfig = createSpy('getConfig').and.returnValue({
      labapi_url: 'http://someurl.com',
      w_ping: true,
      w_ping_slow: 500,
      w_ping_freq: 5000,
      w_ping_timeout: 5000
    });
  }

  beforeEach(() => {
    ngZoneMock = new MockNgZone();
    statusServiceMock = new MockStatusService();
    configServiceMock = new MockConfigService();
    component = new NavbarStatusDropdownComponent(<any>ngZoneMock, <any>statusServiceMock, <any>configServiceMock);
    setupPingTime(HEALTHY_PING_TIME);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should ping every 5000ms', fakeAsync(() => {
    setupPingTime(HEALTHY_PING_TIME);
    component.ngOnInit();

    tick(POLL_TIME * 4);

    component.ngOnDestroy();

    expect(statusServiceMock.ping).toHaveBeenCalledTimes(5); // Once at the start + 4 times
  }));

  it('should run the setInterval outside angular', fakeAsync(() => {
    component.ngOnInit();
    component.ngOnDestroy();
    expect(ngZoneMock.runOutsideAngular).toHaveBeenCalled();
  }));

  it('should run the result within angular', fakeAsync(() => {
    component.ngOnInit();
    tick(POLL_TIME);
    component.ngOnDestroy();
    expect(ngZoneMock.run).toHaveBeenCalled();
  }));

  describe('Healthy Status', () => {
    beforeEach(fakeAsync(() => {
      setupPingTime(HEALTHY_PING_TIME);
      component.ngOnInit();
      tick(POLL_TIME);
      component.ngOnDestroy();
    }));

    it('should set status to success', () => {
      expect(component.status).toEqual('dot-success');
    });

    it('should should set extraInfo to healthy message', () => {
      expect(component.extraInfo).toEqual('Link to ultra is healthy');
    });

    it('should set the ping time', () => {
      expect(component.pingTime).toEqual(HEALTHY_PING_TIME);
    });
  });


  describe('Slow Status', () => {
    beforeEach(fakeAsync(() => {
      setupPingTime(SLOW_PING_TIME);
      component.ngOnInit();
      tick(POLL_TIME);
      component.ngOnDestroy();
    }));

    it('should set status to warning', () => {
      expect(component.status).toEqual('dot-warning');
    });

    it('should should set extraInfo to slow message', () => {
      expect(component.extraInfo).toEqual('Link to ultra is slow');
    });

    it('should set the ping time', () => {
      expect(component.pingTime).toEqual(SLOW_PING_TIME);
    });
  });


  describe('Ping turned off', () => {
    beforeEach(fakeAsync(() => {
      configServiceMock.getConfig = createSpy('getConfig').and.returnValue({
        w_ping: false
      });

      component = new NavbarStatusDropdownComponent(<any>ngZoneMock, <any>statusServiceMock, <any>configServiceMock);

      component.ngOnInit();
      tick(POLL_TIME);
      component.ngOnDestroy();
    }));

    it('should not call status service', () => {
      expect(statusServiceMock.ping).not.toHaveBeenCalled();
    });
  });


  describe('Error Status', () => {
    beforeEach(fakeAsync(() => {
      setupPingError();
      spyOn(console, 'error');
      component.ngOnInit();
      tick(POLL_TIME);
      component.ngOnDestroy();
    }));

    it('should set status to error', () => {
      expect(component.status).toEqual('dot-danger');
    });

    it('should should set extraInfo to error message', () => {
      expect(component.extraInfo).toEqual('Ultra services down');
    });

    it('should set the ping time to empty', () => {
      expect(component.pingTime).toEqual('');
    });

    it('should log to console error', () => {
      expect(console.error).toHaveBeenCalled();
    });
  });

  function setupPingTime(pingTime: number) {
    statusServiceMock.ping = createSpy('pingSpy').and.returnValue(Observable.of({elapsedTime: pingTime}));
  }

  function setupPingError() {
    statusServiceMock.ping = createSpy('pingSpy').and.returnValue(Observable.throw(new Error(ERROR_MESSAGE)));
  }

});
