/* tslint:disable:no-unused-variable */
import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {NavbarComponent} from './navbar.component';
import {NavbarDataService} from './navbar-data-service';
import {Observable} from 'rxjs/Observable';
import {UserModel} from '../../../models/user.model';
import {UserService} from '../../../services/user/user.service';

describe('NavbarComponent', () => {
  let component: NavbarComponent;
  let fixture: ComponentFixture<NavbarComponent>;
  let userServiceMock: UserServiceMock;

  const validUser: UserModel = {
    resourceType: 'Login',
      token: 'MTQ4NTg1ODcwMTE0ODU4NTg3MD',
      code: 'bob',
      name: 'Bobert McBobertson',
      login_group: 'systems',
      lab: 'INV',
      department: 'SY',
      entry_type: 'S',
      library_entry: 'C',
      validation_level: '9',
      confidential_access: '*',
      login_time_out: '60',
      login_timeout_min: '60',
      login_timeout_warn_min: '60',
      validation_depts: '*',
      initials: 'ash',
      inquiry_log: 'N',
      login_type: ' ',
      status: 'A'
  };

  class UserServiceMock {
    user = Observable.of(validUser);
  }

  beforeEach(async(() => {
    userServiceMock = new UserServiceMock();

    TestBed.configureTestingModule({
      declarations: [NavbarComponent],
      providers: [NavbarDataService]
    }).overrideComponent(NavbarComponent, {
        set: {
          providers: [
            {provide: UserService, useValue: userServiceMock}
          ]
        }
      }
    ).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NavbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
