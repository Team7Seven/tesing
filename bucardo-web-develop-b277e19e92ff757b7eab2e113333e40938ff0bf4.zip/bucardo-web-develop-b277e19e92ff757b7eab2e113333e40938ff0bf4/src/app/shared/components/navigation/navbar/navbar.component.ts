import {Component} from '@angular/core';
import {NavbarDataService} from './navbar-data-service';
import {UserService} from '../../../services/user/user.service';
import {UserModel} from '../../../models/user.model';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent {

  user: UserModel;
  page: string;

  constructor(private navbarData: NavbarDataService, private userService: UserService) {
    navbarData.page.subscribe((page) => this.page = page);
    userService.user.subscribe((user) => this.user = user);
  }
}
