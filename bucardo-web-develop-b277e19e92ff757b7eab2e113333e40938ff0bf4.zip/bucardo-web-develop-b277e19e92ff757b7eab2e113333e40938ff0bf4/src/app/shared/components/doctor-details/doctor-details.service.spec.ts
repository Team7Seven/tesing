import {DoctorDetailsService} from './doctor-details.service';
import {async} from '@angular/core/testing';
import {DoctorDetailsModel} from './doctor-details.model';
import {Observable} from 'rxjs/Observable';
import {ConfigurationService} from '../../services/configuration/configuration.service';
import {ApiClient} from '../../services/api-client/api-client';
import Spy = jasmine.Spy;

describe('DoctorDetailsService', () => {

  class ApiClientMock {
    get: Spy;
  }

  const labApiUrl = 'http://labApiUrl:8000';
  const validId = '70';
  let configService: ConfigurationService;
  let apiClientMock: ApiClientMock;
  let doctorDetailsService: DoctorDetailsService;

  beforeEach(() => {
    apiClientMock = new ApiClientMock();
    configService = new ConfigurationService(<ApiClient><any>apiClientMock);
    doctorDetailsService = new DoctorDetailsService(<ApiClient><any>apiClientMock, configService);
    apiClientMock.get = jasmine.createSpy('get').and.returnValue(Observable.from([DoctorDetailsModel]));
  });

  it('should initialise DoctorDetailsService successfully', () => {
    expect(doctorDetailsService).toBeTruthy();
  });

  it('should return doctor details from GET call to Lab API', async(() => {
      doctorDetailsService.getDetails(validId).subscribe(
        () => {
          expect(apiClientMock.get).toHaveBeenCalledWith(`${this.labAPIUrl}/Doctor/${validId}`);
        }
      );
    })
  );


});





