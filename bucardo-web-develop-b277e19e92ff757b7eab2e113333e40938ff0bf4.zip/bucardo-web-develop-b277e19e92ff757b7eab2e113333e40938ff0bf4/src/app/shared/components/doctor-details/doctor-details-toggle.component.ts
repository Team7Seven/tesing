import {Component, Input, OnChanges} from '@angular/core';
import {DoctorDetailsModel} from './doctor-details.model';

@Component({
  selector: 'doctor-details-toggle',
  template: `
    <hr class="style-sidebar">
    <div class="overflow-scrolly-vertical-doctor-component">
     <div class="panel-body">
        <div class="row">
          <div class="col-sm-7">
            <div class="patient-request-doctor-panel-heading no-margin text-light" *ngIf="usualDoctorSelected">Usual Doctor</div>
            <div class="patient-request-doctor-panel-heading no-margin text-light" *ngIf="requestingDoctorSelected">Requesting Doctor</div>
          </div>
          <div class="col-sm-5 toggle-buttons">

            <button
              [ngClass]="{'invisible': !requestingDoctor, 'btn-info': requestingDoctorSelected && requestingDoctor}"
              class="btn btn-secondary btn-sm" [disabled]="!requestingDoctor" 
              (click)="show('requestingDoctorSelected')" aria-label="Requesting Doctor">
              <i class="fa fa-hospital-o fa-2x" aria-hidden="true" title="Requesting Doctor"></i>
            </button>
            <button [ngClass]="{'invisible': !usualDoctor, 'btn-info': usualDoctorSelected && usualDoctor}"
                    class="btn btn-secondary btn-sm" [disabled]="!usualDoctor" 
                    (click)="show('usualDoctorSelected')" aria-label="Usual Doctor">
              <i class="fa fa-user-md fa-2x" aria-hidden="true" title="Usual Doctor"></i>
            </button>
          </div>

        </div>

        <div *ngIf="usualDoctorSelected && usualDoctor">
          <doctor-details-data [doctor]="usualDoctor"></doctor-details-data>
        </div>

        <div *ngIf="requestingDoctorSelected && requestingDoctor">
          <doctor-details-data [doctor]="requestingDoctor"></doctor-details-data>
        </div>

      </div>
    </div>
  `,
  styles: [`
    .panel-body .toggle-buttons {
      text-align: right;
      padding: 0;
    }
    i.fa {
      font-size: 1.6em !important;
    }
  `]
})
export class DoctorDetailsToggleComponent implements OnChanges {
  @Input() usualDoctor: DoctorDetailsModel;
  @Input() requestingDoctor: DoctorDetailsModel;

  public usualDoctorSelected = false;
  public requestingDoctorSelected = true;

  ngOnChanges() {
    if (this.usualDoctor && !this.requestingDoctor) {
      this.usualDoctorSelected = true;
      this.requestingDoctorSelected = false;
    }

    if (this.requestingDoctor && !this.usualDoctor) {
      this.requestingDoctorSelected = true;
      this.usualDoctorSelected = false;
    }
  }

  show(tab) {

    if (tab === 'usualDoctorSelected' && this.usualDoctor) {
      this.requestingDoctorSelected = false;
      this.usualDoctorSelected = true;
    }
    if (tab === 'requestingDoctorSelected' && this.requestingDoctor) {
      this.usualDoctorSelected = false;
      this.requestingDoctorSelected = true;
    }
  }
}
