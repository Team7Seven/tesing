import {ActivatedRoute} from '@angular/router';
import {SocketClientComponent} from './socket-client.component';
import {ActivatedRouteStub} from '../../test-helpers/stubs';
import {KrillEventListenerService} from '../../services/krill-event-listener/krill-event-listener.service';

class MockRequestListenerService {
  registerSocketListener: Function;
}

let component: SocketClientComponent;
let mockRequestListenerService: MockRequestListenerService;

describe('App Component', () => {

  beforeEach(() => {
    mockRequestListenerService = new MockRequestListenerService();

    component = new SocketClientComponent(<KrillEventListenerService>mockRequestListenerService);
    mockRequestListenerService.registerSocketListener = jasmine.createSpy('regSockList');

  });

  it('Should add a BID passed in as a query parameter to local storage and make call to set up webSocket listener', () => {
    spyOn(localStorage, 'setItem');
    component.getBidFromQueryParamsAndAddToLocalStorage('bid=someBID');


    expect(localStorage.setItem).toHaveBeenCalledWith('BID', 'someBID');
    expect(mockRequestListenerService.registerSocketListener).toHaveBeenCalled();
  });

  it('Should not add BID to local storage if no query parameters are sent', () => {
    spyOn(localStorage, 'setItem');
    component.getBidFromQueryParamsAndAddToLocalStorage('');
    expect(localStorage.setItem).not.toHaveBeenCalled();
    expect(mockRequestListenerService.registerSocketListener).not.toHaveBeenCalled();
  });

});
