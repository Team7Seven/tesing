export interface SearchBoxItemModel {
  id: string;
  text: string;
  original?: any;
  selected?: boolean;
}
