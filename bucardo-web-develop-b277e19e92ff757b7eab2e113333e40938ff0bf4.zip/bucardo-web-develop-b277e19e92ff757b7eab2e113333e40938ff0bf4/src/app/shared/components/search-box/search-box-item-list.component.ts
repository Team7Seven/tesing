import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {SearchBoxItemModel} from './search-box-item.model';

const UP = 38;
const DOWN = 40;

@Component({
  selector: 'search-box-list',
  template: `
    <div *ngIf="visible" class="item-list" (focus)="focus()" (blur)="blur()" [class.drop-up]="dropUp"
         [ngStyle]="{'top.px': positionTop, 'bottom.px': positionBottom, 'left.px': positionLeft, 'max-width.px': listWidth}"
         tabindex="-1" #itemList>
      <ul [class.multiple]="multiple" role="listbox">
        <li *ngIf="filteredItems.length == 0" class="no-matching">No matching items</li>
        <li *ngFor="let item of filteredItems"
            (focus)="focus()"
            (click)="selectItem(item, true)"
            [class.selected]="item.selected"
            [attr.aria-selected]="item.selected"
            [class.highlight]="item.id === highlightItem"
            [value]="item.id"
            role="option">
          {{item.text}}
        </li>
      </ul>
    </div>
  `,
  styleUrls: ['search-box-item-list.component.scss']
})

export class SearchBoxItemListComponent implements OnInit {
  @Input() items: SearchBoxItemModel[] = [];
  @Input() filter = '';
  @Input() multiple;
  @Input() visible = false;
  @Input() serverSideFiltering = false;
  @Output() selectedChanged = new EventEmitter<Array<any>>();


  highlightIndex = -1;
  highlightItem: number;
  dropUp;
  filteredItems = [];
  selectedItems = [];
  maxItems = 10;
  inFocus = false;
  positionTop: number = -40000;
  positionLeft: number = -40000;
  listWidth: number;
  positionBottom: number;
  debug = false;

  constructor() {

  }

  ngOnInit() {
    this.items.forEach((i) => {
      if (!i.selected) {
        i.selected = false;
      }
    });
  }

  onFilterChange() {
    this.filterItems();
    if (!this.filteredItems || this.filteredItems.length === 0) {
      return;
    }
    if (!this.multiple) {
      if (this.dropUp) {
        this.highlightIndex = this.filteredItems.length - 1;
      } else {
        this.highlightIndex = 0;
      }
      this.highlightItem = this.filteredItems[this.highlightIndex].id;
    }
  }

  private filterItems() {
    this.filteredItems = this.items.slice(0, this.maxItems);
    if (this.serverSideFiltering) {
      return;
    }
    if (this.items && this.filter) {
      const upperFilter = this.filter.toUpperCase();

      this.filteredItems = this.items.filter((item) => {
        return item.text.toUpperCase().indexOf(upperFilter) !== -1;
      });

      this.filteredItems = this.filteredItems.slice(0, this.maxItems);
      return;
    }
  }

  hideList() {
    if (!this.debug) {
      this.visible = false;
    }
  }

  showList() {
    this.visible = true;
  }

  selectItem(item, emitEvent) {
    if (this.multiple) {
      item.selected = true;
      this.selectedItems.push(item);
    } else {
      this.selectedItems = [item];
    }

    this.hideList();
    if (emitEvent) {
      this.emitSelected();
    }
  }

  deselect(item) {
    this.selectedItems.splice(this.selectedItems.indexOf(item), 1);
    item.selected = false;
    this.emitSelected();
  }

  private emitSelected() {
    this.selectedChanged.emit(this.selectedItems);
  }


  handleOptionsNavigation(event) {
    if (!this.visible) {
      this.visible = true;
    }

    if (this.filteredItems && this.filteredItems.length) {
      event.preventDefault();
      if (event.keyCode === UP) {
        this.highlightIndex--;

        if (this.highlightIndex < 0) {
          this.highlightIndex = this.filteredItems.length - 1;
        }
      }

      if (event.keyCode === DOWN) {
        this.highlightIndex++;

        if (this.highlightIndex > (this.filteredItems.length - 1)) {
          this.highlightIndex = 0;
        }
      }

      this.highlightIndex = this.limitToRange(this.highlightIndex,
        0, this.filteredItems.length - 1);

      this.highlightItem = this.filteredItems[this.highlightIndex].id;
    }
  }

  private limitToRange(num: number, min: number, max: number): number {
    return Math.min(Math.max(num, min), max);
  }

  selectHighlighted() {
    if (this.highlightIndex > -1 && this.highlightIndex < (this.filteredItems.length)) {
      this.selectItem(this.filteredItems[this.highlightIndex], true);
    }
  }

  setListPosition(yPosition, xPosition, inputHeight) {
    if (this.dropUp) {
      this.positionTop = undefined;
      this.positionBottom = window.innerHeight - yPosition;
    } else {
      this.positionTop = yPosition + inputHeight;
    }
    this.positionLeft = xPosition;
  }

  setListWidth(width: number) {
    this.listWidth = width;
  }

  blur() {
    this.inFocus = false;
  }

  focus() {
    this.inFocus = true;
  }

  clearSelected(emit = true) {
    this.filter = '';
    this.onFilterChange();

    this.visible = false;

    this.items.forEach((item) => {
      item.selected = false;
    });

    this.selectedItems = [];

    if (emit) {
      this.emitSelected();
    }
  }
}
