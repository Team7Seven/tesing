import {Component, Input, OnChanges, SimpleChanges} from '@angular/core';
import {PatientDetailsModel} from './patient-details.model';
import * as moment from 'moment';
import {ConfigurationService} from '../../services/configuration/configuration.service';

@Component({
  selector: 'patient-details-data',
  templateUrl: `./patient-details-data.component.html`
})
export class PatientDetailsDataComponent implements OnChanges {

  @Input() patient: PatientDetailsModel;
  displayMrnIdentifierList: Boolean;

  constructor(private config: ConfigurationService) {
    this.displayMrnIdentifierList = config.getConfig().SHOW_MRN_LIST;
  }

  ngOnChanges(changes: SimpleChanges) {
    if ('patient' in changes && this.patient) {
      this.setAgeFromDob();
      this.setFormattedBirthdateFromDob();
      this.setGenderFromSexAbbrev();
      this.setAccountTypeDescriptionFromAccountTypeAbbrev();
    }
  }

  private setAgeFromDob() {
    const birthday = moment(this.patient.dob);
    const daysOld = moment().diff(birthday, 'days');

    if (daysOld < 14) {
      this.patient.age = daysOld;
      this.patient.age_units = 'days';
    } else if (daysOld < 60) {
      this.patient.age = moment().diff(birthday, 'weeks');
      this.patient.age_units = 'weeks';
    } else if (daysOld < 365 * 2) {
      this.patient.age = moment().diff(birthday, 'months');
      this.patient.age_units = 'months';
    } else {
      this.patient.age = moment().diff(birthday, 'years');
      this.patient.age_units = 'years';
    }
  }

  private setFormattedBirthdateFromDob() {
    this.patient.birthdate = moment(this.patient.dob).format('ll');
  }

  private setGenderFromSexAbbrev() {
    this.patient.gender = this.patient.sex === 'M' ? 'Male' : 'Female';
  }

  private setAccountTypeDescriptionFromAccountTypeAbbrev() {
    this.patient.account_type_desc = this.patient.account_type === 'P' ? 'Public' : '';
  }
}
