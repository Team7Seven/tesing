import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {PatientDetailsModel} from './patient-details.model';
import {ConfigurationService} from '../../services/configuration/configuration.service';
import {ApiClient} from '../../services/api-client/api-client';

@Injectable()
export class PatientDetailsService {
  labAPIUrl: string;

  constructor(private apiClient: ApiClient, private config: ConfigurationService) {
    this.labAPIUrl = config.getConfig().labapi_url;
  }

  getDetails(id: string): Observable<PatientDetailsModel> {
    return this.apiClient.get(`${this.labAPIUrl}/Patient/${id}`);
  }

}
