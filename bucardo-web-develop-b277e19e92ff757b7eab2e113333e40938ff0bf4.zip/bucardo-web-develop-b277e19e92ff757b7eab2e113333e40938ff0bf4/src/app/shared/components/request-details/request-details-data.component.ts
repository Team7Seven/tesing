import {Input, Component, DoCheck, ViewChild, OnInit} from '@angular/core';
import {RequestModel} from '../../models/request.model';
import {PatientDetailsModel} from '../patient-details/patient-details.model';
import {DoctorDetailsModel} from '../doctor-details/doctor-details.model';


@Component({
  selector: 'request-details-data',
  templateUrl: `./request-details-data.component.html`,

  styles: [`
    .specimen {
      padding: 4px 0;
    }
    
    .specimen .spec-container {
      text-align: center;
    }
    
    .specimen .collection-date {
      text-align: right;
    }
    
    .spec-wrap{
      margin-left:10px;
      margin-right: 10px;
      padding-right: 10px;
    }
    
    .spec-wrap.even {
      margin-left:10px;
      margin-right: 10px;
      padding-right: 10px;
      background-color: #f2f2f2 !important;
    }

    .specimen-list {
      margin-top: 8px;
      margin-bottom: 4px;
    }

    .toggle-specimens {
      text-align: right;
      margin-right: 0;
      padding-right: 10px;
      font-weight:bold;
      
      /* disable mouse-pointer highlight of anchor on click */
      -webkit-touch-callout: none;
      -webkit-user-select: none;
      -khtml-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
    }

    .request-details {
      height: 100%;
      margin-left: 0;
    }

    #specimen-container {
      overflow-y: scroll;
    }
    
    .specimen-type {
      text-align: right;
    }
    
    .panel-list.received span {
      font-weight: bold;
    }

    .req-subsection .row {
      margin-left: 0 !important;
    }
  `]
})
export class RequestDetailsDataComponent implements DoCheck {

  @Input() request: RequestModel;
  @Input() doctor: DoctorDetailsModel;
  @Input() patient: PatientDetailsModel;

  @ViewChild('specimenContainer') specimenContainer;

  isExpanded = false;
  specContainerMaxHeight: number;

  toggleExpand() {
    this.isExpanded = !this.isExpanded;
    this.calculateListHeight();
  }

  ngDoCheck() {
    if (!this.request) {
      this.isExpanded = false;
    }

    this.calculateListHeight();
  }

  private calculateListHeight() {
    if (this.specimenContainer) {
      const specContainer = this.specimenContainer.nativeElement;
      const container = specContainer.parentElement;

      this.specContainerMaxHeight = container.clientHeight - specContainer.offsetTop;
    }
  }
}
