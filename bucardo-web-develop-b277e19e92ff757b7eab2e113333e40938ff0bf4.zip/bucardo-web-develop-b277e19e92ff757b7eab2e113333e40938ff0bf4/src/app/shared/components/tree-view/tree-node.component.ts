import {Component, EventEmitter, Input, OnChanges, Output, SimpleChanges, ViewEncapsulation} from '@angular/core';
import {TreeNode} from './tree-view.model';

@Component({
  selector: 'tree-node',
  templateUrl: 'tree-node.component.html',
  styleUrls: ['tree-view.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class TreeNodeComponent implements OnChanges {
  @Input() nodes: Array<TreeNode>;
  @Output() onNodeToggled = new EventEmitter<TreeNode>();

  ngOnChanges(changes: SimpleChanges): void {
    if ('nodes' in changes) {
      this.nodes.forEach((node) => {
        node.checked = this.areAllChildrenChecked(node);
        node.partial = this.areSomeChildrenChecked(node);
      });
    }
  }

  private areAllChildrenChecked(node: TreeNode) {
    if (node.nodes && node.nodes.length > 0) {
      let checked = true;

      node.nodes.forEach((child) => {
        if (!this.areAllChildrenChecked(child)) {
          checked = false;
        }
      });

      return checked;
    } else {
      return node.checked;
    }
  }

  private areSomeChildrenChecked(node: TreeNode) {
    if (node.nodes && node.nodes.length > 0) {
      let partial = false;

      node.nodes.forEach((child) => {
        if (this.areSomeChildrenChecked(child)) {
          partial = true;
        }
      });

      return partial;
    } else {
      return node.checked;
    }
  }
}
