import {Component, OnInit, Renderer, ViewChild, ElementRef, HostListener} from '@angular/core';

@Component({
  selector: 'percentage-height',
  template: `
<div #host style="margin: 15px">
  <ng-content></ng-content>
</div>
`
})
// Can't test as code operates on component content and it's done using low level javascript
export class PercentageHeightComponent implements OnInit {

  @ViewChild('host') host: ElementRef;

  constructor(private renderer: Renderer) {}

  ngOnInit() {
    this.onResize({});
  }

  @HostListener('window:resize', ['$event'])
  onResize(event: any) {
    const windowHeight = window.innerHeight;
    let totalAvailableHeight = windowHeight - 5 - 46; // 5 class="matter" 46 top nav bar
    totalAvailableHeight -= this.getStyleValue(this.host.nativeElement, 'margin-bottom');
    totalAvailableHeight -= this.getStyleValue(this.host.nativeElement, 'margin-top');
    this.dfs(this.host.nativeElement, totalAvailableHeight);
  }

  // visiting html nodes using depth first search
  dfs(element: any, availableHeight: number) {
    this.renderer.setElementStyle(element, 'height', availableHeight + 'px');
    // minus auto element heights
    for (const elem of element.children){
      const attribute = elem.attributes['percentageHeight'];
      if (attribute == null) {
        availableHeight -= elem.getBoundingClientRect().height;
      }
      availableHeight -= this.getStyleValue(elem, 'margin-bottom');
      availableHeight -= this.getStyleValue(elem, 'margin-top');
    }
    // minus parent inner padding
    availableHeight -= this.getStyleValue(element, 'padding-bottom');
    availableHeight -= this.getStyleValue(element, 'padding-top');
    availableHeight -= this.getStyleValue(element, 'border-bottom-width');
    availableHeight -= this.getStyleValue(element, 'border-top-width');
    // calculate height
    for (const elem of element.children){
      const attribute = elem.attributes['percentageHeight'];
      if (attribute != null) {
        const percentage = attribute.value;
        const elementHeight = availableHeight * percentage / 100;
        this.dfs(elem, elementHeight);
      }
    }
  }

  private getStyleValue(element: any, property: string): number {
    const value = window.getComputedStyle(element, null).getPropertyValue(property);
    return this.parsePx(value);
  }

  private parsePx(value: string): number {
    if (value == null || value === '') {
      return 0;
    }
    const num = value.slice(0, value.length - 2);
    const result = +num;
    return result;
  }
}
