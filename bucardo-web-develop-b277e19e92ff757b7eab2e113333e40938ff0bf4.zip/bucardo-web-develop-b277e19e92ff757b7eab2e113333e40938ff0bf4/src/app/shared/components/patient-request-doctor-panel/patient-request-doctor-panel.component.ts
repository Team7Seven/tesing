import {Component, HostListener, Input, ViewChild, ViewContainerRef} from '@angular/core';
import {PatientDetailsDataComponent} from '../patient-details/patient-details-data.component';
import {DoctorDetailsToggleComponent} from '../doctor-details/doctor-details-toggle.component';

@Component({
  selector: 'patient-request-doctor-panel',
  template: `
      <div #detailsContainer class="fixed-height left-panel" style="margin-left:0">
          <patient-details-data #patientDetails
                                resize-detect (resize)="onResize()"
                                [patient]="patient"></patient-details-data>
          
          <request-details-data #requestDetails [request]="request" [doctor]="requestingDoctor"
                                [patient]="patient" [ngStyle]="\{'height.px': specimenContainerHeight}">
          </request-details-data>

          <doctor-details-toggle #doctorToggle
                                 resize-detect (resize)="onResize()" 
                                 *ngIf="usualDoctor || requestingDoctor" [usualDoctor]="usualDoctor"
                                 [requestingDoctor]="requestingDoctor"></doctor-details-toggle>
      </div>
  `,
  styleUrls: ['patient-request-doctor-panel.component.scss']
})
export class PatientRequestDoctorPanelComponent {
  @Input() patient;
  @Input() request;
  @Input() requestingDoctor;
  @Input() usualDoctor;

  @ViewChild('detailsContainer') detailsContainer;
  @ViewChild(PatientDetailsDataComponent, {read: ViewContainerRef}) patientDetailsComponent;
  @ViewChild(DoctorDetailsToggleComponent, {read: ViewContainerRef}) doctorDetailsComponent;

  specimenContainerHeight;

  @HostListener('window:resize', ['$event'])
  onResize() {
    if (this.componentsAreValid()) {
      this.calculateRequestDetailsHeight();
    }
  }

  private componentsAreValid() {
    return this.patientDetailsComponent && this.doctorDetailsComponent;
  }

  private calculateRequestDetailsHeight() {
    const patDetails = this.patientDetailsComponent.element.nativeElement;
    const docDetails = this.doctorDetailsComponent.element.nativeElement;
    this.specimenContainerHeight = this.detailsContainer.nativeElement.clientHeight -
      (patDetails.clientHeight + docDetails.clientHeight);
  }

}
