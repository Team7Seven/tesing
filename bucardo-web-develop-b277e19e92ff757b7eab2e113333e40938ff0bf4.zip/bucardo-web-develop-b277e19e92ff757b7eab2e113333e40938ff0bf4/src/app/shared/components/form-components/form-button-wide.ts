import {Component, Input} from '@angular/core';

@Component({
  selector: 'form-button-wide',
  template: `
    <div class="btn-group btn-group-justified {{wrapperClass}}">
        <div class="btn-group">
            <button [id]="buttonId" class="btn btn-primary" type="{{type}}" [disabled]="disabled">{{label}}</button>
        </div>
    </div>
  `
})
export class FormWideButtonComponent  {
  @Input() public label = '';
  @Input() public disabled = false;
  @Input() public type = '';
  @Input() public wrapperClass = '';
  @Input() public buttonId;
}
