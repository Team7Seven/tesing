import {Component, Input} from '@angular/core';

/***
 * A component that matches the style of a form, but for information only
 *
 * e.g. Modified : 12/10/2016 (ash)
 */

let identifier = 0;

@Component({
  selector: 'form-label-value',
  template: `
    <div class="form-group">
      <label class="control-label col-lg-3" *ngIf="label" [attr.for]="identifier">{{label}}</label>
      <div class="col-lg-9">
        <div class="form-control" readonly [id]="identifier">
          {{value}}
        </div>
      </div>
    </div>
  `,
})
export class FormNameValueComponent  {
  @Input() public label = '';
  @Input() public value = '';

  public identifier = `form-text-${identifier++}`;
}


