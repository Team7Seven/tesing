import {Component, Inject, Input, Optional, ViewChild, SimpleChanges, OnChanges, OnInit} from '@angular/core';
import {NG_ASYNC_VALIDATORS, NG_VALIDATORS, NG_VALUE_ACCESSOR, NgModel} from '@angular/forms';
import {ElementBase} from './form-helpers';

let identifier = 0;

/* tslint:disable:no-access-missing-member */
@Component({
  selector: 'form-select',
  template: `
    <div>
      <label *ngIf="label" [attr.for]="identifier">{{label}}</label>
      <select required
              [(ngModel)]="value"
              [ngClass]="{invalid: (invalid | async)}"
              class="form-control" data-style="btn-primary"
              [disabled]="disabled"
              [id]="identifier"
              [title]="placeholder">
        <option value="" disabled selected *ngIf="placeholder">{{placeholder}}</option>
        <ng-content></ng-content>
      </select>
      <validation
        *ngIf="invalid | async"
        [messages]="failures | async">
      </validation>
    </div>
  `,
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: FormSelectComponent,
    multi: true,
  }],
})
export class FormSelectComponent extends ElementBase<string> implements OnChanges, OnInit {
  @Input() public label: string;
  @Input() public placeholder: string;
  @Input() public inputId;
  @Input() public disabled: boolean;

  @ViewChild(NgModel) model: NgModel;

  public identifier;
  public ariaLabel = '';

  constructor(@Optional() @Inject(NG_VALIDATORS) validators: Array<any>,
              @Optional() @Inject(NG_ASYNC_VALIDATORS) asyncValidators: Array<any>) {
    super(validators, asyncValidators);
  }

  ngOnInit() {
    this.ariaLabel = this.getAriaLabel();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if ('inputId' in changes) {
      this.identifier = this.inputId || `form-text-${identifier++}`;
    }
  }
}


