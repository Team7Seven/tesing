import {Component, Input} from '@angular/core';

@Component({
  selector: 'form-button-right',
  template: `
    <div class="btn-group pull-right {{wrapperClass}}">
          <button [id]="buttonId" class="btn btn-primary" type="{{type}}" [disabled]="disabled">{{label}}</button>
    </div>
  `,
  styles: [`
    div.btn-group.pull-right {
      margin-top: 5px;
    }
  `]
})
export class FormButtonRightComponent  {
  @Input() public label = '';
  @Input() public disabled = false;
  @Input() public type = '';
  @Input() public wrapperClass = '';
  @Input() public buttonId;
}
