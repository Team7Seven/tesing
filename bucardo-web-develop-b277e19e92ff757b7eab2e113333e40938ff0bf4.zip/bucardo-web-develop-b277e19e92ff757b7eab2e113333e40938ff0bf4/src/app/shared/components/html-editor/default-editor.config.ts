export const DefaultEditorConfig = {
  language: 'en',
  toolbarLocation: 'top',
  toolbarCanCollapse: true,
  height: 200,
  skin: 'bootstrapck',
  font_defaultLabel: 'Courier New',
  fontSize_defaultLabel: '16pt', // approx = to 12pt = 10cpi print
  // The toolbar groups arrangement, optimized for two toolbar rows.
  extraPlugins: 'items,colorbutton,colordialog',
  toolbarGroups: [
    {name: 'items'},
    {name: 'clipboard', groups: ['clipboard', 'undo']},
    {name: 'editing', groups: ['find', 'selection', 'spellchecker']},
    {name: 'links'},
    {name: 'insert'},
    {name: 'forms'},
    {name: 'tools'},
    {name: 'document', groups: ['mode', 'document', 'doctools']},
    {name: 'others'},
    '/',
    {name: 'basicstyles', groups: ['basicstyles', 'cleanup']},
    {name: 'paragraph', groups: ['list', 'indent', 'blocks', 'align', 'bidi']},
    {name: 'styles'},
    {name: 'colors'}
  ],
  /* Image plugin removed until a repository of images is made available */
  removePlugins: 'image'
};
