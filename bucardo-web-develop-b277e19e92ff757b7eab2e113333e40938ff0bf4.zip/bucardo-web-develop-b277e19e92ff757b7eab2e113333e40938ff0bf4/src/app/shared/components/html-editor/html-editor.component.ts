import {Component, HostListener, Input, OnChanges, SimpleChanges, ViewChild} from '@angular/core';
import {DefaultEditorConfig} from './default-editor.config';
import {AbstractValueAccessor, MakeProvider} from '../../utils/abstract-value-accessor';
import {IdleCheckerService} from '../../services/idle-checker/idle-checker.service';

/* tslint:disable:no-access-missing-member max-line-length */
@Component({
  selector: 'html-editor',
  providers: [MakeProvider(HtmlEditorComponent)],
  template: `
      <div class="fill">
        <span>
            <p class="ruler">..0....v....1....v....2....v....3....v....4....v....5....v....6....v....7....X....8....v....9....v....0....1....v....2....v....3....v....4....v....</p>
            <div #parent id="editorParent" class="">
                <ckeditor #editor [(ngModel)]="value" [config]="config" [debounce]="500" (ready)="onEditorReady()"
                          (change)="onEditorChange($event)"></ckeditor>
            </div>
            
            <p class="ruler">..0....v....1....v....2....v....3....v....4....v....5....v....6....v....7....X....8....v....9....v....0....1....v....2....v....3....v....4....v....</p>
        </span>
      </div>
  `,
  styles: [`
      p.ruler {
          font-family: 'Courier new';
          font-size: 12pt;
          overflow-x: hidden;
      }

      #editorParent {
          height: calc(100vh - 130px);
      }

  `]
})
export class HtmlEditorComponent extends AbstractValueAccessor implements OnChanges {
  @Input() config = DefaultEditorConfig;
  @Input() readOnly = false;

  editorReady = false;
  needsResize = true;

  @ViewChild('editor') editor;
  @ViewChild('parent') parent;

  constructor(private idleCheckerService: IdleCheckerService) {
    super();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if ('readOnly' in changes) {
      this.setReadOnly();
    }
  }

  onEditorReady() {
    this.editorReady = true;
    this.editor.instance.setData(this.value, () => {
      this.setReadOnly(); // Needs to be in callback to work with IE
    });

    if (this.needsResize) {
      this.onResize();
    }
  }

  private setReadOnly() {
    if (this.editorReady) {
      this.editor.instance.setReadOnly(this.readOnly);
    }
  }

  public refreshEditorContent(): string {
    this.value = this.editor.instance.getData();
    return this.value;
  }

  public insertHtml(html: string) {
    if (this.editor.instance && this.editor.instance.status !== 'destroyed' && this.editorReady) {
      this.editor.instance.insertHtml(html);
    }
  }

  @HostListener('window:resize', ['$event'])
  public onResize() {
    // Need to check that instance hasn't been destroyed as units tests trigger
    // the resize event when new instances are created but destroyed instances
    // still exist that would cause to resize to throw an exception.
    if (this.editor.instance && this.editor.instance.status !== 'destroyed' && this.editorReady) {
      this.editor.instance.resize('100%', this.getWindowHeight());
    } else {
      this.needsResize = true;
    }
  }

  public onEditorChange() {
    this.idleCheckerService.resetTimers();
  }

  private getWindowHeight() {
    const height = window.getComputedStyle(this.parent.nativeElement, null).getPropertyValue('height');
    return height.slice(0, height.length - 2);
  }


}
