import {ChangeDetectorRef, Component, EventEmitter, Input, Output} from '@angular/core';
import {ApiClient} from '../../services/api-client/api-client';

const FileSaver = require('file-saver');

@Component({
  selector: 'pdf-display',
  template: `

      <div *ngIf="pdfData">
          <div class="pdf-tools">
              <span title="Rotate" (click)="rotatePdf()"><i class="fa fa-rotate-right fa-2x"></i></span>
              <span title="Download PDF" (click)="savePdf()"><i class="fa fa-download fa-2x"></i></span>
          </div>

          <div class="zoom-controls">
              <div title="Zoom in" (click)="zoomIn()"><i class="fa fa-plus-circle fa-3x"></i></div>
              <div title="Zoom out" (click)="zoomOut()"><i class="fa fa-minus-circle fa-3x"></i></div>
          </div>
      </div>

      <div class="ph100 overflow-scroll-both">
          <div class="text-center">
              <div *ngIf="loading" class="loading"><i class="fa fa-circle-o-notch fa-spin fa-5x"></i></div>
              <pdf-viewer *ngIf="pdfData"
                          [src]="pdfData"
                          [original-size]="true"
                          [show-all]="true"
                          [rotation]="rotation"
                          [zoom]="zoom"
                          [style.display]="'inline-block'"
                          (after-page-render-complete)="onPageRenderComplete($event)"
                          (after-load-complete)="loadingComplete.emit($event)">
              </pdf-viewer>
          </div>
      </div>

  `,
  styleUrls: ['pdf-display.component.scss']
})
export class PdfDisplayComponent {

  @Input() rotation = 0;
  @Input() zoom = 1;
  @Input() fileName = '';
  @Input() postData; // Used if we need to POST extra data when fetching PDF
  @Output() loadingComplete = new EventEmitter<any>();
  @Output() pdfLoadError = new EventEmitter<any>();

  pdfData: any;
  loading = true;

  private _pdfUrl;

  constructor(private apiClient: ApiClient, private changeDetector: ChangeDetectorRef) {
  }

  @Input()
  set pdfUrl(url) {
    this._pdfUrl = url;

    if (url) {
      this.loading = true;
      this.downloadPdf();
    } else {
      this.pdfData = null;
      this.loading = false;
    }

    // To prevent https://stackoverflow.com/questions/34364880/expression-has-changed-after-it-was-checked
    this.changeDetector.detectChanges();
  }

  private downloadPdf() {
    let fetchCall;

    if (this.postData) {
      fetchCall = this.apiClient.postAndExpectFile(this._pdfUrl, this.postData, 'application/json');
    } else {
      fetchCall = this.apiClient.getFile(this._pdfUrl, 'application/json');
    }

    fetchCall.subscribe(
      (data) => this.setPdfDataForViewer(data),
      (error) => this.pdfLoadError.emit(error)
    );
  }

  private setPdfDataForViewer(data) {
    const fileReader = new FileReader();
    fileReader.onload = () => {
      this.pdfData = {data: fileReader.result};
    };
    fileReader.readAsArrayBuffer(data);
  }

  rotatePdf() {
    this.rotation += 90;
    this.rotation %= 360;
  }

  zoomIn() {
    this.zoom += 0.2;
  }

  zoomOut() {
    this.zoom -= 0.2;
  }

  savePdf() {
    if (this.pdfData && this.pdfData.data) {
      const blob = new Blob([this.pdfData.data], {type: 'application/pdf'});
      FileSaver.saveAs(blob, this.fileName);
    }
  }

  onPageRenderComplete(event) {
    if (event.pageNumber === event.numPages) {
      this.loading = false;
    }
  }

}
