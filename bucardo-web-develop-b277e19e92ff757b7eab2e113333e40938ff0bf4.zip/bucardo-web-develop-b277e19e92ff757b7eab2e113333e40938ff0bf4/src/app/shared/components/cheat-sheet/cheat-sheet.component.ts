import {Component, HostListener} from '@angular/core';
import {CheatSheetModel} from './cheat-sheet.model';

@Component({
  selector: 'cheat-sheet',
template: `<div class="cfp-hotkeys-container fade in" *ngIf="display">
  <div class="cfp-hotkeys">
    <div>
      <h4 class="cfp-hotkeys-title">Keyboard Shortcuts (esc or ? to close):</h4>
    </div>
    <table>
      <tbody>
      <tr *ngFor="let item of items">
        <td class="cfp-hotkeys-keys">
          <span class="cfp-hotkeys-key">
            <div>
              Testing
            </div>
          {{ item.shortcut }}
          </span>
        </td>
        <td class="cfp-hotkeys-text">
          {{ item.description }}
        </td>
      </tr>
      </tbody>
    </table>
    <div class="cfp-hotkeys-close" (click)="toggleCheatSheet()">x</div>
  </div>
</div>
`,
  styleUrls: ['cheat-sheet.component.scss']
})
export class CheatSheetComponent {

  display = false;
  items: CheatSheetModel[] = [
    new CheatSheetModel('?', 'Show / hide this help menu'),
    new CheatSheetModel('l', 'Toggle left menu'),
    new CheatSheetModel('alt + s', 'Quick search'),
    new CheatSheetModel('a', 'Accept Result'),
    new CheatSheetModel('⇧ + a', 'Accept all visible results'),
    new CheatSheetModel('v', 'Send to validation'),
    new CheatSheetModel('←', 'Move to the previous specimen'),
    new CheatSheetModel('→', 'Move to the next specimen'),
    new CheatSheetModel('⇧ + →', 'Move to the next specimen page'),
    new CheatSheetModel('⇧ + ←', 'Move to the next specimen page'),
    new CheatSheetModel('↑', 'Move to the previous result'),
    new CheatSheetModel('↓', 'Move to the next result'),
    new CheatSheetModel('esc', 'Select code box'),
  ];

  toggleCheatSheet() {
    this.display = !this.display;
  }

  // TODO: before enabling this check the event target to ensure it is not a valid text input
  // @HostListener('window:keydown', ['$event'])
  key(event: KeyboardEvent) {
    if (event.shiftKey && event.key === '?') {
      this.toggleCheatSheet();
    }
  }
}
