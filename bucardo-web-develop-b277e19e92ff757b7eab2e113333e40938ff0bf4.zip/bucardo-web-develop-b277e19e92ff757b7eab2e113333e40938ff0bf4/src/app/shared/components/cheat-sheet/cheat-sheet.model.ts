export class CheatSheetModel {
  shortcut: string;
  description: string;

  constructor(shortcut: string, description: string) {
    this.shortcut = shortcut;
    this.description = description;
  }
}
