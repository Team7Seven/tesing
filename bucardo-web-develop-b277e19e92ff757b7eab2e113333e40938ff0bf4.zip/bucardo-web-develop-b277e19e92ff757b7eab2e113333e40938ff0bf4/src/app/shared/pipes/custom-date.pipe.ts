import {Pipe, PipeTransform} from '@angular/core';
import * as moment from 'moment';

@Pipe({name: 'ieDate'})
export class CustomDatePipe implements PipeTransform {

  transform(value, format) {
    if (!format) {
      format = 'll HH:mm';
    }

    if (moment(value, 'YYYY-MM-DDTHH:mm:ss.SS[.]SZ').isValid()) {
      return moment(value, 'YYYY-MM-DDTHH:mm:ss.SS[.]SZ').format(format);
    } else {
      return '';
    }
  }
}
