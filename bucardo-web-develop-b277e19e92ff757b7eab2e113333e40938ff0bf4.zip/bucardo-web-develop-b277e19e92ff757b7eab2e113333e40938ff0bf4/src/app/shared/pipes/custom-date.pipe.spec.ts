import {CustomDatePipe} from './custom-date.pipe';

describe('IE 10 compatible custom date Pipe', () => {
  let pipe: CustomDatePipe;

  beforeEach(() => {
    pipe = new CustomDatePipe();
  });

  it('should turn 2017-01-01 into Jan 1, 2017 with no format passed in (defaults to ll format)', () => {
    expect(pipe.transform('2017-01-01', null)).toEqual('Jan 1, 2017 00:00');
  });

  it('should turn 2017-01-01 into January 1, 2017 12:00 AM when the format LLL is passed in', () => {
    expect(pipe.transform('2017-01-01', 'LLL')).toEqual('January 1, 2017 12:00 AM');
  });

});
