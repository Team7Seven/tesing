import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'escapeHtml'})
export class EscapeHtmlPipe implements PipeTransform {
  transform(text: string): string {
    return text
      .replace(/&/g, '&amp;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;')
      .replace(/ /g, '&ensp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/\n/g, '<br/>');
  }
}
