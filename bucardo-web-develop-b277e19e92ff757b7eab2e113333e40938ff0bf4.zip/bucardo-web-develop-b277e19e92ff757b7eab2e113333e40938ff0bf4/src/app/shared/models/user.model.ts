export class UserModel {
  resourceType: string;
  token: string;
  code: string;
  name: string;
  login_group: string;
  lab: string;
  department: string;
  entry_type: string;
  library_entry: string;
  validation_level: string;
  confidential_access: string;
  login_time_out: string;
  validation_depts: string;
  initials: string;
  inquiry_log: string;
  login_type: string;
  status: string;
  login_timeout_min: string;
  login_timeout_warn_min: string;
}
