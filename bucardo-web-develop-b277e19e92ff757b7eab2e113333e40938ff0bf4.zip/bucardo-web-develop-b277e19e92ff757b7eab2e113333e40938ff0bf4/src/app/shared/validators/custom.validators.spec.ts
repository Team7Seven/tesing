import {CustomValidators} from './custom.validators';
import {FormControl} from '@angular/forms';

class InputOutput {
  input: any;
  output: any;

  constructor(input: any, output: any) {
    this.input = input;
    this.output = output;
  }
}

describe('CustomValidators', () => {

  it('should validate date', () => {
    const testCases = [new InputOutput('2000-10-20', null), new InputOutput('2000-10-2a', {date: true}),
      new InputOutput('', null), new InputOutput(null, null)];

    for (const testCase of testCases) {
      const control = new FormControl(testCase.input);
      const result = CustomValidators.validateDate(control);
      expect(result).toEqual(testCase.output, testCase.input);
    }
  });

  it('should validate time', () => {
    const testCases = [new InputOutput('14:15', null), new InputOutput('14:1a', {time: true}),
      new InputOutput('', null), new InputOutput(null, null)];

    for (const testCase of testCases) {
      const control = new FormControl(testCase.input);
      const result = CustomValidators.validateTime(control);
      expect(result).toEqual(testCase.output, testCase.input);
    }
  });

  it('should validate dateTime', () => {
    const testCases = [new InputOutput('2000-10-20T14:15', null), new InputOutput('2000-10-20T14:1a', {dateTime: true}),
      new InputOutput('', null), new InputOutput(null, null)];

    for (const testCase of testCases) {
      const control = new FormControl(testCase.input);
      const result = CustomValidators.validateDateTime(control);
      expect(result).toEqual(testCase.output, testCase.input);
    }
  });

  it('should validate number', () => {
    const testCases = [new InputOutput('3.14', null), new InputOutput('test', {number: true}),
      new InputOutput('', null), new InputOutput(null, null)];

    for (const testCase of testCases) {
      const control = new FormControl(testCase.input);
      const result = CustomValidators.validateNumber(control);
      expect(result).toEqual(testCase.output, testCase.input);
    }
  });

  it('should validate integer', () => {
    const testCases = [new InputOutput('3', null), new InputOutput('3.14', {integer: true}),
      new InputOutput('', null), new InputOutput(null, null)];

    for (const testCase of testCases) {
      const control = new FormControl(testCase.input);
      const result = CustomValidators.validateInteger(control);
      expect(result).toEqual(testCase.output, testCase.input);
    }
  });

  describe('No Space Validator', () => {
    it('should not allow only spaces', () => {
      const control = new FormControl('     ');
      const result = CustomValidators.notJustSpacesValidator(control);
      expect(result).toEqual({nospace: true});
    });

    it('should allow spaces if there are non-spaces', () => {
      const control = new FormControl('  Bob   ');
      const result = CustomValidators.notJustSpacesValidator(control);
      expect(result).toBeFalsy();
    });

    it('should not allow tabs', () => {
      const control = new FormControl('  \t\t   ');
      const result = CustomValidators.notJustSpacesValidator(control);
      expect(result).toEqual({nospace: true});
    });

    it('should not allow returns', () => {
      const control = new FormControl('  \n\n   ');
      const result = CustomValidators.notJustSpacesValidator(control);
      expect(result).toEqual({nospace: true});
    });

    it('should allow an empty string', () => {
      const control = new FormControl('');
      const result = CustomValidators.notJustSpacesValidator(control);
      expect(result).toBeFalsy();
    });


    it('should allow a null value', () => {
      const control = new FormControl(null);
      const result = CustomValidators.notJustSpacesValidator(control);
      expect(result).toBeFalsy();
    });
  });

});
