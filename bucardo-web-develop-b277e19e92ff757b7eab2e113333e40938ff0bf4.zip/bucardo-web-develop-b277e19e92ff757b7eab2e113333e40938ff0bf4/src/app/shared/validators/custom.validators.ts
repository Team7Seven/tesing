import {FormControl, AbstractControl} from '@angular/forms';
import * as moment from 'moment';

export class CustomValidators {

  private static isValueNullOrEmpty(control: FormControl) {
    return control.value == null || control.value === '';
  }

  static validateDate(control: FormControl) {
    if (CustomValidators.isValueNullOrEmpty(control)) {
      return null;
    }
    const datePattern = /^(\d{4})-(\d{1,2})-(\d{1,2})$/;
    return datePattern.test(control.value) ? null : {date: true};
  }

  static validateTime(control: FormControl) {
    if (CustomValidators.isValueNullOrEmpty(control)) {
      return null;
    }
    const timePattern = /^(\d{1,2}):(\d{1,2})$/;
    return timePattern.test(control.value) ? null : {time: true};
  }

  static validateDateTime(control: FormControl) {
    if (CustomValidators.isValueNullOrEmpty(control)) {
      return null;
    }
    const dateTimePattern = /^(\d{4})-(\d{1,2})-(\d{1,2})T(\d{1,2}):(\d{1,2})$/;
    return dateTimePattern.test(control.value) ? null : {dateTime: true};
  }

  static validateNumber(control: FormControl) {
    if (CustomValidators.isValueNullOrEmpty(control)) {
      return null;
    }
    const numberPattern = /^-?\d+(\.\d+)?$/;
    return numberPattern.test(control.value) ? null : {number: true};
  }

  static validateInteger(control: FormControl) {
    if (CustomValidators.isValueNullOrEmpty(control)) {
      return null;
    }
    const integerPattern = /[^-0-9\/]+/;
    return integerPattern.test(control.value) ? {integer: true} : null;
  }

  static notJustSpacesValidator(control: AbstractControl): { [s: string]: boolean } {
    const re = /^\s+$/;
    return (re.test(control.value)) ? {nospace: true} : null;
  }

  static maxIntSizeValidator(control: AbstractControl) {
    if (parseInt(control.value, 10) > 2147483647) {
      return {maxInt: true};
    }
  }

  static createDateFormatValidator(format: string, allowRelativeDates = false) {
    return function (c: FormControl) {

      if (moment(c.value, format, true).isValid()) {
        return null;
      }

      if (!allowRelativeDates) {
        return {
          dateFormat: {
            given: c.value,
            format: format,
            example: moment(new Date()).format(format)
          }
        };
      }

      const err = {
        dateFormat: {
          given: c.value,
          format: format,
          example: moment(new Date()).format(format)  + ' or as a relative date, for example: \'+2d\''
        }
      };

      const relativeDatePattern = /[+|-]\d+[d|m|y]/;

      return (relativeDatePattern.test(c.value)) ? null : err;
    };
  }
}


