import {
  Component, OnInit, OnDestroy, ViewChild, ElementRef, ChangeDetectorRef, Input
} from '@angular/core';
import {ManagementReportService} from './shared/management-report.service';
import {ManagementReportParameterModel} from './shared/management-report-parameter.model';
import {FileSaverService} from '../shared/services/file-saver/file-saver.service';
import {NavbarDataService} from '../shared/components/navigation/navbar/navbar-data-service';
import {PayloadDataService} from '../shared/services/payload-data/payload-data.service';
import {TreeNode} from './management-report-tree-view/tree-view.model';
import {Subscription} from 'rxjs/Subscription';
import {ToasterService} from 'angular2-toaster';
import {FormGroup} from '@angular/forms';
import {ManagementReportParametersComponent} from './management-report-parameters/management-report-parameters.component';

@Component({
  selector: 'management-report',
  templateUrl: 'management-report.component.html',
  providers: [ManagementReportService, FileSaverService],
  styles: [
      `#management-report-parameters h5 {
      text-align: center;
    }

    .management-report-parameters-container {
      height: 40vh;
      margin-top: 10px;
      padding: 5px;
      overflow-y: auto;
      overflow-x: hidden;
      margin-bottom: 0;
    }

    .management-report-parameters {
      height: calc(40vh - 100px);
      margin-top: 10px;
      padding: 5px;
      overflow-y: auto;
      overflow-x: hidden;
      margin-bottom: 50px;
    }

    #report-tree-container {
      height: calc(60vh - 100px);
      padding: 5px;
    }

    #tree-view-container {
      height: calc(100% - 100px);
      padding-bottom: 20px;
      margin-bottom: 20px
    }

    #left-column {
      height: calc(100vh - 60px);
      display: block;
      margin-top: 10px;
    }

    #right-column {
      height: calc(100vh - 60px);
      display: block;
      margin-top: 10px;
    }

    #right-panel {
      padding: 5px;
      margin-bottom: 0;
      height: calc(100% - 10px);
      overflow-y: auto;
      overflow-x: hidden;
    }

    .upload-delete-modify-btns-container {
      padding-bottom: 10px;
    }

    .submit-buttons {
      height: 45px;
      position: absolute;
      bottom: 10px;
      right: 10px;
      text-align: right;
    }

    #reset-button {
      height: 45px;
      position: absolute;
      bottom: 10px;
    }
    `
  ]
})
export class ManagementReportComponent implements OnInit, OnDestroy {
  @ViewChild('contentFrame') contentFrame: ElementRef;
  @ViewChild('fileUploader') fileUploader: ElementRef;
  @ViewChild(ManagementReportParametersComponent) paramsComponent;

  reportTreeNodes: Array<TreeNode>[];
  selectedReport: TreeNode = null;
  models: ManagementReportParameterModel[];
  report: string;
  query: string;
  permissions: any = {};
  iframeVisible = false;
  pdfViewerVisible = false;
  reportDesignName: String;
  uploadedFileName: String;
  templateFileToUpload: Blob;
  reportUploadObject: any = {};
  pdfUrl: string;
  pdfPostData: any;
  fileSaver = require('file-saver');
  loading: boolean;
  generatingReport = false;
  alphaNumericOnly = new RegExp('^\\s*([0-9a-zA-Z, .]+)\\s*$');
  reportDesignCodeIsValid: boolean;
  reportDesignNameIsValid: boolean;
  reportDesignCategoryIsValid: boolean;
  paramsAreLoading = false;
  isUpdatingDesign: boolean;
  form: FormGroup;
  documentType: String;

  private payloadDataSubscription: Subscription;

  constructor(private managementReportService: ManagementReportService,
              private navbarService: NavbarDataService,
              private payloadDataService: PayloadDataService,
              private toasterService: ToasterService,
              private changeDetector: ChangeDetectorRef) {
    navbarService.setPage('Management Reports');
  }

  ngOnInit(): void {
    this.payloadDataSubscription = this.payloadDataService.payloadData.subscribe(data => {
      if (this.loadManagementReports(data)) {
        this.managementReportService.getPermissions().subscribe((permissions) => {
          this.permissions = permissions;
          if (this.permissions.find) {
            this.fetchReports();
          } else {
            this.toasterService.pop('warning', 'You do not have permission to view this page');
          }
        });
      }
    });
  }

  handleFormUpdate(form: FormGroup) {
    this.form = form;
  }

  onReportSelected(reportNode) {
    this.paramsAreLoading = true;
    this.models = null;
    if (this.selectedReport && this.selectedReport.id === reportNode.selected.id) {
      this.selectedReport = null;
    } else {
      this.selectedReport = reportNode.selected;
    }

    this.hideReportContents();

    this.managementReportService.getParameters(reportNode.selected.id)
      .subscribe((response) => {
          this.models = response as Array<ManagementReportParameterModel>;
          this.paramsAreLoading = false;
        },
        (error) => {
          this.failedToLoadParameters();
          throw error;
        });

    // stop event propagating to the branch toggle
    reportNode.event.stopPropagation();
  }

  private failedToLoadParameters() {
    this.clearQuery();
  }

  onButtonClicked(documentType: string) {
    this.documentType = documentType;
    this.paramsComponent.onSubmit();
  }

  hideReportContents() {
    this.iframeVisible = false;
    this.pdfViewerVisible = false;
    this.generatingReport = false;
    this.loading = false;
    this.clearPdfData();
  }

  onNodeToggled(node) {
    node.expanded = !node.expanded;
  }

  fetchReports() {
    this.managementReportService.getAllReports().subscribe(
      (reports) => {
        const categories = {};

        reports.forEach((entry) => {
          const newNode = new TreeNode(entry.resource.code, 'report', entry.resource.name, entry, null);
          this.initialiseCategory(categories, entry);
          categories[entry.resource.category].nodes.push(newNode);
        });

        this.reportTreeNodes = Object.keys(categories).map((key) => {
          return categories[key];
        });
      }
    );
  }

  private initialiseCategory(categories, entry) {
    if (!categories[entry.resource.category]) {
      categories[entry.resource.category] = new TreeNode(entry.resource.category, 'category', entry.resource.category, null, null);
      categories[entry.resource.category].nodes = [];
    }
  }

  clearQuery() {
    if (this.query) {
      this.query = null;
    }

    this.selectedReport = null;
  }

  ngOnDestroy() {
    if (this.payloadDataSubscription) {
      this.payloadDataSubscription.unsubscribe();
    }
  }

  onParametersSave(event: any) {
    const params = this.formatParamsToArray(event.values);
    this.generatingReport = true;
    const reportId = event.reportId;

    if (this.documentType === 'Html') {
      this.generateHtmlReport(reportId, params);
    } else if (this.documentType === 'Pdf') {
      this.generatePdfReport(reportId, params);
    } else if (this.documentType === 'Xls') {
      this.generateXlsReport(reportId, params);
    }
  }

  private generateXlsReport(reportId: string, params: Array<any>) {
    this.managementReportService.generateReportFile(reportId, 'xls', params, 'application/vnd.ms-excel').subscribe(result => {
        this.hideReportContents();
        const blob = new Blob([result], {type: 'application/vnd.ms-excel'});
        this.fileSaver.saveAs(blob, this.selectedReport.name + '.xlsx');
        this.generatingReport = false;
      },
      (error) => {
        this.hideReportContents();
        throw error;
      });
  }

  private generatePdfReport(reportId: string, params: Array<any>) {
    this.setPdfPostData(reportId, params);
    this.pdfUrl = this.managementReportService.getRenderUrl();
    this.showPdfViewer();
  }

  private generateHtmlReport(reportId: string, params: Array<any>) {
    this.clearPdfData();
    this.hidePdfViewer();
    this.loading = true;
    this.managementReportService.generateReport(reportId, 'html', params).subscribe(result => {
        this.loading = false;
        this.changeDetector.detectChanges();
        this.setReportHtml(result);
        this.generatingReport = false;
      },
      (error) => {
        this.hideReportContents();
        throw error;
      });
  }

  pdfGenerated($event) {
    this.generatingReport = false;
  }

  onPdfLoadError() {
    this.hideReportContents();
    throw new Error('Failed to generate PDF report');
  }

  private hidePdfViewer() {
    this.pdfViewerVisible = false;
    this.iframeVisible = true;
  }

  private showPdfViewer() {
    this.iframeVisible = false;
    this.pdfViewerVisible = true;
  }

  private clearPdfData() {
    this.pdfUrl = null;
    this.pdfPostData = null;
  }

  private setPdfPostData(reportId, params: any) {
    this.pdfPostData = {
      template: reportId,
      format: 'pdf',
      params: params
    };
  }

  private formatParamsToArray(values) {
    const params = [];
    Object.keys(values).forEach((key) => {
      params.push({name: key, value: values[key]});
    });

    return params;
  }

  private loadManagementReports(data) {
    return (data && data.payload && data.payload.module === 'management-report')
      || (data && data.event && data.event === 'browser');
  }

  private setReportHtml(contents) {
    if (this.contentFrame) {
      const newDoc = this.contentFrame.nativeElement.contentWindow.document.open('text/html', 'replace');
      newDoc.write(contents);
      newDoc.close();
    }
  }

  fileChangeEvent(fileInput: any) {
    const fileList: FileList = fileInput.target.files;

    if (fileList.item(0) != null) {
      this.uploadedFileName = fileList.item(0).name;
      this.reportUploadObject.name = this.uploadedFileName;
      this.templateFileToUpload = fileList.item(0);
    } else {
      this.reportUploadObject.name = null;
      this.uploadedFileName = null;
      this.templateFileToUpload = fileList.item(0);
    }
  }

  retrieveFullReportTemplateForUpdateDelete(templateId) {
    this.managementReportService.getFullReportTemplateData(templateId).subscribe(result => {
      if (result) {
        this.reportUploadObject = result;
        this.uploadedFileName = this.reportUploadObject.name;
      }
    });
  }

  uploadTemplate() {
    this.isUpdatingDesign = false;
    const reader = new FileReader;
    reader.onloadend = (e) => {
      this.reportUploadObject = {
        resourceType: 'MngRptTemplate',
        code: this.reportUploadObject.code,
        style: '',
        name: this.reportUploadObject.name,
        ['class']: 'management',
        category: this.reportUploadObject.category,
        body: reader.result
      };
      if (this.validUploadFields()) {
        this.managementReportService.uploadReportTemplate(this.reportUploadObject).subscribe(result => {
          this.toasterService.pop('success', 'Successfully uploaded management report design: '
            + this.reportUploadObject.name + ' (' + this.reportUploadObject.code + ') ');
          this.unloadTemplate();
          this.fetchReports();
        }, err => {
          if (err.response.status === (422)) {
            this.toasterService.pop('error', 'Failed to upload: '
              + this.reportUploadObject.name + ' (' + this.reportUploadObject.code + ') ', 'This code already exists, please try another');
          } else {
            throw(err);
          }

          this.unloadTemplate();
        });
      }
    };

    if (this.templateFileToUpload != null) {
      reader.readAsText(this.templateFileToUpload);
    }
  }

  deleteTemplate() {
    this.managementReportService.deleteReportTemplate(this.selectedReport.id).subscribe(result => {
      this.fetchReports();
      this.toasterService.pop('success', 'Successfully deleted management report design: '
        + this.selectedReport.name + ' (' + this.selectedReport.id + ') ');
      this.selectedReport = null;
      this.unloadTemplate();
    }, err => {
      this.unloadTemplate();
      this.toasterService.pop('error', 'Failed to delete management report design: '
        + this.selectedReport.name + ' (' + this.selectedReport.id + ') ', ' ' + err.message);
    });
  }

  updateTemplate(templateId) {
    this.isUpdatingDesign = true;
    if (this.validUploadFields()) {
      this.managementReportService.updateReportTemplate(this.reportUploadObject).subscribe(result => {
          this.toasterService.pop('success', 'Successfully updated management report design: ' + this.reportUploadObject.code);
          this.unloadTemplate();
          this.fetchReports();
        }, err => {
          this.toasterService.pop('error', 'Failed to delete management report design: ' + this.reportUploadObject.code, ' ' + err.message);
          this.unloadTemplate();
        }
      );
    }
    this.isUpdatingDesign = false;
  }

  clearFileInputForIE(fileInput) {
    try {
      fileInput.value = '';
      if (fileInput.value) {
        fileInput.type = 'text';
        fileInput.type = 'file';
      }
    } catch (e) {
    }
  }

  unloadTemplate() {
    this.reportUploadObject = {};
    this.reportUploadObject.body = null;
    this.templateFileToUpload = null;
    this.uploadedFileName = null;
    this.fileUploader.nativeElement.value = '';
    this.clearFileInputForIE(document.getElementById('fileUploader'));
  }

  private validUploadFields(): Boolean {

    if (!this.isFieldWithinMaxLengthRange(this.reportUploadObject.code)) {
      this.toasterService.pop('warning', 'Code: exceeded maximum field length', 'Field must be 15 characters or less');
      return false;
    } else if (!this.isFieldWithinMaxLengthRange(this.reportUploadObject.category)) {
      this.toasterService.pop('warning', 'Category: exceeded maximum field length', 'Field must be 64 characters or less');
      return false;
    } else if (!this.isFieldWithinMaxLengthRange(this.reportUploadObject.name)) {
      this.toasterService.pop('warning', 'Name: exceeded maximum field length', 'Field must be 25 characters or less');
      return false;
    }

    this.reportDesignCodeIsValid = (this.alphaNumericOnly).test(this.reportUploadObject.code);
    this.reportDesignNameIsValid = (this.alphaNumericOnly).test(this.reportUploadObject.name);
    this.reportDesignCategoryIsValid = (this.alphaNumericOnly).test(this.reportUploadObject.category);

    if (!this.reportDesignCodeIsValid) {
      this.toasterService.pop('warning', 'Code: invalid character detected', 'Only A-Z, 0-9, ,. allowed');
      return false;
    } else if (!this.reportDesignNameIsValid) {
      this.toasterService.pop('warning', 'Name: invalid character detected', 'Only A-Z, 0-9, ,. allowed');
      return false;
    } else if (!this.reportDesignCategoryIsValid) {
      this.toasterService.pop('warning', 'Category: invalid character detected', 'Only A-Z, 0-9, ,. allowed');
      return false;
    }

    if (this.reportUploadObject.body != null) {
      if (this.reportUploadObject.category != null && this.reportUploadObject.name != null
        && this.reportUploadObject.code != null) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }

  private isFieldWithinMaxLengthRange(field: any): Boolean {
    switch (field) {
      case this.reportUploadObject.name: {
        return field.length <= 25;
      }
      case this.reportUploadObject.category: {
        return field.length <= 64;
      }
      case this.reportUploadObject.code: {
        return field.length <= 15;
      }
    }
  }

  ignoreEnter(event) {
    if (event.keyCode === 13) {
      event.stopPropagation();
      event.preventDefault();
      return;
    }
  }
}
