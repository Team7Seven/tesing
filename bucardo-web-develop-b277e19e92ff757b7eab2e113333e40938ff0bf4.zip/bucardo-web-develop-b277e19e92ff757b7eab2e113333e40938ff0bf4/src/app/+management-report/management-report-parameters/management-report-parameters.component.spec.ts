import {ManagementReportParametersComponent} from './management-report-parameters.component';
import {FormGroup} from '@angular/forms';
import {ManagementReportParameterModel} from '../shared/management-report-parameter.model';
import {ManagementReportService} from '../shared/management-report.service';

describe('ManagementReportParametersComponent', () => {

  // let fixture: ComponentFixture<ManagementReportParametersComponent>;
  let component: ManagementReportParametersComponent;

  class FormGroupMock {
    value: any;
    valid: boolean;
  }
  let formGroupMock: FormGroupMock;


  function getOffset() {
    let offset = (Math.floor((new Date().getTimezoneOffset()) / 60));

    let negative = false;

    if (offset <= 0) {
      negative = true;
      // turn number positive
      offset = 0 - offset;
    }

    let offsetString  = offset.toString();

    offsetString = offsetString + ':00';

    while (offsetString.length < 5) {
      offsetString = '0' + offsetString;
    }

    if (negative) {
      offsetString = '+' + offsetString;
    } else {
      offsetString = '-' + offsetString;
    }



    return offsetString;
  }


  const managementReportService = {
    getDateFormat: (_: any) => {
    }
  } as ManagementReportService;

  beforeEach(() => {
    component = new ManagementReportParametersComponent(managementReportService);
    component.reportId = 'test1';
    component.save.emit = jasmine.createSpy('emittingSave');
  });

  it('should submit when form is valid', () => {

    formGroupMock = new FormGroupMock;
    formGroupMock.value = {'name': '123'};
    formGroupMock.valid = true;
    component.paramsForm = <FormGroup><any>formGroupMock;
    component.documentType = 'Test';

    component.onSubmit();

    expect(component.save.emit).toHaveBeenCalledWith({ format: 'Test', reportId: 'test1', values: { 'name': '123'}});
  });

  it('should not submit when form is invalid', () => {


    formGroupMock = new FormGroupMock;
    formGroupMock.value = {'name': '123'};
    formGroupMock.valid = false;
    component.paramsForm = <FormGroup><any>formGroupMock;

    component.onSubmit();

    expect(component.save.emit).not.toHaveBeenCalled();
  });

  describe('handling date parameters', () => {
    let model1, model2, model3: ManagementReportParameterModel;
    beforeEach(() => {
      model1 = new ManagementReportParameterModel();
      model1.dataType = 'TYPE_DATE';
      model1.name = 'testDate1';

      model2 = new ManagementReportParameterModel();
      model2.dataType = 'TYPE_DATE_TIME';
      model2.name = 'testDate2';

      model3 = new ManagementReportParameterModel();
      model3.dataType = 'STRING';
      model3.name = 'testString';

      component.models = [model1, model2, model3];
      component.storeDateParams();
    });

    it('determines whether or not a parameter is a date object', () => {
      expect(component.isDateType('TYPE_DATE')).toBeTruthy();
      expect(component.isDateType('TYPE_STRING')).toBeFalsy();
    });

    it('copies date params into an object with the control name as the key and model as value', () => {
      expect(component.dateParams).toEqual({'testDate1': model1, 'testDate2': model2});
    });

    it ('transforms a date into a FHIR formatted date string', () => {
      formGroupMock = new FormGroupMock;
      formGroupMock.value = {
        'testDate1': new Date(`2017-07-18 00:00:00` + getOffset()),
        'testDate2': new Date(`2017-07-19 00:00:00` + getOffset())
      };
      formGroupMock.valid = true;
      component.paramsForm = <FormGroup><any>formGroupMock;
      component.transformDatesToFhirStandard();

      expect(component.paramsForm.value['testDate1'])
        .toEqual('2017-07-18T00:00:00.0' + getOffset());
      expect(component.paramsForm.value['testDate2'])
        .toEqual('2017-07-19T00:00:00.0' + getOffset());
    });

  });
});
