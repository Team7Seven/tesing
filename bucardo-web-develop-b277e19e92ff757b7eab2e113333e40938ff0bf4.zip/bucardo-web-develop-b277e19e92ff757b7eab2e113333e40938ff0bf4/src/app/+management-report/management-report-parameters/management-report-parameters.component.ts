import {Component, Input, Output, EventEmitter, OnChanges, SimpleChanges, OnInit, HostListener} from '@angular/core';
import {FormControl, FormGroup} from '@angular/forms';
import {ManagementReportParameterModel} from '../shared/management-report-parameter.model';
import * as moment from 'moment';
import {ManagementReportService} from '../shared/management-report.service';

@Component({
  selector: 'management-report-parameters',
  template: `
    <form *ngIf="paramsForm != null" [formGroup]="paramsForm" (submit)="onSubmit()">
      <div class="col-xs-12">
        <div>
          <management-report-control
            *ngFor="let model of models"
            [form]="paramsForm"
            [model]="model"
            [controlModel]="controlModels[model.name]"
            [documentType]="documentType">
          </management-report-control>
        </div>
      </div>
    </form>
  `
})
export class ManagementReportParametersComponent implements OnChanges, OnInit {

  @Input() reportId: string;
  @Input() models: ManagementReportParameterModel[];
  @Input() generatingReport = false;
  @Input() documentType: String;
  @Output() save = new EventEmitter<any>();
  @Output() paramsFormEmitter = new EventEmitter<FormGroup>();

  paramsForm: FormGroup;
  dateParams = {};
  controlModels: any = {};

  ngOnInit() {
    this.modelsToFormGroup();
  }

  constructor(private managementReportService: ManagementReportService) {
  }

  ngOnChanges(changes: SimpleChanges): void {
    if ('models' in changes) {
      this.storeDateParams();
      this.modelsToFormGroup();
      this.paramsFormEmitter.emit(this.paramsForm);
    }
  }

  modelsToFormGroup() {
    if (this.models) {
      const group = {};
      this.models.forEach((model) => {
        const controlModel = this.managementReportService.convertParamToControlProperties(model);
        group[model.name] = new FormControl(controlModel.value,
          this.managementReportService.getValidators(model));
        group[model.name].markAsUntouched();
        this.controlModels[model.name] = controlModel;
      });

      this.paramsForm = new FormGroup(group);
    }
  }

  resetModelsToDefault() {
    this.models.forEach((model) => {
      this.managementReportService.setDefaultAndInitialValue(model, this.controlModels[model.name]);
    });
  }

  onSubmit(): void {
    if (this.paramsForm.valid) {
      this.transformDatesToFhirStandard();
      this.paramsFormEmitter.emit(this.paramsForm);
      this.save.emit({format: this.documentType, reportId: this.reportId, values: this.paramsForm.value});
    }
  }

  resetParams(event) {
    event.preventDefault();
    const controlNames = Object.keys(this.paramsForm.controls);
    controlNames.forEach((name) => {
      this.paramsForm.controls[name].patchValue(this.controlModels[name].defaultValue);
    });
    this.paramsForm.markAsUntouched();
    this.paramsForm.markAsPristine();
  }

  storeDateParams() {
    if (!this.models) {
      return;
    }
    this.dateParams = {};
    this.models.forEach((model) => {
      if (this.isDateType(model.dataType)) {
        this.dateParams[model.name] = model;
      }
    });
  }

  isDateType(type) {
    return (type === 'TYPE_DATE' || type === 'TYPE_DATE_TIME' || type === 'TYPE_TIME');
  }

  transformDatesToFhirStandard() {
    Object.keys(this.dateParams).forEach((paramName) => {
      if (this.paramsForm.value[paramName] instanceof Date) {
        const momentDate = moment(this.paramsForm.value[paramName]);
        this.paramsForm.value[paramName] = momentDate.format('YYYY-MM-DD[T]HH:mm:ss[.]SZ');
      }
    });
  }
}
