import {TreeViewComponent} from './tree-view.component';
import Jasmine = jasmine.Jasmine;
import {SimpleChange, SimpleChanges} from '@angular/core';
import {TreeNode} from './tree-view.model';

describe('TreeViewComponent', () => {

  let component: TreeViewComponent;

  beforeEach(() => {
    component = new TreeViewComponent();
  });

  it('should create component', () => {
    expect(component).toBeTruthy();
  });

  describe('when ngOnChanges called', () => {

    beforeEach(() => {
      spyOn(component, 'onFilterChanged').and.callThrough();
    });

    it('calls on filter changed when query is passed in as a change', () => {
      const changes = {query : new SimpleChange('', 'something')} as SimpleChanges;
      component.ngOnChanges(changes);
      expect(component.onFilterChanged).toHaveBeenCalled();
    });

    it('calls on filter changed when nodes is passed in as a change', () => {
      const changes = {nodes : new SimpleChange([], [{}, {}])} as SimpleChanges;
      component.ngOnChanges(changes);
      expect(component.onFilterChanged).toHaveBeenCalled();
    });

  });

  describe('when onFilterChanged is called', () => {
    beforeEach(() => {
      component.nodes = [
        new TreeNode(1, 'test', 'test', 'none', [
          new TreeNode(2, 'test', 'test', 'none'),
          new TreeNode(3, 'pass', 'test', 'none'),
          new TreeNode(4, 'test', 'test', 'none'),
        ]),
        new TreeNode(1, 'other', 'other', 'none', [
          new TreeNode(3, 'pass', 'pass', 'none'),
        ])
      ];
    });

    it ('should set filteredNodes to the same as nodes when no filter passed in', () => {
      component.query = '';
      component.onFilterChanged();

      expect(component.filteredNodes).toEqual(component.nodes);
    });

    it ('should filter out everthing when a non matching query supplied', () => {
      component.query = 'fail';
      component.onFilterChanged();

      expect(component.filteredNodes).toEqual([]);
    });

    it ('should filter out all except one when a matching query supplied', () => {
      component.query = 'pass';
      component.onFilterChanged();

      expect(component.filteredNodes.length).toEqual(1);
    });
  });

  describe('onReportSelected', () => {

    it ('should set the selectedReport parameter to the id of report object passed in', () => {
      component.onReportSelected({selected: {id: 123}});
      expect(component.selectedId).toEqual(123);
    });

    it ('should bubble up the paramter passed in to reportSelected event emitter', () => {
      component.onReportSelected({selected: {id: 123}});

      let emitted = false;
      component.reportSelected.subscribe(x => {
        emitted = true;
        expect(x).toEqual({selected: {}, event: {}});
      });

      component.onReportSelected({selected: {}, event: {}});

      expect(emitted).toBeTruthy();
    });
  });

});

