import {TreeNodeComponent} from './tree-node.component';

describe('TreeNodeComponent', () => {

  let component: TreeNodeComponent;

  beforeEach(() => {
    component = new TreeNodeComponent();
  });

  it('should create component', () => {
    expect(component).toBeTruthy();
  });


  describe('selected method', () => {
    it('should emit a nodeToggled event when the selected method when object with nodes passed in', () => {

      let emitted = false;
      const dir = {nodes: []};
      component.onNodeToggled.subscribe(x => {
        emitted = true;
        expect(x).toEqual(dir);
      });

      component.selected(dir, {});
      expect(emitted).toBeTruthy();

    });

    it('should emit a reportSelected event with the click $event added to it when the dir object without nodes passed in', () => {
      let emitted = false;
      const dir = {};
      component.reportSelected.subscribe(x => {
        emitted = true;
        expect(x).toEqual({selected: dir, event: {}});
      });

      component.selected(dir, {});
      expect(emitted).toBeTruthy();
    });

    it('should emit a reportSelected event with the dir parameter unmodified when the object without nodes and with an ' +
      '$event objct is passed in', () => {
      let emitted = false;
      const dir = {event: {}, selected: {}};
      component.reportSelected.subscribe(x => {
        emitted = true;
        expect(x).toEqual(dir);
      });

      component.selected(dir, null);
      expect(emitted).toBeTruthy();
    });


  });

});

