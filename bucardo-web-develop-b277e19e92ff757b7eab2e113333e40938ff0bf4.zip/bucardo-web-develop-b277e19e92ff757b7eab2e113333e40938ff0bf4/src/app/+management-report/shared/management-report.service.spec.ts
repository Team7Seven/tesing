import {async, fakeAsync, tick} from '@angular/core/testing';
import {Observable} from 'rxjs/Observable';
import createSpy = jasmine.createSpy;
import {ConfigurationService} from '../../shared/services/configuration/configuration.service';
import {ApiClient} from '../../shared/services/api-client/api-client';
import {ManagementReportService} from './management-report.service';
import any = jasmine.any;
import {ManagementReportParameterModel} from './management-report-parameter.model';
import {Validators} from '@angular/forms';
import {ManagementReportControlModel} from './management-report-control.model';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {UserModel} from '../../shared/models/user.model';
import {UserService} from '../../shared/services/user/user.service';

describe('Service: ManagementReportService', () => {

  const validReportResponse = {'resourceType': 'foo', 'type': 'bar',
    'entry': [{'resource': {'resourceType': 'MngRptTemplate', 'code': 'mng_1', 'name': 'Management Report One', 'class': 'management',
      'category': 'Report Cat 1', 'meta': {'versionId': 'mng_1_00010101000000', 'lastUpdated': '0001-01-01T00:00:00Z',
        'eTag': 'W\/\'mng_1_00010101000000\'', 'opr': 'paulac', 'oprName': 'paulac'}}}]};

  const validReportTemplate =  {
    resourceType: 'MngRptTemplate',
    code: 'A1',
    style: 'Style',
    name: 'Name',
    ['class']: 'management',
    category: 'CAT7E',
    body: '<?xml version="1.0" encoding="UTF-8"?> <report> </report>'
  };

  const invalidReportTemplate = {
    resourceType: 'MngRptTemplate',
    code: 'Z1',
    style: '',
    name: '',
    ['class']: 'management',
    category: 'CAT7E'
  };

  let apiClientMock: ApiClientMock;
  let userServiceMock: UserServiceMock;
  let configService: ConfigurationService;
  let managementReportService: ManagementReportService;
  const managementReportModel = new ManagementReportParameterModel();
  const LOGGED_IN_USER = 'Zlatan';
  const validUser: UserModel = {
    resourceType: 'Login',
    token: 'MTQ4NTg1ODcwMTE0ODU4NTg3MD',
    code: LOGGED_IN_USER,
    name: 'Bobert McBobertson',
    login_group: 'systems',
    lab: 'INV',
    department: 'SY',
    entry_type: 'S',
    library_entry: 'C',
    validation_level: '9',
    confidential_access: '*',
    login_time_out: '60',
    login_timeout_min: '60',
    login_timeout_warn_min: '60',
    validation_depts: '*',
    initials: 'ash',
    inquiry_log: 'N',
    login_type: ' ',
    status: 'A'
  };

  class ApiClientMock {
    put = createSpy('api put').and.returnValue(Observable.of(any));
    get = jasmine.createSpy('get').and.returnValue(Observable.from([validReportResponse]));
    post = createSpy('post').and.returnValue(Observable.of(any));
    delete = createSpy('delete').and.returnValue(Observable.of(any));
  }

  class UserServiceMock {
    user = Observable.of(validUser);
  }

  beforeEach(() => {
    apiClientMock = new ApiClientMock();
    configService = new ConfigurationService(<ApiClient><any>apiClientMock);
    userServiceMock = new UserServiceMock();
    managementReportService = new ManagementReportService(
      <ApiClient><any>apiClientMock,
      <ConfigurationService><any>configService,
      <UserService><any>userServiceMock);
  });

  it('should initialise ManagementReportService successfully', () => {
        expect(managementReportService).toBeTruthy();
  });

  it('should return reports from GET call to Lab API', async(() => {
      managementReportService.getAllReports().subscribe(
        () => {
          expect(apiClientMock.get).toHaveBeenCalledWith(`${this.labAPIUrl}/MngRptTemplate?_summary=short`);
        }
      );
    })
  );

  it('should return report template JSON object when POSTing valid report template', fakeAsync(() => {
    managementReportService.uploadReportTemplate(validReportTemplate).subscribe((response) => {
      expect(response.body);
    });
    tick();
  }));

  it('should return http 500 error when POSTing invalid report template', fakeAsync(() => {
    managementReportService.uploadReportTemplate(invalidReportTemplate).subscribe((response) => {
      expect(response.httpCode === 500);
    });
    tick();
  }));

  describe('when returning full report template data (for updating existing report)', () => {
    it('should call API with PUT for valid report design', () => {
      managementReportService.getFullReportTemplateData(validReportTemplate.code);
      expect(apiClientMock.get)
        .toHaveBeenCalledWith(`${this.labAPIUrl}/MngRptTemplate/${validReportTemplate.code}`);
    });

    it('API call should fail (500) with GET call for invalid report code', () => {
      managementReportService.getFullReportTemplateData('ThisReportDoesNotExist').subscribe((response) => {
        expect(response.httpCode === 500);
      });
    });
  });

  describe('when modifying an existing mng rpt template', () => {
    beforeEach(() => {
      managementReportService.getAllReports().subscribe(
        () => {
          expect(apiClientMock.get).toHaveBeenCalledWith(`${this.labAPIUrl}/MngRptTemplate?_summary=short`);
        }
      );
    });

    it('should call API with PUT for valid report design', () => {
      managementReportService.updateReportTemplate(validReportTemplate);
      expect(apiClientMock.put)
        .toHaveBeenCalledWith(`${this.labAPIUrl}/MngRptTemplate/${validReportTemplate.code}`, validReportTemplate, LOGGED_IN_USER);
    });

    it('API call should fail (500) with PUT call for invalid report design', fakeAsync(() => {
      managementReportService.uploadReportTemplate(invalidReportTemplate).subscribe((response) => {
        expect(response.httpCode === 500);
      });
      tick();
    }));
  });

  describe('when deleting an existing mng rpt template', () => {
    beforeEach(() => {
      managementReportService.getAllReports().subscribe(
        () => {
          expect(apiClientMock.get).toHaveBeenCalledWith(`${this.labAPIUrl}/MngRptTemplate?_summary=short`);
        }
      );
    });

    it('should call API with DELETE', () => {
      managementReportService.deleteReportTemplate(validReportTemplate.code);
      expect(apiClientMock.delete)
        .toHaveBeenCalledWith(`${this.labAPIUrl}/MngRptTemplate/${validReportTemplate.code}`);
    });

    it('API call should fail (500) with DELETE call for invalid report code', fakeAsync(() => {
      managementReportService.deleteReportTemplate('HELLO DARKNESS MY OLD FRIEND').subscribe((response) => {
        expect(response.httpCode === 500);
      });
      tick();
    }));
  });

  describe('getting date format', () => {
    it('should get the correct format when \'Long Date\' is specified', () => {
      managementReportModel.displayFormat = 'Long Date';
      const format = managementReportService.getDateFormat(managementReportModel );

      expect(format).toEqual('D MMMM[,] YYYY');
    });
    it('should get the correct format when \'Medium Date\' is specified', () => {
      managementReportModel.displayFormat = 'Medium Date';
      const format = managementReportService.getDateFormat(managementReportModel );

      expect(format).toEqual('D MMM YYYY');
    });
    it('should get the correct format when \'Short Date\' is specified', () => {

      managementReportModel.displayFormat = 'Short Date';
      const format = managementReportService.getDateFormat(managementReportModel );

      expect(format).toEqual('DD/MM/YYYY');
    });

    it('should get the correct format when no format is specified but type is TYPE_DATE', () => {
      managementReportModel.displayFormat = '';

      managementReportModel.dataType = 'TYPE_DATE';
      const format = managementReportService.getDateFormat(managementReportModel );

      expect(format).toEqual('Do MMMM, YYYY');
    });

    it('should get the correct format when no format is specified but type is TYPE_TIME', () => {
      managementReportModel.displayFormat = '';
      managementReportModel.dataType = 'TYPE_TIME';
      const format = managementReportService.getDateFormat(managementReportModel );

      expect(format).toEqual('HH:mm');
    });

    it('should get the correct format when no format and is specified but type is TYPE_DATE_TIME', () => {
      managementReportModel.displayFormat = '';
      managementReportModel.dataType = 'TYPE_DATE_TIME';
      const format = managementReportService.getDateFormat(managementReportModel);

      expect(format).toEqual('Do MMMM, YYYY HH:mm');
    });
  });

  describe('adding validators', () => {

    let model: ManagementReportParameterModel;

    beforeEach(() => {
      model = new ManagementReportParameterModel();
    });

    it('should add required validator if field is required', () => {
      model.required = 'Yes';
      expect(managementReportService.getValidators(model)).toEqual([Validators.required]);
    });

    it('should not add required validator if field is not required', () => {
      model.required = 'No';
      expect(managementReportService.getValidators(model)).toEqual([]);
    });
  });

  describe('assigning control properties', () => {

    let model: ManagementReportParameterModel;
    let controlModel: ManagementReportControlModel;

    beforeEach(() => {
      model = new ManagementReportParameterModel();
      controlModel = new ManagementReportControlModel();
    });

    it('should set the control as a multiple input when multi-value is provided', () => {
      model.parameterType = 'multi-value';
      controlModel = managementReportService.convertParamToControlProperties(model);
      expect(controlModel.multiple).toBeTruthy();
    });

    it('should set the control as hidden when specified by model', () => {
      model.hidden = 'Yes';
      controlModel = managementReportService.convertParamToControlProperties(model);
      expect(controlModel.hidden).toBeTruthy();
    });

    it('should set the control label to the model promptText when supplied', () => {
      model.promptText = 'Test Text';
      model.name = 'Test Text 3';
      controlModel = managementReportService.convertParamToControlProperties(model);
      expect(controlModel.label).toEqual(model.promptText);
    });

    it('should set the control label to the model name  when  promptText not supplied', () => {
      model.name = 'Test Text 3';
      controlModel = managementReportService.convertParamToControlProperties(model);
      expect(controlModel.label).toEqual(model.name);
    });

    it('should set the control name to the model name', () => {
      model.name = 'Test Text 3';
      controlModel = managementReportService.convertParamToControlProperties(model);
      expect(controlModel.name).toEqual(model.name);
    });

    it('should set the control property required', () => {
      model.required = 'Yes';
      controlModel = managementReportService.convertParamToControlProperties(model);
      expect(model.required).toBeTruthy();
    });

    describe('getting default value', () => {
      it('should set the default value to that passed in', () => {
        model.defaultValue = 'Test Text 3';
        controlModel = managementReportService.convertParamToControlProperties(model);
        expect(controlModel.value).toEqual(model.defaultValue);
      });

      describe('no defaultValue provided on param model', () => {
        beforeEach(() => {
          model.defaultValue = null;
        });

        it('sets the controls value to an empty array if multi-value is passed in', () => {
          model.parameterType = 'multi-value';
          controlModel = managementReportService.convertParamToControlProperties(model);
          expect(controlModel.value).toEqual([]);
        });

        it('sets the controls value to an empty array if multi-value is not passed in', () => {
          model.parameterType = 'simple';
          controlModel = managementReportService.convertParamToControlProperties(model);
          expect(controlModel.value).toEqual('');
        });
      });
    });

    describe('assigning control elements types and additional settings', () => {
      it('should get a search box element with possible options', () => {
        model.type = 'LIST_BOX';
        model.selectionList = [{value: 1, label: 'one'}, {value: 2, label: 'two'}, {value: 3, label: 'three'}];

        controlModel = managementReportService.convertParamToControlProperties(model);
        const selectionListBs = new BehaviorSubject([
          {id: 1, text: 'one'},
          {id: 2, text: 'two'},
          {id: 3, text: 'three'}
        ]);
        expect(controlModel.element).toEqual('search-box');
        expect(controlModel.selectionList).toEqual(selectionListBs);
      });

      it('should get a radio button element with possible options', () => {
        model.type = 'RADIO_BUTTON';
        model.selectionList = [{value: 1, label: 'one'}, {value: 2, label: 'two'}, {value: 3, label: 'three'}];
        controlModel = managementReportService.convertParamToControlProperties(model);
        expect(controlModel.element).toEqual('radio');
        expect(controlModel.selectionList).toEqual([
            {id: 1, text: 'one'},
            {id: 2, text: 'two'},
            {id: 3, text: 'three'}
          ]
        );
      });

      it('should get a checkbox element with possible options', () => {
        model.type = 'CHECK_BOX';
        controlModel = managementReportService.convertParamToControlProperties(model);
        expect(controlModel.element).toEqual('checkbox');
      });

      describe('TEXT_BOX inputs', () => {
        describe('date/time types', () => {
          it('should set element to datepicker and only configure datepickerOptions, not timepickerOptions ' +
            'when param is TYPE_DATE', () => {
            model.dataType = 'TYPE_DATE';
            controlModel = managementReportService.convertParamToControlProperties(model);
            expect(controlModel.element).toEqual('datepicker');
            expect(controlModel.showDatePicker).not.toBeFalsy();
            expect(controlModel.showTimePicker).toBeFalsy();
          });
          it('should set element to datepicker and configure both datepickerOptions AND timepickerOptions ' +
            'when param is TYPE_DATE_TIME',
            () => {
              model.dataType = 'TYPE_DATE_TIME';
              controlModel = managementReportService.convertParamToControlProperties(model);
              expect(controlModel.element).toEqual('datepicker');
              expect(controlModel.showTimePicker).not.toBeFalsy();
              expect(controlModel.showDatePicker).not.toBeFalsy();
            });
          it('should set element to datepicker and only configure timepickerOptions, not datepickerOptions when param is TYPE_TIME', () => {
            model.dataType = 'TYPE_TIME';
            controlModel = managementReportService.convertParamToControlProperties(model);
            expect(controlModel.element).toEqual('datepicker');
            expect(controlModel.showDatePicker).toBeFalsy();
            expect(controlModel.showTimePicker).not.toBeFalsy();
          });
        });

        describe('Standard HTML input elements', () => {
          it('should set the element to \'input\' of type \'text\' when anything other than date, radio, listbox, ' +
            'or checkbox is possible', () => {
            model.dataType = 'UNKNOWN_TYPE';
            controlModel = managementReportService.convertParamToControlProperties(model);
            expect(controlModel.element).toEqual('input');
            expect(controlModel.textInputType).toEqual('text');
          });

          describe('with numeric data types', () => {
            it('should set the element to \'input\' of type \'text\' when TYPE_INTEGER is supplied', () => {
              model.dataType = 'TYPE_INTEGER';
              controlModel = managementReportService.convertParamToControlProperties(model);
              expect(controlModel.element).toEqual('input');
              expect(controlModel.textInputType).toEqual('text');
            });
            it('should set the element to \'input\' of type \'text\' when TYPE_FLOAT is supplied', () => {
              model.dataType = 'TYPE_FLOAT';
              controlModel = managementReportService.convertParamToControlProperties(model);
              expect(controlModel.element).toEqual('input');
              expect(controlModel.textInputType).toEqual('text');
            });
            it('should set the element to \'input\' of type \'text\' when TYPE_DECIMAL is supplied', () => {
              model.dataType = 'TYPE_DECIMAL';
              controlModel = managementReportService.convertParamToControlProperties(model);
              expect(controlModel.element).toEqual('input');
              expect(controlModel.textInputType).toEqual('text');
            });
          });

          it('should set the input type to \'password\' when the parameter specified concealEntry', () => {
            model.dataType = 'UNKNOWN_TYPE';
            model.concealEntry = 'Yes';
            controlModel = managementReportService.convertParamToControlProperties(model);
            expect(controlModel.element).toEqual('input');
            expect(controlModel.textInputType).toEqual('password');
          });
        });
      });
    });
  });

});
