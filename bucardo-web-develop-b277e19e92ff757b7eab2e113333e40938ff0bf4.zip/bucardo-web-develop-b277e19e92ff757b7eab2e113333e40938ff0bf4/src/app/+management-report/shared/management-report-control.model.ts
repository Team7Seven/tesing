export class ManagementReportControlModel {

  type: string;
  element: string;
  defaultValue: any;
  label: string;
  helpText: string;
  hidden: boolean;
  textInputType: string;
  multiple: boolean;
  name: string;
  selectionList: any;
  required: boolean;
  value: string;
  showDatePicker?: boolean;
  showTimePicker?: boolean;

  constructor() {}

}

