import {ManagementReportComponent} from './management-report.component';
import {ManagementReportRoute} from './management-report.routes';
import {RouterModule} from '@angular/router';
import {NgModule, CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {CommonModule} from '@angular/common';
import {ReactiveFormsModule, FormsModule} from '@angular/forms';
import {ManagementReportControlComponent} from './management-report-control/management-report-control.component';
import {ManagementReportParametersComponent} from './management-report-parameters/management-report-parameters.component';
import {TreeViewComponent} from './management-report-tree-view/tree-view.component';
import {SharedModule} from '../shared/shared.module';
import {TreeNodeComponent} from './management-report-tree-view/tree-node.component';
import {NKDatetimeModule} from 'ng2-datetime/ng2-datetime';

@NgModule({
  declarations: [ManagementReportComponent, ManagementReportControlComponent,
    TreeViewComponent, TreeNodeComponent, ManagementReportParametersComponent],
  imports: [RouterModule.forChild([ManagementReportRoute]), CommonModule, ReactiveFormsModule, FormsModule,
    SharedModule, NKDatetimeModule],
  exports: [ManagementReportComponent, TreeViewComponent, TreeNodeComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class ManagementReportModule {
}
