import {Component, Input, ViewEncapsulation} from '@angular/core';
import {FormGroup} from '@angular/forms';
import {ManagementReportParameterModel} from '../shared/management-report-parameter.model';
import {ManagementReportControlModel} from '../shared/management-report-control.model';

@Component({
  selector: 'management-report-control',
  templateUrl: 'management-report-control.component.html',
  styleUrls: ['management-report-control.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ManagementReportControlComponent {

  @Input() model: ManagementReportParameterModel;
  @Input() form: FormGroup;
  @Input() controlModel: ManagementReportControlModel;

  constructor() {
  }

  get isValid() {
    return this.form.controls[this.model.name].valid;
  }

  setSelection(event) {
    let value: any;
    if (!event || event.length === 0) {
      value = null;
    } else if (this.controlModel.multiple) {
      value = event.map(item => {
        return item.id;
      });
    } else {
      value = event[0].id;
    }

    this.form.controls[this.model.name].setValue(value);
    this.form.controls[this.model.name].markAsDirty();
    this.form.controls[this.model.name].markAsTouched();
  }

  resetSearchBox() {
    this.form.controls[this.model.name].setValue(null);
  }
}
