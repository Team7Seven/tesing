import {HistoricalPatientResultsComponent} from './historical-patient-results.component';
import {Route} from '@angular/router';

export const HistoricalPatientRoute: Route = {
  path: '', component: HistoricalPatientResultsComponent
};
