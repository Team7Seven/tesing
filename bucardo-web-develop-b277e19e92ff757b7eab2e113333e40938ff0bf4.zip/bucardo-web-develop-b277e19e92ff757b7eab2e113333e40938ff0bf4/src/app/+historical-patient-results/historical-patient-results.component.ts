import {Component} from '@angular/core';

@Component({
  selector: 'historical-patient-results',
  template: `
<percentage-height>
  <div class="row" percentageHeight="100">
    <div class="col-xs-4" percentageHeight="100">
      
    </div>
    <div class="col-xs-4" percentageHeight="100">
      <div [innerHtml]="'TODO Query report'"></div>
    </div>
    <div class="col-xs-4" percentageHeight="100">
      <div [innerHtml]="'TODO Content'"></div>
    </div>
  </div>
</percentage-height>
`
})
export class HistoricalPatientResultsComponent {
}
