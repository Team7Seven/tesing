import {Route} from '@angular/router';
import {HomeComponent} from './home.component';
import {AuthGuard} from '../guards/auth.guard';

export const HomeRoute: Route = {
  path: '',
  component: HomeComponent,
  canActivate: [AuthGuard],
  children: [
    {path: '', loadChildren: './+waiting/waiting.module#WaitingModule'},
    {path: 'lab-notes', loadChildren: './+lab-notes/lab-notes.module#LabNotesModule'},
    {path: 'editor', loadChildren: './+editors/editors.module#EditorsModule'},
    {
      path: 'cumulative-reports',
      loadChildren: './+cumulative-reports/cumulative-reports.module#CumulativeReportsModule'
    },
    {path: 'management-report', loadChildren: './+management-report/management-report.module#ManagementReportModule'},
    {
      path: 'historical-patient-results',
      loadChildren: './+historical-patient-results/historical-patient-results.module#HistoricalPatientResultsModule'
    },
    {
      path: 'request-scans',
      loadChildren: './+request-scans/request-scans.module#RequestScansModule'
    },
  ]
};
