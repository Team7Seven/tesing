import { Component } from '@angular/core';
import { AuthGuard } from '../guards/auth.guard';
import { AuthenticationService } from '../shared/services/authentication/authentication.service';

/**
 * This class represents the lazy loaded HomeComponent.
 */
@Component({
  selector: 'sd-home',
  templateUrl: 'home.component.html',
  providers: [AuthGuard, AuthenticationService],
  styleUrls: ['home.component.scss'],
})

export class HomeComponent {
}

