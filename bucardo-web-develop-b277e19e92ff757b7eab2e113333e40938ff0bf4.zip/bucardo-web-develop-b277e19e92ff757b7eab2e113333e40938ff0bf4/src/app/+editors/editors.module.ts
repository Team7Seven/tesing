import {PatientReportFormatEditorComponent} from './report-format-editor.component';
import {EditorRoutes} from './editors.routes';
import {RouterModule} from '@angular/router';
import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {ReactiveFormsModule, FormsModule} from '@angular/forms';
import {EditorFormatControlsComponent} from './editor-format-controls/editor-format-controls.component';
import {EditorItemsComponent} from './editor-items/editor-items.component';
import {TemplateInfoTableComponent} from './template-info-table/template-info-table.component';
import {SharedModule} from '../shared/shared.module';
import {ModalModule} from 'ng2-bootstrap';
import {EditorPageAreaSelectorComponent} from './editor-page-area-selector/editor-page-area-selector.component';
import {DraggableDirective} from './editor-items/editor-items-draggable.directive';
import {EditorTemplateControlsComponent} from './editor-template-controls/editor-template-controls.component';
import {TemplateEditorComponent} from './template-editor.component';

@NgModule({
  declarations: [PatientReportFormatEditorComponent,
                 TemplateEditorComponent,
                 EditorItemsComponent,
                 EditorFormatControlsComponent,
                 EditorTemplateControlsComponent,
                 TemplateInfoTableComponent,
                 EditorPageAreaSelectorComponent,
                 DraggableDirective],
  imports: [RouterModule.forChild(EditorRoutes),
            CommonModule,
            ReactiveFormsModule,
            FormsModule,
            SharedModule,
            ModalModule.forRoot()],
  exports: [PatientReportFormatEditorComponent, TemplateEditorComponent]
})
export class EditorsModule {
}
