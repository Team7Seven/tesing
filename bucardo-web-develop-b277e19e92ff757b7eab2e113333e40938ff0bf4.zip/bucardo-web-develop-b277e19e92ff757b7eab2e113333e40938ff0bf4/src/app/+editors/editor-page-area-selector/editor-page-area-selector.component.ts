import {Component, Input, Output, EventEmitter} from '@angular/core';

@Component({
  selector: 'editor-page-area-selector',
  template: `
  <div>
    <div class="horiz hand">header</div>
      <div>
        <span id="page-edit-left" class="vert left hand">L</span>
        <span id="page-edit-right" class="vert hand">R</span>
      </div>
    <div class="horiz hand">footer</div>
  </div>
`,
  styles: [`
  .horiz {
      display: block;
      border: 1px solid darkgray;
      width: 100px;
      height: 20px;
      text-align: center;
      vertical-align: middle;
  }
  
  .left {
    margin-right: 56.5px;
  }
  
  .vert {
      display: inline-block;
      border: 1px solid darkgray;
      width: 20px;
      height: 120px;
      text-align: center;
      vertical-align: middle;
  }
`]
})

export class EditorPageAreaSelectorComponent {

  @Input() formatsTemplates: any[];
  @Output() applyTemplatePressed = new EventEmitter();

  showTemplateSelector = false;
  selectedTemplate: any;

  onApplyTemplatePressed() {
    this.showTemplateSelector = false;
    if (this.selectedTemplate) {
      this.applyTemplatePressed.emit(this.selectedTemplate);
    }
  }
}
