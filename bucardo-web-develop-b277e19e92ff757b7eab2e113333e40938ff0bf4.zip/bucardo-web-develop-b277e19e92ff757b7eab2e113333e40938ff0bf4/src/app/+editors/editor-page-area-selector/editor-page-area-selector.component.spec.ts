import {EditorPageAreaSelectorComponent} from './editor-page-area-selector.component';

describe('EditorFormatControlsComponent', () => {

  let component: EditorPageAreaSelectorComponent;

  beforeEach(() => {
    component = new EditorPageAreaSelectorComponent();
  });

  it('should create component', () => {
    expect(component).toBeTruthy();
  });

  it('should emit selected template on call to onTemplateSelected', (done) => {
    component.selectedTemplate = 'Test Template';
    let emitted = false;
    component.applyTemplatePressed.subscribe(x => {
      emitted = true;
      expect(x).toEqual('Test Template');
      done();
    });

    component.onApplyTemplatePressed();

    expect(emitted).toBe(true);
  });

});
