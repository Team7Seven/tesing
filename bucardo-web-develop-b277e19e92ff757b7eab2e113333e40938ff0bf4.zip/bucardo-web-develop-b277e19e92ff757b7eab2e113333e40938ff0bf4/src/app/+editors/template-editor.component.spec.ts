import {Observable} from 'rxjs/Observable';
import {fakeAsync, tick} from '@angular/core/testing';
import {EditorService} from './shared/editor.service';
import {ToasterService} from 'angular2-toaster';
import {PayloadDataService} from '../shared/services/payload-data/payload-data.service';
import {NavbarDataService} from '../shared/components/navigation/navbar/navbar-data-service';
import {TemplateEditorComponent} from './template-editor.component';

describe('ReportTemplateEditorComponent', () => {

  const TEMPLATE_ID = 'TEMPLATE_ID';
  const TEMPLATE_CLASS = 'Class123';

  let component: TemplateEditorComponent;
  let navbarServiceMock: NavbarDataServiceMock;
  let toasterServiceMock: ToasterServiceMock;
  let editorServiceMock: EditorServiceMock;
  let payloadDataServiceMock: PayloadDataServiceMock;

  class ToasterServiceMock {
    pop = jasmine.createSpy('pop').and.returnValue(Observable.of([]));
  }

  class EditorServiceMock {
    getListOfCommonTemplates = jasmine.createSpy('getListOfCommonTemplates').and.returnValue(Observable.of([]));
    getCommonTemplate = jasmine.createSpy('getCommonTemplate').and.returnValue(Observable.of([]));
    getLabItems = jasmine.createSpy('getLabItems').and.returnValue(Observable.of([]));
    saveCommonTemplate = jasmine.createSpy('saveCommonTemplate').and.returnValue(Observable.of([]));
    getTemplateClasses = jasmine.createSpy('getTemplateClasses').and.returnValue(Observable.of([]));
    getTemplateStyles = jasmine.createSpy('getTemplateStyles').and.returnValue(Observable.of([]));
    getTemplatePermissions = jasmine.createSpy('getTemplatePermissions').and.returnValue(Observable.of({
      find: true,
      add: true,
      change: true
    }));
  }

  class PayloadDataServiceMock {
    payloadData: Observable<any> = Observable.of({event: '', payload: {}});
  }

  class NavbarDataServiceMock {
    setPage = jasmine.createSpy('setPage');
  }

  class EditorComponentMock {
    refreshEditorContent = jasmine.createSpy('refreshEditorContent').and.returnValue('STUFF');
  }

  beforeEach(() => {
    toasterServiceMock = new ToasterServiceMock();
    editorServiceMock = new EditorServiceMock();
    payloadDataServiceMock = new PayloadDataServiceMock();
    navbarServiceMock = new NavbarDataServiceMock();

    component = new TemplateEditorComponent(
      <ToasterService><any>toasterServiceMock,
      <EditorService><any>editorServiceMock,
      <PayloadDataService><any>payloadDataServiceMock,
      <NavbarDataService><any>navbarServiceMock);

    component.editor = <any>new EditorComponentMock();

    payloadDataServiceMock.payloadData = Observable.of({event: 'editCommonTemplate', payload: {}});

    spyOn(console, 'error');
  });

  it('should subscribe to payload data on initialisation', fakeAsync(() => {
    spyOn(payloadDataServiceMock.payloadData, 'subscribe').and.callThrough();
    component.ngOnInit();
    tick();
    expect(payloadDataServiceMock.payloadData.subscribe).toHaveBeenCalled();
  }));

  it('should get a Common template when event \'editCommonTemplate\' is received', () => {
    component.ngOnInit();

    expect(editorServiceMock.getCommonTemplate).toHaveBeenCalled();
  });

  it('should get a list of template classes when event \'editCommonTemplate\' is received', () => {
    component.ngOnInit();

    expect(editorServiceMock.getTemplateClasses).toHaveBeenCalled();
  });

  it('should throw exception on failure to get a Common template', () => {
    editorServiceMock.getCommonTemplate = jasmine.createSpy('getCommonTemplate').and.returnValue(Observable.throw('An Error'));

    try {
      component.ngOnInit();
      fail('Should throw an error');
    } catch (error) {
      expect(error).toEqual('An Error');
    }

  });

  it('should get a list of common templates on init when event is \'editCommonTemplate\'', () => {
    component.ngOnInit();

    expect(editorServiceMock.getListOfCommonTemplates).toHaveBeenCalled();
  });

  it('should handle failure to get common templates on init', () => {
    editorServiceMock.getListOfCommonTemplates = jasmine.createSpy('getListOfCommonTemplates')
      .and.returnValue(Observable.throw('An Error'));

    try {
      component.ngOnInit();
      fail('Should throw an error');
    } catch (error) {
      expect(error).toEqual('An Error');
    }
  });

  it('should get a list of common templates on init', () => {
    component.ngOnInit();
    expect(editorServiceMock.getListOfCommonTemplates).toHaveBeenCalled();
  });

  it('should save a Common template on save when event is \'editCommonTemplate\'', () => {
    component.permissions = {add: true, change: true};
    component.onSavePressed(TEMPLATE_ID);

    expect(editorServiceMock.saveCommonTemplate).toHaveBeenCalled();
    expect(component.editor.refreshEditorContent).toHaveBeenCalled();
    expect(toasterServiceMock.pop).toHaveBeenCalledWith('success', 'Saved...');
  });

  it('should pass on exception when saving a Common template on save when event is \'editCommonTemplate\'', () => {
    component.permissions.add = true;
    editorServiceMock.saveCommonTemplate = jasmine.createSpy('saveCommonTemplate').and.returnValue(Observable.throw('An Error'));

    try {
      component.onSavePressed(TEMPLATE_ID);
      fail('should have thrown an error');
    } catch (error) {
      expect(error).toEqual('An Error');
    }

  });

  it('should get a common template on apply template pressed', () => {
    editorServiceMock.getCommonTemplate = jasmine.createSpy('getCommonTemplate')
      .and.returnValue(Observable.of([{html: 'Test Common Template'}]));

    component.onTemplateSelected('Test Template Id');

    expect(editorServiceMock.getCommonTemplate).toHaveBeenCalled();
  });

  it('should bubble up failure to get a common template on apply template pressed', () => {
    editorServiceMock.getCommonTemplate = jasmine.createSpy('getCommonTemplate').and.returnValue(Observable.throw('An Error'));

    try {
      component.onTemplateSelected('Test Template Id');
      fail('Should throw and error');
    } catch (error) {
      expect(error).toEqual('An Error');
    }
  });

  it('should populate items when search on items dialog is pressed', () => {
    const items = [
      {code: 'na', name: 'SODIUM', lab: 'INV', key_num: '1'},
      {code: 'k', name: 'POTASSIUM', lab: 'INV', key_num: '1'},
      {code: 'zn', name: 'ZINC', lab: 'INV', key_num: '1'}
    ];
    editorServiceMock.getLabItems = jasmine.createSpy('getLabItems').and.returnValue(Observable.of(items));

    component.onItemsSearch({code: '', name: '', lab: '', keyNum: ''});

    expect(editorServiceMock.getLabItems).toHaveBeenCalled();
    expect(component.items).toEqual(items);
  });

  it('should handle failure to get lab items', () => {
    editorServiceMock.getLabItems = jasmine.createSpy('getLabItems').and.returnValue(Observable.throw('An Error'));

    try {
      component.onItemsSearch({code: '', name: '', lab: '', keyNum: ''});
      fail('Should throw and error');
    } catch (error) {
      expect(error).toEqual('An Error');
    }
  });

  it('should get a list of template styles depending on the template class that was selected', () => {
    payloadDataServiceMock.payloadData = Observable.of({event: 'editCommonTemplate', payload: {code: TEMPLATE_ID}});
    editorServiceMock.getCommonTemplate = jasmine.createSpy('getCommonTemplate')
      .and.returnValue(Observable.of({html: 'Test Common Template', 'class': TEMPLATE_CLASS}));

    component.ngOnInit();

    expect(editorServiceMock.getTemplateStyles).toHaveBeenCalledWith(TEMPLATE_CLASS);
  });

  describe('with find permissions disabled', () => {

    beforeEach(() => {
      editorServiceMock.getTemplatePermissions = jasmine.createSpy('getTemplatePermissions')
        .and.returnValue(Observable.of({find: false, change: true}));
    });

    it('should not make the requests to get template styles when find permission is false', () => {
      payloadDataServiceMock.payloadData = Observable.of({event: 'editCommonTemplate', payload: {}});
      component.ngOnInit();
      expect(editorServiceMock.getListOfCommonTemplates).not.toHaveBeenCalled();
    });

    it('should not make the requests to get lab formats when find permission is false', () => {
      payloadDataServiceMock.payloadData = Observable.of({event: 'editCommonTemplate', payload: {}});
      component.ngOnInit();
      expect(editorServiceMock.getTemplateClasses).not.toHaveBeenCalled();
    });

    it('should show a warning toast when find permission is false', () => {
      payloadDataServiceMock.payloadData = Observable.of({event: 'editCommonTemplate', payload: {}});
      component.ngOnInit();
      expect(toasterServiceMock.pop).toHaveBeenCalledWith('warning', 'You do not have permission to view this page.');
    });
  });

  describe('checking permissions when saving', () => {
    it('allows save when brandnew is set to true and adding is enabled', () => {
      component.editingBrandNewTemplate = true;
      component.permissions = {add: true};

      component.onSavePressed(TEMPLATE_ID);

      expect(editorServiceMock.saveCommonTemplate).toHaveBeenCalled();
      expect(component.editor.refreshEditorContent).toHaveBeenCalled();
      expect(toasterServiceMock.pop).toHaveBeenCalledWith('success', 'Saved...');
    });


    it('does not allow save when brandnew is set to true and adding is disabled', () => {
      component.editingBrandNewTemplate = true;
      component.permissions = {add: false};

      component.onSavePressed(TEMPLATE_ID);

      expect(editorServiceMock.saveCommonTemplate).not.toHaveBeenCalled();
      expect(component.editor.refreshEditorContent).not.toHaveBeenCalled();
      expect(toasterServiceMock.pop).not.toHaveBeenCalledWith('success', 'Saved...');
    });

    it('allows save when brandnew is set to false and changing is enabled', () => {
      component.editingBrandNewTemplate = false;
      component.permissions = {change: true};

      component.onSavePressed(TEMPLATE_ID);

      expect(editorServiceMock.saveCommonTemplate).toHaveBeenCalled();
      expect(component.editor.refreshEditorContent).toHaveBeenCalled();
      expect(toasterServiceMock.pop).toHaveBeenCalledWith('success', 'Saved...');
    });


    it('allows save when brandnew is set to true and adding is enabled', () => {
      component.editingBrandNewTemplate = false;
      component.permissions = {change: false};

      component.onSavePressed(TEMPLATE_ID);

      expect(editorServiceMock.saveCommonTemplate).not.toHaveBeenCalled();
      expect(component.editor.refreshEditorContent).not.toHaveBeenCalled();
      expect(toasterServiceMock.pop).not.toHaveBeenCalledWith('success', 'Saved...');
    });

  });

});
