import {Component, EventEmitter, Input, OnChanges, Output, SimpleChanges} from '@angular/core';
import * as moment from 'moment';
import {SearchBoxItemModel} from '../../shared/components/search-box/search-box-item.model';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';

@Component({
  selector: 'editor-format-controls',
  styles: [`
    .panel-body {
      padding: 5px;
      margin: 0;
    }

    .c-checkboxes {
      margin-top: 10px;
    }

    h4 {
      margin-top: 0;
    }

    .notes /deep/ textarea {
      margin-top: 5px;
      margin-bottom: 5px;
    }
  `],
  templateUrl: 'editor-format-controls.component.html',
})

export class EditorFormatControlsComponent implements OnChanges {
  @Input() labFormatInput: any = {};
  @Input() formatStyles = [];
  @Input() selectedTemplateCode = '';
  @Input() selectedTemplateStyleCode = '';
  @Input() templates = [];
  @Input() generateDisabled = true;
  @Input() permissions: any = {};
  @Input() formats = [];
  @Input() autoSelectFormat: any;

  @Output() templateSelected = new EventEmitter();
  @Output() templateStyleSelected = new EventEmitter();
  @Output() savePressed = new EventEmitter();
  @Output() loadInEditorPressed = new EventEmitter();
  @Output() useTemplatePressed = new EventEmitter();
  @Output() formatSelected = new EventEmitter();
  @Output() searchBoxFocused = new EventEmitter();


  labFormat: any;
  selectedFormat: SearchBoxItemModel;
  autoSelectedSearchBoxItem: SearchBoxItemModel;
  lastModified: string;
  showDaysBack: boolean;
  showPanelSearchAndSingleComment: boolean;
  showCount: boolean;
  showItemsList: boolean;
  items: string;
  searchBoxFormats = new BehaviorSubject<Array<SearchBoxItemModel>> ([]);

  constructor() {
    this.reset();
  }

  private reset() {
    this.labFormat = {};
    this.lastModified = null;
    this.showDaysBack = false;
    this.showPanelSearchAndSingleComment = false;
    this.showCount = false;
    this.showItemsList = false;
    this.items = '';
  }

  private resetTemplateSelections() {
    this.selectedTemplateStyleCode = '';
    this.selectedTemplateCode = '';
  }

  ngOnChanges(changes: SimpleChanges): void {
    if ('formats' in changes) {
      this.resetTemplateSelections();

      const availableFormats = [];

      changes['formats'].currentValue.forEach(format => {
        availableFormats.push(this.getSearchBoxObject(format));
      });

      this.searchBoxFormats.next(availableFormats);
      this.assignAutoSelected();
    }

    if ('autoSelectFormat' in changes) {
      this.assignAutoSelected();
    }

    if ('labFormatInput' in changes && changes['labFormatInput'].currentValue) {

      this.reset();
      this.resetTemplateSelections();

      Object.assign(this.labFormat, changes['labFormatInput'].currentValue);

      this.lastModified = this.getLastModifiedFromMetaData(this.labFormat);

      const formatClass = this.labFormat.clazz;

      this.showDaysBack = formatClass === 'A' || formatClass === 'B' || formatClass === 'C';
      this.showPanelSearchAndSingleComment = formatClass === 'C';
      this.showCount = formatClass === 'A';

      this.selectedFormat = this.getSearchBoxObject(this.labFormat);

    } else if ('labFormatInput' in changes) {
      this.reset();
    }

    if ('selectedTemplateStyleCode' in changes && this.selectedTemplateStyleCode) {
      const style = this.getStyleFromStyleCode();
      if (style) {
        this.showItemsList = (style.items === 'true');
      }
    }
  }

  assignAutoSelected() {
    if (this.autoSelectFormat && this.formats) {
      this.formats.forEach((format) => {
        if (format.code === this.autoSelectFormat.code) {
          this.autoSelectedSearchBoxItem = this.getSearchBoxObject(format);
        }
      });
    }
  }

  private getLastModifiedFromMetaData(labFormat: any) {
    if (this.hasValidModifiedDate(labFormat)) {
      return moment(labFormat.meta.lastUpdated).format('L LTS');
    } else {
      return null;
    }
  }

  private hasValidModifiedDate(labFormat) {
    return labFormat && labFormat.meta && labFormat.meta.lastUpdated && labFormat.meta.lastUpdated.trim();
  }

  onTemplateSelected() {
    if (this.selectedTemplateCode) {
      this.templateSelected.emit(this.selectedTemplateCode);
    }
  }

  onTemplateStyleSelected() {
    if (this.selectedTemplateStyleCode) {
      const style = this.getStyleFromStyleCode();
      if (style) {
        this.templateStyleSelected.emit(style);
      }
    }
  }

  private getStyleFromStyleCode(): any {
    let result: any = null;

    this.formatStyles.forEach((style) => {
      if (style.code === this.selectedTemplateStyleCode) {
        result = style;
      }
    });

    return result;
  }

  onSubmit(form) {
    if (form && form.valid) {
      this.savePressed.emit(form.value);
    }
  }

  getSearchBoxObject(format: any) {
    return {id: format.code, text: format.name, original: format, selected: false};
  }

}
