import {Routes} from '@angular/router';
import {PatientReportFormatEditorComponent} from './report-format-editor.component';
import {TemplateEditorComponent} from './template-editor.component';

export const EditorRoutes: Routes = [
  {path: 'template', component: TemplateEditorComponent},
  {path: 'report-format', component: PatientReportFormatEditorComponent}
];
