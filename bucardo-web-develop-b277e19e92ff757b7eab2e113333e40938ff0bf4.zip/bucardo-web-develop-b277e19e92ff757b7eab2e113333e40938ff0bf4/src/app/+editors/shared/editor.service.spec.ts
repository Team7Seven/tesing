import {EditorService} from './editor.service';
import {Observable} from 'rxjs/Observable';
import {fakeAsync, tick} from '@angular/core/testing';
import {UserModel} from '../../shared/models/user.model';
import createSpy = jasmine.createSpy;

describe('EditorService', () => {

  const LAB_API_URL = 'http://somewhere.com';
  const VALID_JSON = {result: 'result'};
  const ENCODED_AMPERSAND = '%26';
  const TEMPLATE_ARRAY_RESULT = {
    entry: [{
      resource: {
        type: 'bob', code: 'T1', name: 'Template 1'
      }
    }, {
      resource: {
        type: 'blah', code: 'T2', name: 'Template 2'
      }
    }
    ]
  };

  const LOGGED_IN_USER = 'bob';

  const validUser: UserModel = {
    resourceType: 'Login',
    token: 'MTQ4NTg1ODcwMTE0ODU4NTg3MD',
    code: LOGGED_IN_USER,
    name: 'Bobert McBobertson',
    login_group: 'systems',
    lab: 'INV',
    department: 'SY',
    entry_type: 'S',
    library_entry: 'C',
    validation_level: '9',
    confidential_access: '*',
    login_time_out: '60',
    login_timeout_min: '60',
    login_timeout_warn_min: '60',
    validation_depts: '*',
    initials: 'ash',
    inquiry_log: 'N',
    login_type: ' ',
    status: 'A'
  };

  let editorService: EditorService;
  let apiClientMock: ApiClientMock;
  let configMock: ConfigServiceMock;
  let userServiceMock: UserServiceMock;

  class ApiClientMock {
    get = createSpy('api get').and.returnValue(Observable.of(VALID_JSON));
    post = createSpy('api post').and.returnValue(Observable.of(VALID_JSON));
    put = createSpy('api put').and.returnValue(Observable.of(''));
  }

  class ConfigServiceMock {
    getConfig = createSpy('config').and.returnValue({labapi_url: LAB_API_URL});
  }

  class UserServiceMock {
    user = Observable.of(validUser);
  }

  beforeEach(() => {
    spyOn(console, 'error');
    apiClientMock = new ApiClientMock();
    configMock = new ConfigServiceMock();
    userServiceMock = new UserServiceMock();
    editorService = new EditorService(<any>apiClientMock, <any>configMock, <any>userServiceMock);
  });

  it('should call getConfig on the configuration service to get the lab api url', () => {
    expect(configMock.getConfig).toHaveBeenCalled();
  });

  describe('when getting lab format', () => {
    it('should call api with composite key made from code, lab and keyNum', () => {
      editorService.getLabFormat('code', 'lab', 'keyNum');
      expect(apiClientMock.get).toHaveBeenCalledWith(`${LAB_API_URL}/PatRptFormat/code~lab~keyNum`);
    });

    it('should encode the parameters', () => {
      editorService.getLabFormat('&', 'lab', 'keyNum');
      expect(apiClientMock.get).toHaveBeenCalledWith(`${LAB_API_URL}/PatRptFormat/${ENCODED_AMPERSAND}~lab~keyNum`);
    });
  });

  describe('when getting a template', () => {
    it('should call api with the code', () => {
      editorService.getCommonTemplate('code');
      expect(apiClientMock.get).toHaveBeenCalledWith(`${LAB_API_URL}/PatRptTemplate/code`);
    });

    it('should encode the parameters', () => {
      editorService.getCommonTemplate('&');
      expect(apiClientMock.get).toHaveBeenCalledWith(`${LAB_API_URL}/PatRptTemplate/${ENCODED_AMPERSAND}`);
    });
  });

  describe('when getting a list of template classes', () => {
    it('should call api', () => {
      editorService.getTemplateClasses();
      expect(apiClientMock.get).toHaveBeenCalledWith(`${LAB_API_URL}/PatRptTemplate/$classList`);
    });
  });

  describe('when getting a list of template styles', () => {
    it('should call api', () => {
      editorService.getTemplateStyles('code');
      expect(apiClientMock.get).toHaveBeenCalledWith(`${LAB_API_URL}/PatRptTemplate/$styleList?class=code`);
    });

    it('should encode the parameters', () => {
      editorService.getTemplateStyles('&');
      expect(apiClientMock.get).toHaveBeenCalledWith(`${LAB_API_URL}/PatRptTemplate/$styleList?class=${ENCODED_AMPERSAND}`);
    });
  });

  describe('when getTemplatesFromClassAndStyle', () => {

    beforeEach(() => {
      apiClientMock.get = createSpy('api get').and.returnValue(Observable.of(TEMPLATE_ARRAY_RESULT));
    });

    it('should call api', () => {
      editorService.getTemplatesFromClassAndStyle('class', 'style');
      expect(apiClientMock.get).toHaveBeenCalledWith(`${LAB_API_URL}/PatRptTemplate?class=class&style=style&_summary=short`);
    });

    it('should encode the parameters', () => {
      editorService.getTemplatesFromClassAndStyle('&', 'style');
      expect(apiClientMock.get).toHaveBeenCalledWith(`${LAB_API_URL}/PatRptTemplate?class=${ENCODED_AMPERSAND}&style=style&_summary=short`);
    });

    it('should map the result into an array of ids and names', fakeAsync(() => {
      let result = [];

      editorService.getTemplatesFromClassAndStyle('class', 'style').subscribe((templates) => {
        result = templates;
      });

      tick();

      expect(result.length).toEqual(2);
      expect(result[0]).toEqual({id: 'T1', name: 'Template 1'});
      expect(result[1]).toEqual({id: 'T2', name: 'Template 2'});
    }));
  });

  describe('when getListOfCommonTemplates', () => {

    beforeEach(() => {
      apiClientMock.get = createSpy('api get').and.returnValue(Observable.of(TEMPLATE_ARRAY_RESULT));
    });

    it('should call api', () => {
      editorService.getListOfCommonTemplates();
      expect(apiClientMock.get).toHaveBeenCalledWith(`${LAB_API_URL}/PatRptTemplate?_summary=short`);
    });

    it('should map the result into an array of ids and names', fakeAsync(() => {
      let result = [];

      editorService.getListOfCommonTemplates().subscribe((templates) => {
        result = templates;
      });

      tick();

      expect(result.length).toEqual(2);
      expect(result[0]).toEqual({id: 'T1', name: 'Template 1'});
      expect(result[1]).toEqual({id: 'T2', name: 'Template 2'});
    }));

  });

  describe('when saveLabFormat', () => {

    beforeEach(() => {
      apiClientMock.get = createSpy('api get').and.returnValue(Observable.of(TEMPLATE_ARRAY_RESULT));
    });

    it('should call api', () => {
      const labFormat = {
        code: 'code',
        lab: 'lab',
        key_num: 'key_num'
      };

      editorService.saveLabFormat(labFormat);

      expect(apiClientMock.put)
        .toHaveBeenCalledWith(`${LAB_API_URL}/PatRptFormat/code~lab~key_num`, labFormat, LOGGED_IN_USER);
    });

    it('should encode params', () => {
      const labFormat = {
        code: '&',
        lab: '&',
        key_num: '&'
      };

      editorService.saveLabFormat(labFormat);

      expect(apiClientMock.put)
        .toHaveBeenCalledWith(`${LAB_API_URL}/PatRptFormat/${ENCODED_AMPERSAND}~${ENCODED_AMPERSAND}~${ENCODED_AMPERSAND}`,
          labFormat, LOGGED_IN_USER);
    });

  });

  describe('when saveCommonTemplate', () => {

    beforeEach(() => {
      apiClientMock.get = createSpy('api get').and.returnValue(Observable.of(TEMPLATE_ARRAY_RESULT));
    });

    it('should call post if the template is new', () => {
      const template = {
        code: 'code',
        lab: 'lab',
        key_num: 'key_num',
        body: 'some html'
      };

      editorService.saveCommonTemplate(template, true);

      expect(apiClientMock.post)
        .toHaveBeenCalledWith(`${LAB_API_URL}/PatRptTemplate`, template);
    });

    it('should call put if the template exists', () => {
      const template = {
        code: 'code',
        lab: 'lab',
        key_num: 'key_num',
        body: 'some html'
      };

      editorService.saveCommonTemplate(template, false);

      expect(apiClientMock.put)
        .toHaveBeenCalledWith(`${LAB_API_URL}/PatRptTemplate/code`, template, LOGGED_IN_USER);
    });


    it('should encode params', () => {
      const template = {
        code: '&',
        lab: 'lab',
        key_num: 'key_num',
        body: 'some html'
      };

      editorService.saveCommonTemplate(template, false);

      expect(apiClientMock.put)
        .toHaveBeenCalledWith(`${LAB_API_URL}/PatRptTemplate/${ENCODED_AMPERSAND}`, template, LOGGED_IN_USER);
    });

  });

  describe('when generateFormatFromItems', () => {

    beforeEach(() => {
      apiClientMock.post = createSpy('api post').and.returnValue(Observable.of({body: 'some html'}));
    });

    it('should call api', () => {
      editorService.generateFormatFromItems('items', 'body', 'code');

      expect(apiClientMock.post)
        .toHaveBeenCalledWith(`${LAB_API_URL}/PatRptFormat/$templateToFormat`, {
          body: 'body',
          template: 'code',
          items: 'items',
          use_script: ''
        });
    });

    it('should return a json message with a body', fakeAsync(() => {
      let result = null;

      editorService.generateFormatFromItems('items', 'body', 'code').subscribe(response => result = response);

      tick();

      expect(result).toEqual({body: 'some html'});
    }));

  });


});
