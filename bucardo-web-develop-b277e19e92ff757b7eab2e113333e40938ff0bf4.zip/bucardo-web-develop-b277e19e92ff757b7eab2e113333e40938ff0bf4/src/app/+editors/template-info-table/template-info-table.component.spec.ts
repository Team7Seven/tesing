import {TestBed, ComponentFixture} from '@angular/core/testing';
import {TemplateInfoTableComponent} from './template-info-table.component';
import {Component} from '@angular/core';

// Using host component testing the implementation of ngOnChanges
// (https://medium.com/@christophkrautz/testing-ngonchanges-in-angular-components-bbb3b4650ee8#.jvq0icq7t)
@Component({
  template: '<template-info-table [metaData]="metaData"></template-info-table>'
})
class TestHostComponent {
  metaData: any;
}

describe('TemplateInfoTableComponent', () => {

  let testHostComponent: TestHostComponent;
  let fixture: ComponentFixture<TestHostComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
     declarations: [TemplateInfoTableComponent, TestHostComponent]});

    fixture = TestBed.createComponent(TestHostComponent);
    testHostComponent = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create component', () => {
    expect(testHostComponent).toBeTruthy();
  });

  it('should populate template details table when template meta data changes', () => {

    testHostComponent.metaData = {
        'Resource Type': 'db/CommonTemplate',
        'Code': 'SERIAL4R',
        'Name': 'SERIAL BY ROW',
        'Clazz': 'formats',
        'JavaScript': ' ',
        'Info': ' ',
        'Opr': 'pk',
        'Date Changed': '2015-03-03T00:00:00Z'
     };

    // Trigger change detection which will call the TemplateInfoTableComponent's ngOnChanges lifecycle hook
    fixture.detectChanges();

    const templateInfoTable = fixture.nativeElement.querySelector('table');
    expect(templateInfoTable.rows.length).toBe(8);
    expect(templateInfoTable.rows[0].outerText).toBe('Resource Type	db/CommonTemplate');
    expect(templateInfoTable.rows[1].outerText).toBe('Code	SERIAL4R');
    expect(templateInfoTable.rows[2].outerText).toBe('Name	SERIAL BY ROW');
    expect(templateInfoTable.rows[3].outerText).toBe('Clazz	formats');
    expect(templateInfoTable.rows[4].outerText).toBe('JavaScript	');
    expect(templateInfoTable.rows[5].outerText).toBe('Info	');
    expect(templateInfoTable.rows[6].outerText).toBe('Opr	pk');
    expect(templateInfoTable.rows[7].outerText).toBe('Date Changed	2015-03-03T00:00:00Z');
  });

});
