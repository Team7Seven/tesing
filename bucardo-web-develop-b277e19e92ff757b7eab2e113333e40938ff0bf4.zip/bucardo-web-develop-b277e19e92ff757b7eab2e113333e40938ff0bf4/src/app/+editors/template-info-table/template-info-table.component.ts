import {Component, Input, OnChanges, SimpleChanges} from '@angular/core';

@Component({
  selector: 'template-info-table',
  template: `
  <div *ngIf="metaData">
    <br />
    <h3>Template Details</h3>
    <table class="table table-striped">
      <tr *ngFor="let property of metaDataFields">
        <td>{{property}}</td><td>{{metaData[property]}}</td>
      </tr>
    </table>
  </div>
`
})

export class TemplateInfoTableComponent implements OnChanges {

  @Input() metaData: any;
  private metaDataFields: string[];

  ngOnChanges(changes: SimpleChanges): void {
    if ('metaData' in changes) {
      if (this.metaData) {
        this.metaDataFields = Object.keys(this.metaData);
      } else {
        this.metaDataFields = [];
      }
    }
  }

}
