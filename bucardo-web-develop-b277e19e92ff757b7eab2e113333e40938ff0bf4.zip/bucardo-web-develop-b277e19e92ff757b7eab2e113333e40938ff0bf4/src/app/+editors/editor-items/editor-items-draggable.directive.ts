import {Directive, ElementRef, HostListener, OnInit, Input} from '@angular/core';

@Directive({
  selector: '[draggable]'
})
export class DraggableDirective implements OnInit {

  @Input('draggableClasses') draggableClasses: string;

  top: number;
  left: number;
  isMouseDown = false;
  draggableElementClasses: string[];

  constructor(private element: ElementRef) {}

  ngOnInit() {
    this.draggableElementClasses = this.draggableClasses.split(',');

    // Apply draggable CSS
    //
    // It is not recommended to apply any special positioning
    // to a Bootstrap modal container and its parent elements:
    // https://www.toptal.com/twitter-bootstrap/the-10-most-common-bootstrap-mistakes
    // so this line has been commented out. However this causes
    // the horizontal movement of the element being dragged to
    // not accurately track the horizontal mouse movements.
    //
    // this.element.nativeElement.style.position = 'relative';
    //
    this.element.nativeElement.className += ' cursor-draggable';
    // Set the cursor to a 'move' icon on all elements that can be used in initiate the drag
    for (let i = 0; i < this.draggableElementClasses.length; i++) {
      const draggableElements = this.element.nativeElement.getElementsByClassName(this.draggableElementClasses[i].trim());
      for (let j = 0; j < draggableElements.length; j += 1) {
        draggableElements[j].style.cursor = 'move';
      }
    }
  }

  @HostListener('mousedown', ['$event'])
  onMouseDown(event: MouseEvent) {

    // Prevent right-click drag by ignoring all events except left mouse down
    if (event.button !== 0) {
      return;
    }

    // Prevent dragging on non-draggable elements.
    const target: Element = <Element>event.target;
    let draggableElement = false;
    for (let i = 0; i < this.draggableElementClasses.length; i += 1) {
      if (target.classList.contains(this.draggableElementClasses[i].trim())) {
        draggableElement = true;
      };
    }
    if (!draggableElement) {
      return;
    }

    event.preventDefault();
    this.isMouseDown = true;

    this.top = event.clientY - this.element.nativeElement.style.top.replace('px', '');
    this.left = event.clientX - this.element.nativeElement.style.left.replace('px', '');
  }

  @HostListener('document:mouseup')
  onMouseUp(event: MouseEvent) {
    this.isMouseDown = false;
  }

//  @HostListener('document:mouseout')
//  onMouseOut(event: MouseEvent) {
//    // Prevent the user from dragging the dialog outside the visible area.
//    this.isMouseDown = false;
//  }

  @HostListener('document:mousemove', ['$event'])
  onMouseMove(event: MouseEvent) {
    if (this.isMouseDown) {
      event.preventDefault();
      this.element.nativeElement.style.top = (event.clientY - this.top) + 'px';
      this.element.nativeElement.style.left = (event.clientX - this.left) + 'px';
    }
  }
}
