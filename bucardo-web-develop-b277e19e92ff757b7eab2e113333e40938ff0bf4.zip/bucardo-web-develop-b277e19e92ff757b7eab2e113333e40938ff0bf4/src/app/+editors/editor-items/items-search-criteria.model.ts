export class ItemsSearchCriteriaModel {
  code = '';
  name = '';
  lab = '';
  keyNum = '';
}
