import {ComponentFixture, TestBed} from '@angular/core/testing';
import {FormsModule} from '@angular/forms';
import {ModalModule} from 'ng2-bootstrap';
import {DraggableDirective} from './editor-items-draggable.directive';
import {EditorItemsComponent} from './editor-items.component';

describe('EditorItemsComponent', () => {

  let component: EditorItemsComponent;
  let fixture: ComponentFixture<EditorItemsComponent>;

  beforeEach(() => {
    component = new EditorItemsComponent();
  });

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [EditorItemsComponent, DraggableDirective],
      imports: [FormsModule, ModalModule.forRoot()]});

    fixture = TestBed.createComponent(EditorItemsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create component', () => {
    expect(component).toBeTruthy();
  });

  it('should make call to show items list dialog on call to showDialog', () => {
    spyOn(component.itemsListDialog, 'show');
    component.showDialog();

    expect(component.itemsListDialog.show).toHaveBeenCalled();
  });

  it('should make call to hide items list dialog on call to hideDialog', () => {
    spyOn(component.itemsListDialog, 'hide');
    component.hideDialog();

    expect(component.itemsListDialog.hide).toHaveBeenCalled();
  });

  it('should emit test items search criteria on call to onSubmit', (done) => {

    const itemsSearchCriteria = {code: 'Test Code', name: 'Test Name', lab: 'Test Lab', keyNum: '1'};
    component.model = itemsSearchCriteria;
    let emitted = false;
    component.submitClicked.subscribe(x => {
      emitted = true;
      expect(x).toEqual(itemsSearchCriteria);
      done();
    });

    component.onSubmit();

    expect(emitted).toBe(true);
  });

  it('should emit test of selected item on call to onClick', (done) => {

    const selectedItem = 'abc';
    let emitted = false;
    component.selectedItem.subscribe(x => {
      emitted = true;
      expect(x).toEqual(selectedItem);
      done();
    });

    component.onClick(selectedItem);

    expect(emitted).toBe(true);
  });

});
