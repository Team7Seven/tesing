import {Route} from '@angular/router';
import {RequestScansComponent} from './request-scans.component';

export const RequestScansRoutes: Route = {
  path: '',
  component: RequestScansComponent
};
