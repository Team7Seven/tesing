/* tslint:disable:no-unused-variable */
import {discardPeriodicTasks, fakeAsync, tick} from '@angular/core/testing';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {Observable} from 'rxjs/Observable';
import {RequestScansComponent} from './request-scans.component';
import {DocumentModel} from './shared/document.model';
import {Subject} from 'rxjs/Subject';
import createSpy = jasmine.createSpy;

const PDF_URL = 'PDF_LOCATION.PDF';
const REQUEST_NUMBER = '1234';
const DOCUMENT_ID = '4321';
const SAMPLE_DOC = <any>{
  ri: DOCUMENT_ID,
  name: 'bob'
};

class PayloadDataServiceMock {
  payloadData = new BehaviorSubject('');
  sendPayload = createSpy('sendPayload').and.callFake((data) => {
    this.payloadData.next(data);
  });
}

class ToasterServiceMock {
  pop = createSpy('toastMock');
}

class RequestScansServiceMock {
  getPermissions = createSpy('getPermissions').and.returnValue(Observable.of({find: true}));
  getDocumentUrl = createSpy('getDocumentUrl').and.returnValue(PDF_URL);
  getUnallocatedScans = createSpy('getUnallocatedScans').and.returnValue(Observable.of({}));
  getScanMetaDataByRequest = createSpy('getScanMetaDataByRequest').and.returnValue(Observable.of([SAMPLE_DOC]));
  updateScan = createSpy('updateScan').and.callFake((document) => Observable.of(document));
  deleteScan = createSpy('deleteScan').and.returnValue(Observable.of({}));
  searchRequests = createSpy('searchRequests');
}

class PatientRequestDoctorHelperMock {
  networkError = new Subject();
  resetObservables = createSpy('resetObservables');
  fetchPatientRequestDoctorFromRequestId = createSpy('fetchPatientRequestDoctorFromRequestId');
  request = new BehaviorSubject({}).asObservable();
  receiveNewRequest = createSpy('receiveNewRequest');
}

class BootstrapModalMock {
  hide = createSpy('closeModal');
  show = createSpy('openModal');
}

class NavbarDataServiceMock {
  setPage = createSpy('setPage');
}

class ChangeDetectorMock {
  detectChanges = createSpy('detectChanges');
}

class NgZoneMock {
  runOutsideAngular = createSpy('runOutsideAngular').and.callFake((fn) => fn());
  run = createSpy('run').and.callFake((fn) => fn());
}

describe('RequestScansComponent', () => {

  let payloadDataServiceMock: PayloadDataServiceMock;
  let requestScansServiceMock: RequestScansServiceMock;
  let toasterServiceMock: ToasterServiceMock;
  let navbarServiceMock: NavbarDataServiceMock;
  let changeDetectorMock: ChangeDetectorMock;
  let ngZoneMock: NgZoneMock;
  let component: RequestScansComponent;
  let patientRequestDoctorHelperMock: PatientRequestDoctorHelperMock;
  let bootstrapModalMock: BootstrapModalMock;

  beforeEach(() => {
    payloadDataServiceMock = new PayloadDataServiceMock();
    requestScansServiceMock = new RequestScansServiceMock();
    toasterServiceMock = new ToasterServiceMock();
    navbarServiceMock = new NavbarDataServiceMock();
    ngZoneMock = new NgZoneMock();
    changeDetectorMock = new ChangeDetectorMock();
    patientRequestDoctorHelperMock = new PatientRequestDoctorHelperMock();
    bootstrapModalMock = new BootstrapModalMock();

    component = new RequestScansComponent(
      <any> payloadDataServiceMock,
      <any> requestScansServiceMock,
      <any> toasterServiceMock,
      <any> navbarServiceMock,
      <any> patientRequestDoctorHelperMock,
      <any> changeDetectorMock,
      <any> ngZoneMock,
      <any> bootstrapModalMock
    );

  });

  it('should clear document list selections if request is not found', () => {
    component.docListsContainer = {nativeElement: {clientHeight: 20}};
    component.selectedAssignedDocument = <any>{ri: '123'};
    component.selectedUnassignedDocument = <any>{ri: '234'};

    requestScansServiceMock.getScanMetaDataByRequest = createSpy('requestError').and.returnValue(Observable.throw('SOME_ERROR'));
    try {
      component.ngOnInit();
      payloadDataServiceMock.sendPayload({event: 'document', payload: {request: REQUEST_NUMBER}});
    } catch (e) {
      expect(component.selectedUnassignedDocument).toBeFalsy();
      expect(component.selectedAssignedDocument).toBeFalsy();
      expect(e).toEqual('SOME_ERROR');
    }
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('On init', () => {

    it('should subscribe to payloadData on init', fakeAsync(() => {
      spyOn(payloadDataServiceMock.payloadData, 'subscribe').and.returnValue(Observable.of({}));
      component.ngOnInit();
      tick();
      expect(payloadDataServiceMock.payloadData.subscribe).toHaveBeenCalled();
    }));

    it('should reset observables on the patient request doctor helper', () => {
      component.ngOnInit();
      expect(patientRequestDoctorHelperMock.resetObservables).toHaveBeenCalled();
    });


    describe('with valid request passed in request', () => {

      beforeEach(() => {
        component.ngOnInit();
        payloadDataServiceMock.sendPayload({event: 'document', payload: {request: REQUEST_NUMBER}});
      });

      it('should call a service to get patient request and doctor details', () => {
        expect(patientRequestDoctorHelperMock.fetchPatientRequestDoctorFromRequestId).toHaveBeenCalledWith(REQUEST_NUMBER);
      });

      it('should get list of unallocated scans', fakeAsync(() => {
        tick();
        expect(requestScansServiceMock.getUnallocatedScans).toHaveBeenCalled();
        discardPeriodicTasks();
      }));

      it('should get patient doctor request data', fakeAsync(() => {
        tick();
        expect(patientRequestDoctorHelperMock.fetchPatientRequestDoctorFromRequestId).toHaveBeenCalledWith(REQUEST_NUMBER);
        discardPeriodicTasks();
      }));

      it('should assign list of documents', fakeAsync(() => {
        tick();
        expect(component.assignedDocuments).toEqual([SAMPLE_DOC]);
      }));

      it('should select first assignedDocument', fakeAsync(() => {
        tick();
        expect(component.selectedAssignedDocument.ri).toEqual(SAMPLE_DOC.ri);
      }));

    });


    describe('onAssignedPressed', () => {

      beforeEach(() => {
        component.requestId = REQUEST_NUMBER;
        component.unassignedDocuments = [SAMPLE_DOC];
        component.selectedUnassignedDocument = SAMPLE_DOC;
        component.onAssignPressed();
      });

      it('should update scan with the current request id', () => {
        const documentWithRequestId = Object.assign({request: REQUEST_NUMBER}, SAMPLE_DOC);

        expect(requestScansServiceMock.updateScan).toHaveBeenCalledWith(documentWithRequestId);
      });

      it('should remove document from unassignedDocuments', () => {
        expect(component.unassignedDocuments.length).toEqual(0);
      });

      it('should add document to assignedDocuments', () => {
        expect(component.assignedDocuments.length).toEqual(1);
      });

      it('should clear unassigned document', () => {
        expect(component.selectedUnassignedDocument).toBeFalsy();
      });

      it('should set the selected assigned document to the assigned document', () => {
        expect(component.selectedAssignedDocument).toEqual(SAMPLE_DOC);
      });
    });

    describe('onUnassignedPressed', () => {

      beforeEach(() => {
        component.requestId = REQUEST_NUMBER;
        const documentWithRequestId = Object.assign({}, SAMPLE_DOC, {request: REQUEST_NUMBER});
        component.assignedDocuments = [documentWithRequestId];
        component.selectedAssignedDocument = documentWithRequestId;
        component.onUnassignPressed();
      });

      it('should update scan with zero for the request id', () => {
        const documentWithZeroRequestId = Object.assign({}, SAMPLE_DOC, {request: '0'});

        expect(requestScansServiceMock.updateScan).toHaveBeenCalledWith(documentWithZeroRequestId);
      });

      it('should remove document from assignedDocuments', () => {
        expect(component.assignedDocuments.length).toEqual(0);
      });

      it('should add document to unassignedDocuments', () => {
        expect(component.unassignedDocuments.length).toEqual(1);
      });

      it('should clear assigned document', () => {
        expect(component.selectedAssignedDocument).toBeFalsy();
      });

      it('should set the selected unassigned document to the unassigned document', () => {
        const documentWithZeroRequestId = Object.assign({}, SAMPLE_DOC, {request: '0'});
        expect(component.selectedUnassignedDocument).toEqual(documentWithZeroRequestId);
      });
    });


    describe('onUnassignedDocumentChanged', () => {
      beforeEach(() => {
        component.selectedUnassignedDocument = <any>{ri: 'ID_BEFORE_CLICK'};
        component.selectedAssignedDocument = <any> {ri: 'NON_EMPTY_ID'};
        component.onUnassignedDocumentChanged(<any>{ri: 'ID_AFTER_CLICK'});
      });

      it('should assign the document', () => {
        expect(component.selectedUnassignedDocument.ri).toEqual('ID_AFTER_CLICK');
      });

      it('should clear assigned document', () => {
        expect(component.selectedAssignedDocument).toBeFalsy();
      });
    });


    describe('onAssignedDocumentChanged', () => {
      beforeEach(() => {
        component.selectedUnassignedDocument = <any> {ri: 'NON_EMPTY_ID'};
        component.selectedAssignedDocument = <any> {ri: 'ID_BEFORE_CLICK'};
        component.onAssignedDocumentChanged({ri: 'ID_AFTER_CLICK'});
      });

      it('should assign the document', () => {
        expect(component.selectedAssignedDocument.ri).toEqual('ID_AFTER_CLICK');
      });

      it('should clear unassigned document', () => {
        expect(component.selectedUnassignedDocument).toBeFalsy();
      });
    });

    describe('permissions check', () => {

      function expectGetPermissionsCalledOnEvent(event: any) {
        component.ngOnInit();
        payloadDataServiceMock.sendPayload(event);
        expect(requestScansServiceMock.getPermissions).toHaveBeenCalled();
        discardPeriodicTasks();
      }

      it('should check permissions for this module when a browser (login) event comes in', fakeAsync(() => {
        expectGetPermissionsCalledOnEvent({event: 'browser'});
      }));

      it('should check permissions for this module when a request-scans event comes in', fakeAsync(() => {
        expectGetPermissionsCalledOnEvent({event: 'menu', payload: {module: 'request-scans'}});
      }));

      it('should check permissions for this module when a showRequestScans event comes in', fakeAsync(() => {
        expectGetPermissionsCalledOnEvent({event: 'document', payload: {request: REQUEST_NUMBER}});
      }));
    });

  });


  describe('Permissions', () => {
    beforeEach(() => {
      component.ngOnInit();
    });

    it('should retrieve scan if find permission and request in payload', () => {
      payloadDataServiceMock.sendPayload({event: 'document', payload: {request: REQUEST_NUMBER}});
      expect(requestScansServiceMock.getScanMetaDataByRequest).toHaveBeenCalledWith(REQUEST_NUMBER);
    });

    it('should not retrieve scan data if we don`t have find permission', () => {
      requestScansServiceMock.getPermissions = jasmine.createSpy('getPermissions').and.returnValue(Observable.of({find: false}));
      payloadDataServiceMock.sendPayload({event: 'document', payload: {request: REQUEST_NUMBER}});
      expect(requestScansServiceMock.getScanMetaDataByRequest).not.toHaveBeenCalled();
    });

    it('should show a warning toast if we don`t have find permission', () => {
      requestScansServiceMock.getPermissions = jasmine.createSpy('getPermissions').and.returnValue(Observable.of({find: false}));
      payloadDataServiceMock.sendPayload({event: 'document', payload: {request: REQUEST_NUMBER}});
      expect(toasterServiceMock.pop).toHaveBeenCalledWith('warning', 'You do not have permission to view this page.');
    });
  });


  describe('Get scan from passed in request', () => {
    beforeEach(() => {
      requestScansServiceMock.getScanMetaDataByRequest = createSpy('getScanMetaDataByRequest').and.returnValue(Observable.of([SAMPLE_DOC]));
      component.ngOnInit();
      payloadDataServiceMock.sendPayload({event: 'document', payload: {request: REQUEST_NUMBER}});
    });

    it('should call the api to get the meta data associated with the request scan', () => {
      expect(requestScansServiceMock.getScanMetaDataByRequest).toHaveBeenCalledWith(REQUEST_NUMBER);
    });

    it('should get the document url info from the service', () => {
      expect(requestScansServiceMock.getDocumentUrl).toHaveBeenCalledWith(DOCUMENT_ID);
    });

    it('should assign the pdfSrc to the scan location', () => {
      expect(component.pdfUrl).toEqual(PDF_URL);
    });

    it('should not should a warning toast', () => {
      expect(toasterServiceMock.pop).not.toHaveBeenCalled();
    });
  });


  describe('Passed in scan does not exist', () => {
    beforeEach(() => {
      requestScansServiceMock.getScanMetaDataByRequest = createSpy('getScanMetaDataByRequest').and.returnValue(Observable.of(null));
      component.ngOnInit();
      payloadDataServiceMock.sendPayload({event: 'document', payload: {request: REQUEST_NUMBER}});
    });

    it('should not assign the pdfSrc to the scan location', () => {
      expect(component.pdfUrl).toBeFalsy();
    });
  });

  describe('deleting scans', () => {
    beforeEach(() => {
      const UNASSIGNED_DOCUMENT: DocumentModel = <any>{ri: 'UNASSIGNED_SELECTED_ID'};
      component.unassignedDocuments = [UNASSIGNED_DOCUMENT];
      component.selectedUnassignedDocument = UNASSIGNED_DOCUMENT;
      component.confirmDeleteDialog = bootstrapModalMock;
    });

    it('calls the dialog service open method', () => {
      component.confirmDelete(<any>'');
      expect(bootstrapModalMock.show).toHaveBeenCalled();
    });

    it('calls delete on the currently selcted unassigned document', () => {
      component.doDelete();
      expect(requestScansServiceMock.deleteScan).toHaveBeenCalledWith({ri: 'UNASSIGNED_SELECTED_ID'});
    });

    it('removes the deleted document from the list of unassigned documents', () => {
      component.doDelete();
      expect(component.unassignedDocuments.length).toEqual(0);
    });

    it('hides the confirmation dialog on successful deletion', () => {
      component.doDelete();
      expect(bootstrapModalMock.hide).toHaveBeenCalled();
    });

    it('deselects the currently selected unassigned document', () => {
      component.doDelete();
      expect(component.selectedUnassignedDocument).toBeFalsy();
    });
  });

  describe('selecting request', () => {
    const FOUND_REQUEST = {ri: 123, number: 123, prefix: 'abc'};
    beforeEach(() => {
      requestScansServiceMock.searchRequests = createSpy('getScanMetaDataByRequest').and
        .returnValue(Observable.of([FOUND_REQUEST]));
      component.docListsContainer = {nativeElement: {clientHeight: 20}};
    });

    describe('selecting a new request', () => {
      it('searches for a request when getRequest is called', () => {
        component.getRequest('abc123');
        expect(requestScansServiceMock.searchRequests).toHaveBeenCalledWith('abc123');
      });

      it('assings a new requestId when a request is searched for and found', () => {
        component.getRequest('abc123');
        expect(component.requestId).toEqual(123);
      });

      it('passes new request into helper when a request is searched for and found', () => {
        component.getRequest('abc123');
        expect(patientRequestDoctorHelperMock.receiveNewRequest).toHaveBeenCalledWith(FOUND_REQUEST);
      });
    });

    describe('finding 0 or more than one request', () => {
      it('does not pass new requests into helper and shows warning toast when more than one request found', () => {
        requestScansServiceMock.searchRequests = createSpy('getScanMetaDataByRequest').and
          .returnValue(Observable.of([FOUND_REQUEST, FOUND_REQUEST]));
        component.getRequest('abc123');
        expect(patientRequestDoctorHelperMock.receiveNewRequest).not.toHaveBeenCalledWith(FOUND_REQUEST);
        expect(toasterServiceMock.pop).toHaveBeenCalled();
      });
      it('does not pass new requests into helper and shows warning toast when 0 requests found', () => {
        requestScansServiceMock.searchRequests = createSpy('getScanMetaDataByRequest').and
          .returnValue(Observable.of([]));
        component.getRequest('abc123');
        expect(patientRequestDoctorHelperMock.receiveNewRequest).not.toHaveBeenCalled();
        expect(toasterServiceMock.pop).toHaveBeenCalled();
      });

      describe('clearing requests', () => {
        beforeEach(() => {
          component.requestId = 23;
          component.selectedAssignedDocument = <any>{'doc': 'test'};
          requestScansServiceMock.searchRequests = createSpy('getScanMetaDataByRequest').and
            .returnValue(Observable.of([]));
        });

        it('sets the request ID to null when no request found', () => {
          component.getRequest('as');
          expect(component.requestId).toEqual(null);
        });
        it('calls resetObservables on helper', () => {
          component.getRequest('as');
          expect(patientRequestDoctorHelperMock.resetObservables).toHaveBeenCalled();
        });
        it('deselects assigned document', () => {
          component.getRequest('as');
          expect(component.selectedAssignedDocument).toEqual(null);
        });
      });
    });
  });
})
;
