import {Injectable} from '@angular/core';
import {ApiClient} from '../../shared/services/api-client/api-client';
import {ConfigurationService} from '../../shared/services/configuration/configuration.service';
import {getEtagFromMeta} from '../../shared/utils/etag-utils';
import {UserService} from '../../shared/services/user/user.service';

@Injectable()
export class RequestScansService {

  private baseUrl;
  private currentUser;

  constructor(private apiClient: ApiClient,
              private config: ConfigurationService,
              private userService: UserService) {
    this.baseUrl = config.getConfig().labapi_url;
    userService.user.subscribe((user) => {
      if (user) {
        this.currentUser = user.code;
      }
    });
  }

  getPermissions() {
    return this.apiClient.get(`${this.baseUrl}/Document/$perms`);
  }

  getScanMetaDataByRequest(requestId) {
    return this.apiClient.get(`${this.baseUrl}/Document?request=${requestId}`).map((requests) => {
      if (requests.entry) {
        return requests.entry.map(this.mapDocumentFromFhir);
      } else {
        return null;
      }
    });
  }

  getDocumentUrl(documentId: string) {
    return `${this.baseUrl}/Document/$getContent?document=${documentId}`;
  }

  getUnallocatedScans() {
    return this.apiClient.get(`${this.baseUrl}/Document?request=none`).map(requestMetaData => {
      if (requestMetaData.entry && requestMetaData.entry.length) {
        return requestMetaData.entry.map(this.mapDocumentFromFhir);
      } else {
        return [];
      }
    });
  }

  updateScan(document) {
    if (document && document.ri) {
      return this.apiClient.put(`${this.baseUrl}/Document/${document.ri}`, document, this.currentUser);
    }
  }

  deleteScan(document) {
    if (document && document.ri) {
      return this.apiClient.delete(`${this.baseUrl}/Document/${document.ri}`);
    }
  }

  searchRequests(filter) {
    const parts = filter.split('-');
    let prefix = this.config.getConfig().prefix;
    if (parts.length > 1) {
      prefix = parts.shift();
    }

    const num = parts[0];

    return this.apiClient.get(`${this.baseUrl}/Request?prefix=${prefix}&num=${num}`).map((json: any) => {
      return json.entry.map((request) => {
        return request.resource;
      });
    });
  }

  private mapDocumentFromFhir(request) {
    return request.resource;
  }
}
