import {
  ChangeDetectorRef,
  Component,
  HostListener,
  NgZone,
  OnDestroy,
  OnInit,
  TemplateRef,
  ViewChild
} from '@angular/core';
import {Subscription} from 'rxjs/Subscription';
import {RequestScansService} from './shared/request-scans.service';
import {ToasterService} from 'angular2-toaster';
import {PayloadDataService} from '../shared/services/payload-data/payload-data.service';
import {NavbarDataService} from '../shared/components/navigation/navbar/navbar-data-service';
import {PatientRequestDoctorHelper} from '../shared/component-helpers/patient-request-doctor.helper';
import {BsModalService} from 'ngx-bootstrap/modal';
import {BsModalRef} from 'ngx-bootstrap/modal/modal-options.class';
import {DocumentModel} from './shared/document.model';
import {SearchBoxItemModel} from '../shared/components/search-box/search-box-item.model';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';

@Component({
  selector: 'request-scans',
  templateUrl: `./request-scans.component.html`,
  styles: [`
    .fullLength {
      height: calc(100vh - 65px);
    }

    .remove-padding-right {
      padding-right: 0;
    }

    .doc-lists {
      border-left: 1px solid lightgray;
    }

    .list-separator {
      margin-bottom: 10px;
    }

    form-button-right {
      width: 100px;
    }

    .input-group-addon {
      border: 0;
      text-align: center;
      color: #777777;
      padding: 0 8px !important;
      cursor: pointer;
    }

    .input-group-addon.disabled {
      color: #d1d1d1;
      cursor: not-allowed;
    }

    .request-search {
      padding-top: 8px !important;
    }

    .input-group-addon i.fa-search {
      font-size: 16px;
    }


  `],
  providers: [RequestScansService]
})

export class RequestScansComponent implements OnInit, OnDestroy {
  pdfUrl = null;
  zoom = 1.5;

  permissions: any = {};
  unassignedDocuments: DocumentModel[] = [];
  assignedDocuments: DocumentModel[] = [];
  selectedUnassignedDocument: DocumentModel;
  selectedAssignedDocument: DocumentModel;
  fileName = '';
  requestId = null;
  bottomDocumentListHeight = 200;
  confirmDeleteDialog: BsModalRef;
  requestReferenceInputValue: string;
  currentRequestReference: string;
  viewActive = true;
  @ViewChild('docLists') docListsContainer;
  @ViewChild('docTop') docTopList;
  @ViewChild('docBottom') docBottomList;

  private payloadDataSubscription: Subscription;
  private documentMetaDataSub: Subscription;

  constructor(private payloadDataService: PayloadDataService,
              private requestScansService: RequestScansService,
              private toastService: ToasterService,
              private navbarService: NavbarDataService,
              public patientRequestDoctorHelper: PatientRequestDoctorHelper,
              private changeDetector: ChangeDetectorRef,
              private _ngZone: NgZone,
              private modalService: BsModalService) {
    navbarService.setPage('Request Scans');
  }

  ngOnInit() {
    this.patientRequestDoctorHelper.resetObservables();
    this.subPayloadChanges();
    this.patientRequestDoctorHelper.networkError.subscribe(() => this.onNetworkError());
  }

  ngOnDestroy() {
    this.payloadDataSubscription.unsubscribe();

    if (this.documentMetaDataSub) {
      this.documentMetaDataSub.unsubscribe();
    }

    this.viewActive = false;
  }

  private subPayloadChanges() {
    this.payloadDataSubscription = this.payloadDataService.payloadData.subscribe(krillEvent => {
      if (this.isAnEventToStartComponent(krillEvent)) {
        this.subscribeToRequest();
        this.subscribeToPermissions(krillEvent);
      }
    });
  }

  private onNetworkError() {
    if (this.documentMetaDataSub) {
      this.documentMetaDataSub.unsubscribe();
    }

    this.clearRequest();
    this.clearRequestScanData();
    this.deselectUnassignedDocument();
    this.patientRequestDoctorHelper.resetObservables();
  }

  private subscribeToPermissions(krillEvent) {
    this.requestScansService.getPermissions().subscribe(
      (permissions) => {
        this.onPermissionsResult(permissions, krillEvent);
      }
    );
  }

  private subscribeToRequest() {
    this.patientRequestDoctorHelper.request.subscribe((request) => {
      if (request) {
        this.requestReferenceInputValue = `${request.prefix}-${request.num}`;
        this.currentRequestReference = `${request.prefix}-${request.num}`;
      }
    });
  }

  private onPermissionsResult(permissions, krillEvent) {
    this.permissions = permissions;

    if (this.permissions.find) {
      if (this.aRequestWasPassedIn(krillEvent)) {
        this.requestId = krillEvent.payload.request;
        this.getDataAssociatedWithRequest(this.requestId);
      }

      this.refreshUnallocatedScans();
      this.detectChanges(); // So we have both top and bottom doc lists for calculating heights
      this.onResize();
    } else {
      this._ngZone.runOutsideAngular(() => {
        this.toastService.pop('warning', 'You do not have permission to view this page.');
      });
    }
  }

  private getDataAssociatedWithRequest(request: any) {
    this.fetchPatientRequestDoctorDetails(request);
    this.fetchListOfDocumentsInRequest(request);
  }

  private aRequestWasPassedIn(krillEvent) {
    return krillEvent.payload && krillEvent.payload.request && krillEvent.payload.request.trim();
  }

  private fetchPatientRequestDoctorDetails(request) {
    this.patientRequestDoctorHelper.fetchPatientRequestDoctorFromRequestId(request);
  }

  private fetchListOfDocumentsInRequest(request: any) {
    this.documentMetaDataSub = this.requestScansService.getScanMetaDataByRequest(request).subscribe(
      (documents) => {
        if (documents) {
          this.assignedDocuments = documents;
          this.updateSelection();
        } else {
          this.onRequestNotFound();
        }
      },
      (error) => {
        this.onNetworkError();
        throw error;
      });
  }

  private clearRequestScanData() {
    this.pdfUrl = null;
    this.fileName = '';

    // Make sure pdfUrl gets picked up by the viewer so we can show a loading icon properly
    this.detectChanges();
  }

  private refreshUnallocatedScans() {
    this.requestScansService.getUnallocatedScans().subscribe((result) => {
      this.unassignedDocuments = result;
    });
  }

  private selectFirstAssignedDocument() {
    if (this.assignedDocuments && this.assignedDocuments.length) {
      this.selectedAssignedDocument = this.assignedDocuments[0];
      this.setRequestScanPdfData(this.selectedAssignedDocument);
    }
  }

  private isAnEventToStartComponent(eventData: any) {
    return eventData && ((eventData.event === 'menu' && eventData.payload && eventData.payload.module === 'request-scans') ||
      eventData.event === 'document' || // show a particular pdf
      eventData.event === 'browser'); // browser means we just got a token and can now call getTemplatePermissions
  }

  onAssignPressed() {
    if (this.selectedUnassignedDocument) {

      this.selectedUnassignedDocument.request = this.requestId;

      this.requestScansService.updateScan(this.selectedUnassignedDocument).subscribe((updatedScan) => {
        this.removeDocumentFromList(this.selectedUnassignedDocument, this.unassignedDocuments);
        this.addDocumentToList(updatedScan, this.assignedDocuments);
        this.selectedAssignedDocument = updatedScan;
        this.deselectUnassignedDocument();
      });
    }
  }

  onUnassignPressed() {
    if (this.selectedAssignedDocument) {
      this.selectedAssignedDocument.request = '0';
      this.requestScansService.updateScan(this.selectedAssignedDocument).subscribe((updatedScan) => {
        this.removeDocumentFromList(this.selectedAssignedDocument, this.assignedDocuments);
        this.addDocumentToList(updatedScan, this.unassignedDocuments);
        this.selectedUnassignedDocument = updatedScan;
        this.deselectAssignedDocument();
      });
    }
  }


  private removeDocumentFromList(document, documentList) {
    const index = documentList.indexOf(document);

    if (index > -1) {
      documentList.splice(index, 1);
    }
  }

  private addDocumentToList(document, documentList) {
    documentList.push(document);
  }

  private onRequestNotFound() {
    this.deselectAssignedDocument();
    this.deselectUnassignedDocument();
    this.showRequestNotFoundToast();
  }

  private showRequestNotFoundToast() {
    this._ngZone.runOutsideAngular(() => {
      this.toastService.pop('warning', 'Request not found');
    });
  }

  private setRequestScanPdfData(requestScan) {
    if (requestScan.ri) {
      this.clearRequestScanData();

      this.pdfUrl = this.requestScansService.getDocumentUrl(requestScan.ri);
      this.fileName = `${requestScan.name}.pdf`;
    }
  }

  onUnassignedDocumentChanged(document: DocumentModel) {
    this.selectedUnassignedDocument = document;

    if (this.selectedUnassignedDocument) {
      this.deselectAssignedDocument();
      this.setRequestScanPdfData(this.selectedUnassignedDocument);
    }
  }

  private deselectAssignedDocument() {
    this.selectedAssignedDocument = null;
  }

  onAssignedDocumentChanged(document) {
    this.selectedAssignedDocument = document;

    if (this.selectedAssignedDocument) {
      this.deselectUnassignedDocument();
      this.setRequestScanPdfData(this.selectedAssignedDocument);
    }
  }

  onPdfLoadError() {
    this.onNetworkError();
    throw new Error('Failed to fetch scan');
  }


  private deselectUnassignedDocument() {
    this.selectedUnassignedDocument = null;
  }

  @HostListener('window:resize', ['$event'])
  onResize() {
    if (this.componentsAreValid()) {
      this.calculateUnassignedDocumentListHeight();
    }
  }

  private componentsAreValid() {
    return this.docTopList || this.docBottomList;
  }

  private calculateUnassignedDocumentListHeight() {
    let topListHeight;
    const containerHeight = this.docListsContainer.nativeElement.clientHeight;
    if (this.docTopList) {
      topListHeight = this.docTopList.nativeElement.clientHeight;
    } else {
      topListHeight = 0;
    }
    if (this.docBottomList) {
      this.bottomDocumentListHeight = containerHeight - (topListHeight + 190);
    }
  }

  confirmDelete(template: TemplateRef<any>) {
    this.confirmDeleteDialog = this.modalService.show(template);
  }

  doDelete() {
    if (this.selectedUnassignedDocument) {
      this.requestScansService.deleteScan(this.selectedUnassignedDocument).subscribe(() => {
        const index = this.unassignedDocuments.indexOf(this.selectedUnassignedDocument);
        this.removeDocumentFromList(this.selectedUnassignedDocument, this.unassignedDocuments);
        this.deselectUnassignedDocument();
        if (this.unassignedDocuments[index]) {
          this.onUnassignedDocumentChanged(this.unassignedDocuments[index]);
        }
        this.confirmDeleteDialog.hide();
      });
    }
  }

  requestChanged() {
    this.deselectAssignedDocument();
    this.detectChanges(); // So we have both top and bottom doc lists for calculating heights
    this.calculateUnassignedDocumentListHeight();
  }

  onRequestKeyUp(event, inputValue) {
    if (event.keyCode === 13) {
      this.getRequest(inputValue);
    }
  }

  getRequest(reference) {
    if (reference) {
      this.requestScansService.searchRequests(reference).subscribe((results) => {
        if (results.length === 1) {
          this.requestId = results[0].ri;
          this.patientRequestDoctorHelper.receiveNewRequest(results[0]);
          this.requestChanged();
          this.fetchListOfDocumentsInRequest(results[0].ri);
          return;
        }
        this.requestChanged();
        this.clearRequest();
        this.showRequestNotFoundToast();
      });
    }
  }

  updateSelection() {
    if (this.selectedAssignedDocument) {
      this.deselectAssignedDocument();
    }
    if (!this.selectedUnassignedDocument) {
      this.selectFirstAssignedDocument();
    }
  }

  clearRequest() {
    this.requestId = null;
    this.currentRequestReference = '';
    this.patientRequestDoctorHelper.resetObservables();
    this.clearSearchInput();
    this.deselectAssignedDocument();
    this.detectChanges(); // So we have both top and bottom doc lists for calculating heights
    this.calculateUnassignedDocumentListHeight();
  }

  clearSearchInput() {
    this.requestReferenceInputValue = '';
  }

  detectChanges() {
    if (this.viewActive) {
      this.changeDetector.detectChanges();
    }
  }

  populateSearchInput() {
    setTimeout(() => {
      this.requestReferenceInputValue = this.currentRequestReference;
    }, 200);
  }

}
