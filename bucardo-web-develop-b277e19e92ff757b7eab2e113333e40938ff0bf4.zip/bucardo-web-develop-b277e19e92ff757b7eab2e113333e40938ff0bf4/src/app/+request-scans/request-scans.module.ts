import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {RouterModule} from '@angular/router';
import {SharedModule} from '../shared/shared.module';
import {RequestScansComponent} from './request-scans.component';
import {RequestScansRoutes} from './request-scans.routes';
import {DocumentListComponent} from './shared/document-list/document-list.component';
import {FormsModule} from '@angular/forms';
import {ModalModule} from 'ngx-bootstrap';

@NgModule({
  imports: [
    ModalModule.forRoot(),
    CommonModule,
    RouterModule.forChild([RequestScansRoutes]),
    SharedModule,
    FormsModule
  ],
  declarations: [RequestScansComponent, DocumentListComponent]
})
export class RequestScansModule { }
