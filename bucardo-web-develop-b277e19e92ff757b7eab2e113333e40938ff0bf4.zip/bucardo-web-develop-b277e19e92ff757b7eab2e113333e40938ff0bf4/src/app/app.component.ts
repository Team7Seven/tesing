import {AfterViewInit, Component, ViewContainerRef} from '@angular/core';
import {AuthGuard} from './guards/auth.guard';
import {AuthenticationService} from './shared/services/authentication/authentication.service';
import {ConfigurationService} from './shared/services/configuration/configuration.service';
import {Toast, ToasterService} from 'angular2-toaster';
import {ApiErrorHandler} from './shared/services/api-client/api-error-handler';

/**
 * This class represents the main application component. Within the @Routes annotation is the configuration of the
 * applications routes, configuring the paths for the lazy loaded components (HomeComponent, AboutComponent).
 */
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  providers: [AuthGuard, AuthenticationService]
})
export class AppComponent implements AfterViewInit  {
  constructor(public viewContainerRef: ViewContainerRef, private config: ConfigurationService, private toastService: ToasterService) {

  }

  ngAfterViewInit(): void {
    if (!this.config.isInitialised()) {
      this.popNoConnectionToast();
    }
  }

  private popNoConnectionToast() {
    const toast: Toast = {
      type: 'error',
      title: 'Error',
      body: ApiErrorHandler.noServiceMsg,
      timeout: 0,
      showCloseButton: false
    };

    this.toastService.pop(toast);
  }
}
