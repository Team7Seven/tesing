import {ActionReducer, Action} from '@ngrx/store';
import {Login} from '../models/login.model';

export const LOGIN_RECEIVED_AUTH_DATA = 'LOGIN_RECEIVED_AUTH_DATA';

export const LoginAuthDataReducer: ActionReducer<Array<Login>> = (state: Login[] = [], action: Action) => {
  switch (action.type) {
    case LOGIN_RECEIVED_AUTH_DATA:
      return action.payload;
    default:
      return state;
  }
};
