import {Component, OnInit} from '@angular/core';
import {Login} from './shared/models/login.model';
import {AuthenticationService} from '../shared/services/authentication/authentication.service';
import {Router} from '@angular/router';

/**
 * This class represents the lazy loaded AuthenticationComponent.
 */
@Component({
  selector: 'orac-authentication',
  templateUrl: 'login.component.html',
  styleUrls: ['login.component.scss'],
  providers: [AuthenticationService]
})

export class LoginComponent implements OnInit {

  submitted = false;
  regulatoryText = 'Sample Regulatory Text Regulatory Text Regulatory Text Regulatory Text';
  version = '2.0.0';
  model = new Login('', '', '', '', '');
  errorMessage = '';
  loading = false;

  /**
   * Creates an instance of the AuthenticationComponent with the injected
   * AuthenticationService.
   *
   * @param {AuthenticationService} authenticationService - The injected AuthenticationService.
   */
  constructor(private _authenticationService: AuthenticationService, private router: Router) {
  }

  ngOnInit() {
    // reset login status
    this._authenticationService.logout();
  }

  onSubmit() {
    this.loading = true;
    this._authenticationService.login(this.model)
      .subscribe((result) => {
        if (result) {
          this.router.navigate(['/management-report']);
        } else {
          // login failed
          this.errorMessage = 'Username or password is incorrect';
          this.loading = false;
        }
      });
  }
}

