/* tslint:disable:no-unused-variable */
import {ComponentFixture, TestBed} from '@angular/core/testing';
import {LoginComponent} from './login.component';
import {FormsModule} from '@angular/forms';
import {AuthenticationService} from '../shared/services/authentication/authentication.service';
import {Router} from '@angular/router';
import {Login} from './shared/models/login.model';
import {Observable} from 'rxjs/Observable';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let authServiceMock: MockAuthService;
  let routerMock: MockRouter;

  class MockAuthService {
    login = jasmine.createSpy('login');
    logout = jasmine.createSpy('logout');
  }

  class MockRouter {
    navigate = jasmine.createSpy('navigate');
  }

  beforeEach(() => {
    authServiceMock = new MockAuthService();
    routerMock = new MockRouter();

    TestBed.configureTestingModule({
      imports: [FormsModule],
      declarations: [LoginComponent]
    }).overrideComponent(LoginComponent, {
        set: {
          providers: [
            {provide: AuthenticationService, useValue: authServiceMock},
            {provide: Router, useValue: routerMock}
          ]
        }
      }
    );

    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;

    fixture.detectChanges();
  });


  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should reset login details when initialising', () => {
    component.ngOnInit();
    expect(authServiceMock.logout).toHaveBeenCalled();
  });

  it('should call login on submit', () => {
    setLoginResult(true);

    component.model = new Login('bobert', 'Jumbone', 'Bob', 'McConnell', '');
    component.onSubmit();
    expect(authServiceMock.login).toHaveBeenCalledWith(component.model);
  });

  it('should navigate to management-report on successful login', () => {
    setLoginResult(true);

    component.onSubmit();
    expect(routerMock.navigate).toHaveBeenCalledWith(['/management-report']);
  });

  it('should not navigate to dashboard on fail', () => {
    setLoginResult(false);

    component.onSubmit();
    expect(routerMock.navigate).not.toHaveBeenCalled();
  });

  function setLoginResult(result: any) {
    authServiceMock.login = jasmine.createSpy('login').and.returnValue(Observable.from([result]));
  }

});
