import {TestTools} from '../test-tools';
import {RequestScansPage} from "./request-scans.po";

describe('Request Scans', () => {

    const tools = new TestTools();
    const po = new RequestScansPage(tools);

    beforeEach(() => {
        cy.server();
        cy.route('/Document/$getContent?document=*').as('getPdf');
        cy.route('/Patient/*').as('getPatient');
        cy.route('/Request**').as('getRequest');
        cy.route('/Request/3822').as('getSecondRequest');
        cy.route('/Request/716').as('getFirstRequest');
        cy.route('/Document?request=716').as('getAssignedDocs');
        cy.route('/Document?request=none').as('getUnassignedDocs');
        cy.route('/Doctor/*').as('getDoctor');
        cy.route('POST', '/Proc/$logEvent').as('logError');
    });

    describe('with permissions', () => {

        describe('with request specified', () => {

            beforeEach(() => {
                tools.navigateToWaiting();

                po.loadScanPageWithRequest('716');

                cy.wait('@getPdf', {timeout: 30000});
            });

            it('should navigate to url', () => {
                cy.contains('Request Scans');
            });

            it('should show patient details', () => {
                po.waitForPatientRoute();

                po.patientNumber.contains('1234567890');
            });

            it('should show assigned and unassigned document lists', () => {
                cy.wait('@getAssignedDocs');
                cy.wait('@getUnassignedDocs');

                cy.get('#assignedDocuments ul>li').should('not.be.empty');
                po.unassignedDocs.should('not.be.empty');
            });

            it('should show scan svg element', () => {
                po.scanElement.should('be.visible');
            });

            it('should be able to assign an unallocated scan to the loaded request', () => {
                cy.route('/Document/*').as('updateRequest');

                po.firstUnassignedDocument.then((unassignedReport) => {
                    const firstUnassignedReportName = unassignedReport.text();
                    unassignedReport.click();
                    po.assignButton.click();

                    cy.wait('@updateRequest').wait(500);

                    po.lastAssignedDoc.then(lastAssignedReport => {
                        expect(firstUnassignedReportName).to.equal(lastAssignedReport.text());
                    });

                });
            });

            it('should be able to unassign an allocated scan', () => {
                cy.route('/Document/*').as('updateRequest');

                po.lastAssignedDoc.then((assignedReport) => {
                    const lastAssignedReportName = assignedReport.text();
                    assignedReport.click();
                    po.unassignButton.click();

                    cy.wait('@updateRequest').wait(500);

                    po.lastUnassignedDoc.then(lastUnassignedReport => {
                        expect(lastAssignedReportName).to.equal(lastUnassignedReport.text());
                    });
                });
            });

        });

        describe('without request specified', () => {
            beforeEach(() => {
                cy.server();
                cy.route('/Document?request=none').as('getUnassignedDocs');

                tools.navigateToWaiting();

                po.loadScanPage();

                cy.wait('@getUnassignedDocs');
            });

            it('should not show a scan document', () => {
                po.scanElement.should('not.exist');
            });

            it('should show the list of unallocated scans', () => {
                po.unassignedDocs.should('not.be.empty');
            });

            it('should not show the list of allocated scans', () => {
                po.assignedDocs.should('not.exist');
            });
        });

    });

    describe('with no permissions', () => {
        beforeEach(() => {
            const bid = 'permno';
            tools.navigateToWaiting(bid, 'test1234');
            po.loadScanPageWithRequest('716', bid);
        });

        it('does not show scan, just a warning toast', () => {
            po.scanElement.should('not.exist');
            tools.warningToast.contains('You do not have permission to view this page');
        });

    });

    describe('changing requests', () => {
        beforeEach(() => {
            tools.navigateToWaiting();
            po.loadScanPageWithRequest('716');

            cy.wait('@getPdf', {timeout: 30000});
            cy.wait('@getFirstRequest');
        });

        it('should load the new request details when a new one is selected', () => {
            po.requestName.then((initialRequestName) => {
                const initialRequestNameText = initialRequestName.text();
                po.searchForRequest('16-100436');

                po.requestName.then((currentRequestName) => {
                    expect(initialRequestNameText).not.to.equal(currentRequestName.text());
                });
            });
        });

        it('should save a document to the first request in the list', () => {
            po.searchForRequest('16-100436');

            cy.route('PUT', '/Document/*').as('updateRequest');

            po.firstUnassignedDocument.then((unassignedDoc) => {
                const firstUnassignedDocName = unassignedDoc.text();
                unassignedDoc.click();
                po.assignButton.click();

                cy.wait('@updateRequest').wait(500);

                po.lastAssignedDoc.then(lastAssignedDoc => {
                    expect(firstUnassignedDocName).to.equal(lastAssignedDoc.text());
                    po.unassignButton.click(); // Clear up after
                    tools.toast.should('not.exist');
                });

            });
        });
    });

    describe('deleting document', () => {
        beforeEach(() => {
            cy.route({
                method: 'DELETE',
                url: 'Document/*',
                response: ''
            }).as('deleteDocument');

            tools.navigateToWaiting();
            po.loadScanPageWithRequest('716');

            cy.wait('@getAssignedDocs');
            cy.wait('@getUnassignedDocs');
        });

        it('should show delete confirmation', () => {
            po.firstUnassignedDocument.click();
            po.deleteButton.click();

            po.deleteDialog.contains('Delete');
        });

        it('should remove the document from the unassigned list after a delete', () => {
            po.allUnassignedDocs.then((reportsBeforeDelete) => {
                po.firstUnassignedDocument.click();
                po.deleteButton.click();

                po.deleteDialog.within(() => {
                    cy.get('.btn-primary').click();
                    cy.wait('@deleteDocument');
                });

                po.allUnassignedDocs.then((reportsAfterDelete) => {
                    expect(reportsAfterDelete.length).to.be.lessThan(reportsBeforeDelete.length);
                });
            });

        });
    });

    describe('invalid request entered', () => {

        beforeEach(() => {
            tools.navigateToWaiting();

            po.loadScanPageWithRequest('716');

            cy.wait('@getPdf', {timeout: 30000});
            po.searchForRequest('999999999');

            cy.wait('@getUnassignedDocs');
        });

        it('does not show scan, just a warning toast', () => {
            po.scanElement.should('not.exist');
            tools.warningToast.contains('Request scan not found');
            po.assignButton.should('be.disabled');
        });

    });


    describe('Network Failures', () => {

        function loadFirstRequest() {
            tools.navigateToWaiting();
            po.loadScanPageWithRequest('716');

            cy.wait(['@getPatient', '@getFirstRequest', '@getDoctor', '@getPdf', '@getAssignedDocs', '@getUnassignedDocs']);
        }

        function shouldClearEverything() {
            po.scanElement.should('not.exist');
            po.patientDetails.should('not.exist');
            po.requestDetails.should('not.exist');
            po.doctorDetails.should('not.exist');
            po.assignedDocs.should('not.exist');
            po.searchBox.should('have.value', '');
        }

        describe('fail to get document', () => {

            function loadSecondRequest() {
                po.loadScanPageWithRequest('3822');
                cy.wait(['@getPdfError']);
            }

            beforeEach(() => {
                loadFirstRequest();

                // Stub the queryReport call to fail
                cy.route({
                    method: 'GET',
                    url: 'Document/$getContent?document=*',
                    response: '',
                    status: 500
                }).as('getPdfError');

                loadSecondRequest();
            });

            it('should show an error and log it', () => {
                tools.errorToast.should('be.visible');
                cy.wait('@logError');
            });

            it('should not show any patient / request / doctor / document', () => {
                shouldClearEverything();
                cy.wait('@logError');
            });
        });


        describe('fail to get list of documents for a request', () => {

            function loadSecondRequest() {
                po.loadScanPageWithRequest('3822');
                cy.wait(['@getAssignedDocsError']);
            }

            beforeEach(() => {
                loadFirstRequest();

                // Stub the queryReport call to fail
                cy.route({
                    method: 'GET',
                    url: '/Document?request=3822',
                    response: '',
                    status: 500
                }).as('getAssignedDocsError');

                loadSecondRequest();
            });

            it('should show an error and log it', () => {
                tools.errorToast.should('be.visible');
                cy.wait('@logError');
            });

            it('should not show any patient / request / doctor / document', () => {
                shouldClearEverything();
                cy.wait('@logError');
            });
        });

        describe('fail to get doctor record', () => {

            function loadSecondRequest() {
                po.loadScanPageWithRequest('3822');
                cy.wait(['@getDoctorError']);
            }

            beforeEach(() => {
                loadFirstRequest();

                // Stub the queryReport call to fail
                cy.route({
                    method: 'GET',
                    url: '/Doctor/*',
                    response: '',
                    status: 500
                }).as('getDoctorError');

                loadSecondRequest();
            });

            it('should show an error and log it', () => {
                tools.errorToast.should('be.visible');
                cy.wait('@logError');
            });

            it('should not show any patient / request / doctor / document', () => {
                shouldClearEverything();
                cy.wait('@logError');
            });
        });

        describe('fail to get patient record', () => {

            function loadSecondRequest() {
                po.loadScanPageWithRequest('3822');
                cy.wait(['@getPatientError']);
            }

            beforeEach(() => {
                loadFirstRequest();

                // Stub the queryReport call to fail
                cy.route({
                    method: 'GET',
                    url: '/Patient/*',
                    response: '',
                    status: 500
                }).as('getPatientError');

                loadSecondRequest();
            });

            it('should show an error and log it', () => {
                tools.errorToast.should('be.visible');
                cy.wait('@logError');
            });

            it('should not show any patient / request / doctor / document', () => {
                shouldClearEverything();
                cy.wait('@logError');
            });
        });
    });

});
