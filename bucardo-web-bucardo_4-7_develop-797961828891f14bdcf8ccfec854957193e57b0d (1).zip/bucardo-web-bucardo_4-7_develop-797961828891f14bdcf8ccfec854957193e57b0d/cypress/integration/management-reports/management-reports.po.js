import {TestTools} from "../test-tools";

/** @type {TestTools} */
let tools;

export class ManagementReportsPage {

    constructor(testTools) {
        tools =  testTools;
    }

    navigateToReports(bid = 'boat', pass = 'cats1122') {
        const body = '{"app": "gmaster","formname": "management-report"}';
        tools.navigateToWaiting(bid, pass);
        tools.navigateToPage('menu', body, bid);
    }

    get reportTree() {
        return cy.get('.tree-view-wrapper');
    }

    get reportFilter() {
        return cy.get('#mg-rpt-filter');
    }

    get treeNodes() {
        return cy.get('management-tree-node > ul.branch > li.node');
    }

    get params() {
        return cy.get('#management-report-params');
    }

    get htmlButton() {
        return cy.get('#html-button');
    }

    get pdfButton() {
        return cy.get('#pdf-button');
    }

    get xlsButton() {
        return cy.get('#xls-button');
    }

    get uploadButton() {
        return cy.get('#uploadRptButton');
    }

    get deleteButton() {
        return cy.get('#deleteRptButton');
    }

    get updateButton() {
        return cy.get('#updateRptButton');
    }

    get deleteConfirm() {
        return cy.get('#submitButtonDelete');
    }

    get updateConfirm() {
        return cy.get('#submitButtonUpdate');
    }

    get cancelButtonDelete() {
        return cy.get('#cancelButtonDelete');
    }

    get cancelButtonUpdate() {
        return cy.get('#cancelButtonUpdate');
    }

    get modalForm() {
        return cy.get('.modal-content');
    }

    get reportUploadButton() {
        return cy.get('#submitButton');
    }

    get pdfSvgHolder() {
        return cy.get('svg');
    }

    get iFrame() {
        return cy.get('iframe');
    }

    get reportName() {
        return cy.get('#selectedReportName');
    }

    get loadingSpinner() {
        return cy.get('.loadingSpinner');
    }

    get integerTextbox() {
        return cy.get('#integerTextbox');
    }

    get stringTextbox() {
        return cy.get('#stringTextbox');
    }

    get radio3() {
        return cy.get('#Radio3');
    }

    get listBoxOptions() {
        return cy.get('#listBoxOptions');
    }

    get decimalParam() {
        return cy.get('#decimalParam');
    }

}
