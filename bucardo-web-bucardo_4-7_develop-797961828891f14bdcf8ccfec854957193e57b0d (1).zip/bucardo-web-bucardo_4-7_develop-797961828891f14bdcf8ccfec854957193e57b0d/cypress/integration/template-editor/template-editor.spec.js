import {TestTools} from '../test-tools';
import {TemplateEditorPage} from "./template-editor.po";

const tools = new TestTools();
const po = new TemplateEditorPage(tools);

describe('Template Editor', () => {

    const MAX_CODE_LENGTH = 14;
    let randomTemplateCode;

    function createTemplateWithValues(code, name, content, clazz = 'formats', style = 'freeform', script = 'somescript.js', bid = 'boat') {
        po.clickNew();

        po.code.type(code);
        po.name.type(name);
        po.script.type(script);

        po.clazz.select(clazz);
        cy.wait('@getStyleList');
        po.style.select(style);

        tools.setIFrameContents(content);

        po.clickSave();
        po.clickNew();

        tools.navigateToPage('template', 'where=' + JSON.stringify({code: code}), bid);
        po.templateList.should('have.value', code);
    }

    function testCreationWithValues(code, name, content, clazz = 'formats', style = 'freeform', script = 'somescript.js', bid = 'boat') {
        createTemplateWithValues(code, name, content, clazz, style, script, bid);

        po.code.should('have.value', code);
        po.name.should('have.value', name);
        po.clazz.should('have.value', clazz);
        po.style.should('have.value', style);
        po.script.should('have.value', script);

        tools.iFrameContains(content);
    }

    function fillTemplateForm(content = 'fake content', code = 'fakecode', name = 'fakename') {
        tools.setIFrameContents(content);
        po.code.clear().type(code);
        po.name.clear().type(name);
        po.clazz.select('Body Format');
        po.style.select('Serial By Row');
    }

    beforeEach(() => {
        randomTemplateCode = tools.makeId('TEST_', 10);
        cy.server();
        cy.route('/PatRptTemplate/$styleList?class=*').as('getStyleList');
        cy.route('/PatRptTemplate/$classList').as('getClassList');
        cy.route('/PatRptTemplate?_summary=short').as('getTemplateList');
        cy.route('/PatRptTemplate/E2E*').as('getTemplate');
        cy.route('/PatRptTemplate/$perms').as('getPerms');
        cy.route('POST', '/PatRptTemplate').as('createTemplate');
        cy.route('PUT', '/PatRptTemplate/*').as('updateTemplate');
        cy.route('POST', '/Proc/$logEvent').as('logError');
    });

    describe('typical template', () => {
        beforeEach(() => {
            tools.navigateToWaiting();
            po.navToTemplate('E2ESERIALR');

            cy.wait(['@getStyleList', '@getTemplateList', '@getTemplate', '@getClassList'])
        });

        it('should navigate to url', () => {
            cy.contains('Template Configuration');
        });

        it('should load a template', () => {
            po.code.should('have.value', 'E2ESERIALR');
            po.name.should('have.value', 'E2E Serial By Row');
            po.clazz.should('have.value', 'formats');
            po.style.should('have.value', 'serialrow');

            tools.iFrameContains('^^ITEM');
        });

        it('should switch to a different template using the dropdown', () => {
            po.templateList.select('E2ESINGLE');

            cy.wait(['@getTemplate', '@getStyleList']);

            po.code.should('have.value', 'E2ESINGLE');
            po.name.should('have.value', 'E2E Single');
            po.clazz.should('have.value', 'formats');
            po.style.should('have.value', 'single');

            tools.iFrameContains('^^ITEM');
        });


        it('should switch to a different template using a KRILL event', () => {
            po.navToTemplate('E2ESINGLE');

            cy.wait(['@getTemplate', '@getStyleList']);

            po.code.should('have.value', 'E2ESINGLE');
            po.name.should('have.value', 'E2E Single');
            po.clazz.should('have.value', 'formats');
            po.style.should('have.value', 'single');

            tools.iFrameContains('^^ITEM');
        });
    });

    describe('Creating Templates', () => {
        beforeEach(() => {
            tools.navigateToWaiting();
            po.navToPage();
        });

        it('should clear fields when new is pressed', () => {
            po.navToTemplate('E2ESERIALR');
            cy.wait(['@getStyleList', '@getTemplateList', '@getTemplate', '@getClassList']);

            po.clickNew();

            po.code.should('have.value', '');
            po.name.should('have.value', '');
            po.clazz.should('have.value', null);
            po.style.should('have.value', null);
            po.script.should('have.value', '');
        });


        it('should create a new template and reload it', () => {
            testCreationWithValues(randomTemplateCode,
                `${randomTemplateCode}_NAME`,
                `<p>${randomTemplateCode} CONTENT</p>`);
        });

        it('should update a template and reload it', () => {
            createTemplateWithValues(randomTemplateCode,
                `${randomTemplateCode}_NAME`,
                `<p>${randomTemplateCode} CONTENT</p>`);

            tools.setIFrameContents(`UPDATED_TEXT_${randomTemplateCode}`);

            po.clickSave(true);
            po.clickNew();

            tools.navigateToPage('template', 'where=' + JSON.stringify({code: randomTemplateCode}), 'boat');

            tools.iFrameContains(`UPDATED_TEXT_${randomTemplateCode}`);
        });

        it('should show an error when creating a template that already exists', () => {
            fillTemplateForm(`<p>${randomTemplateCode} CONTENT</p>`, 'E2ESINGLE', `${randomTemplateCode}_NAME`);

            po.saveButton.click();
            cy.wait('@createTemplate');

            tools.errorToast.should('contain', 'Resource already present');
        });
    });

    describe('Max Field Size', () => {

        beforeEach(() => {
            tools.navigateToWaiting();
            po.navToTemplate('E2ESERIALR');

            cy.wait(['@getStyleList', '@getTemplateList', '@getTemplate', '@getClassList'])
        });

        it('should cope with normal-length chars in maximum length code', () => {
            const maxLengthCode = tools.makeId('TEST_', MAX_CODE_LENGTH);
            testCreationWithValues(maxLengthCode, maxLengthCode + '_NAME', maxLengthCode + '_CONTENT');
        });

        it.skip('should cope with double-length chars in maximum length code', () => {
            const maxLengthCode = tools.makeId('TEST_', MAX_CODE_LENGTH - 4) + '££££';
            testCreationWithValues(maxLengthCode, randomTemplateCode + '_NAME', randomTemplateCode + '_CONTENT');
        });

        it.skip('should cope with double-length chars in maximum length name', () => {
            testCreationWithValues(randomTemplateCode, randomTemplateCode + '££££££££££', randomTemplateCode + '_CONTENT');
        });

    });

    describe('Permissions', () => {
        describe('Accessing with no permissions', () => {
            beforeEach(() => {
                tools.navigateToWaiting('permno', 'test1234');
                po.navToTemplate('E2ESINGLE', 'permno');
                cy.wait('@getPerms');
            });

            it('does not show anything when user has no permissions', () => {
                po.editorControls.should('not.exist');
                po.htmlEditor.should('not.exist');

                tools.warningToast.contains('You do not have permission to view this page');
            });

        });

        describe('Accessing with only find permissions', () => {
            beforeEach(() => {
                po.navToDefaultTemplateWithUser('permf');
            });

            it('does show the form and ckeditor', () => {
                po.editorControls.should('exist');
                po.htmlEditor.should('exist');
            });

            it('disables new and save button', () => {
                po.saveButton.should('not.be.enabled');
                po.newButton.should('not.be.enabled');
            });
        });

        describe('Accessing with only find and add permissions', () => {
            beforeEach(() => {
                po.navToDefaultTemplateWithUser('permfa');
            });

            it('save button is disabled and new button is enabled on page load', () => {
                po.saveButton.should('not.be.enabled');
                po.newButton.should('be.enabled');
            });

            it('enables the save button after new is pressed and form is filled', () => {
                po.clickNew();
                fillTemplateForm();
                po.saveButton.should('be.enabled');
            });

            it('disables the save button after a template is selected after the new button was pressed', () => {
                po.clickNew();
                po.templateList.select('E2ESERIALR');

                po.saveButton.should('not.be.enabled');
            });
        });

        describe('Accessing with only find and change permissions', () => {
            beforeEach(() => {
                po.navToDefaultTemplateWithUser('permfc');
            });

            it('save button is enabled and new button is disabled on page load', () => {
                po.saveButton.should('be.enabled');
                po.newButton.should('not.be.enabled');
            });
        });
    });

    describe('Network Failures', () => {

        beforeEach(() => {
            tools.navigateToWaiting('boat', 'cats1122');

            po.navToTemplate('E2ESERIALR', 'boat');
            cy.wait(['@getStyleList', '@getTemplateList', '@getTemplate', '@getClassList']);
        });

        describe('Failure list of templates', () => {

            beforeEach(() => {
                cy.route({
                    url: '/PatRptTemplate?_summary=short',
                    status: 500,
                    response: ''
                }).as('getTemplateListError');

                po.navToTemplate('E2ESINGLE', 'boat');
                cy.wait(['@getTemplateListError']);
            });

            it('should show an error toast', () => {
                tools.errorToast.should('be.visible');
                cy.wait('@logError');
            });

            it('should have an empty form and htmlEditor', () => {
                po.code.should('have.value', '');
                po.name.should('have.value', '');
                tools.iFrameShouldContainInitialValue();
                cy.wait('@logError');
            });
        });

        describe('Failure when getting template', () => {

            beforeEach(() => {

                cy.route({
                    url: '/PatRptTemplate/E2E*',
                    status: 500,
                    response: ''
                }).as('getTemplateError');

                po.navToTemplate('E2ESINGLE', 'boat');
                cy.wait(['@getTemplateList', '@getTemplateError', '@getClassList']);
            });

            it('should show an error toast', () => {
                tools.errorToast.should('be.visible');
                cy.wait('@logError');
            });

            it('should have an empty form and htmlEditor', () => {
                po.code.should('have.value', '');
                po.name.should('have.value', '');
                tools.iFrameShouldContainInitialValue();
                cy.wait('@logError');
            });
        });

        describe('when getting style list', () => {
            beforeEach(() => {
                cy.route({
                    url: '/PatRptTemplate/$styleList?class=*',
                    status: 500,
                    response: ''
                }).as('getStyleListError');

                po.navToTemplate('E2ESINGLE', 'boat');
                cy.wait(['@getStyleListError']);
            });

            it('should show an error toast', () => {
                tools.errorToast.should('be.visible');
                cy.wait('@logError');
            });

            it('should have an empty form and htmlEditor', () => {
                po.code.should('have.value', '');
                po.name.should('have.value', '');
                tools.iFrameShouldContainInitialValue();
                cy.wait('@logError');
            });
        });

        describe('when getting class list', () => {

            beforeEach(() => {
                cy.route({
                    url: '/PatRptTemplate/$classList',
                    status: 500,
                    response: ''
                }).as('getClassListError');

                po.navToTemplate('E2ESINGLE', 'boat');
                cy.wait(['@getClassListError']);
            });

            it('should show an error toast', () => {
                tools.errorToast.should('be.visible');
                cy.wait('@logError');
            });

            it('should have an empty form and htmlEditor', () => {
                po.code.should('have.value', '');
                po.name.should('have.value', '');
                tools.iFrameShouldContainInitialValue();
                cy.wait('@logError');
            });
        });

        describe('when creating a template', () => {
            beforeEach(() => {

                cy.route({
                    method: 'POST',
                    url: '/PatRptTemplate',
                    status: 500,
                    response: ''
                }).as('createTemplateError');

                po.navToTemplate('E2ESINGLE', 'boat');
                cy.wait(['@getStyleList', '@getTemplateList', '@getTemplate', '@getClassList']);

                po.clickNew();
                fillTemplateForm();

                po.saveButton.click();
                cy.wait('@createTemplateError');
            });

            it('should show an error toast', () => {
                tools.errorToast.should('be.visible');
                cy.wait('@logError');
            });

            it('should still show the editor and config', () => {
                po.code.should('have.value', 'fakecode');
                po.name.should('have.value', 'fakename');
                tools.iFrameContains('fake content');
                cy.wait('@logError');
            });
        });


        describe('when updating a template', () => {
            beforeEach(() => {
                cy.route({
                    method: 'PUT',
                    url: '/PatRptTemplate/*',
                    status: 500,
                    response: ''
                }).as('updateTemplateError');

                po.navToTemplate('E2ESINGLE', 'boat');
                cy.wait(['@getStyleList', '@getTemplateList', '@getTemplate', '@getClassList']);

                po.saveButton.click();
                cy.wait('@updateTemplateError');
            });

            it('should show an error toast', () => {
                tools.errorToast.should('be.visible');
                cy.wait('@logError');
            });

            it('should still show the editor and config', () => {
                po.code.should('have.value', 'E2ESINGLE');
                po.name.should('have.value', 'E2E Single');
                tools.iFrameContains('E2E Single');
                cy.wait('@logError');
            });
        });

    });
});
