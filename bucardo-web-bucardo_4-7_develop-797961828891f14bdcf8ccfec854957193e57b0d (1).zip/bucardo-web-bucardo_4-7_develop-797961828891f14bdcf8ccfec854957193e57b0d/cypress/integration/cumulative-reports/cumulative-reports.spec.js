import {TestTools} from '../test-tools';
import {CumulativeReportsPage} from "./cumulative-reports.po";

const tools = new TestTools();
const po = new CumulativeReportsPage();

describe('Cumulative Reports', () => {

    beforeEach(() => {
        cy.server();
        cy.route('/Document/$getContent**').as('getPdf');
        cy.route('/Patient/*').as('getPatient');
        cy.route('/Request/*').as('getRequest');
        cy.route('/Doctor/*').as('getDoctor');
        cy.route('/PatientReport/$perms').as('getPerms');
        cy.route('POST', '/PatientReport/$queryReport').as('getReport');
        cy.route('POST', '/Proc/$logEvent').as('logError');
    });

    describe('with no permissions', () => {
        beforeEach(() => {
            po.loadDefaultReportAsUser('permno', 'test1234', false);
        });

        it('does not show any patient, doctor, request, or report details', () => {
            po.doctorDetails.should('not.exist');
            po.patientDetails.should('not.exist');
            po.requestDetails.should('not.exist');
            po.reportIframe.should('not.exist');

            tools.warningToast.contains('You do not have permission to view this page');
        });
    });

    describe('with permissions', () => {
        beforeEach(() => {
            po.loadDefaultReportAsUser('boat', 'cats1122');
            cy.wait(['@getPatient', '@getRequest', '@getDoctor']);
        });

        it('shows patient, doctor, request, and report details', () => {
            po.doctorDetails.should('exist');
            po.patientDetails.should('exist');
            po.requestDetails.should('exist');
            po.reportIframe.should('exist');

            tools.warningToast.should('not.exist');

            po.patientId.contains('1234567890');
            po.requestId.contains('16-101147');
            po.doctorDetails.contains('TEST, DOCTOR');

            tools.iFrameContains('BLACK, JIMMY JOHN');
        });

    });

    describe('switching between users', () => {
        beforeEach(() => {
            po.loadDefaultReportAsUser('boat', 'cats1122');
            cy.wait(['@getPatient', '@getRequest', '@getDoctor']);

            po.navToReport('3822', 'CDM', 'CMRPT', 'boat');
            cy.wait(['@getPatient', '@getRequest', '@getDoctor']);
        });

        it('should have different patient ID', () => {
            po.patientId.contains('CHI-1205604098');
        });

        it('should have a different request ID', () => {
            po.requestId.contains('16-103725');
        });
    });

    describe('Network Failures', () => {

        function loadPatient72() {
            po.loadDefaultReportAsUser('boat', 'cats1122');
            cy.wait(['@getPatient', '@getRequest', '@getDoctor']);
        }

        function shouldClearEverything() {
            po.patientDetails.should('not.exist');
            po.requestDetails.should('not.exist');
            po.doctorDetails.should('not.exist');

            tools.iFrameShouldBeEmpty('BLACK, JIMMY JOHN');
        }

        describe('fail to get report contents', () => {

            function loadPatient71() {
                po.navToReport('3822', 'CDM', 'CMRPT', 'boat', false);
                cy.wait(['@getReportError']);
            }

            beforeEach(() => {
                loadPatient72();

                // Stub the queryReport call to fail
                cy.route({
                    method: 'POST',
                    url: '/PatientReport/$queryReport',
                    response: '',
                    status: 500
                }).as('getReportError');

                loadPatient71();
            });

            it('should show an error and log it', () => {
                tools.errorToast.should('be.visible');
                cy.wait('@logError');
            });

            it('should not show any patient / request / doctor / report', () => {
                shouldClearEverything();
                cy.wait('@logError');
            });
        });

        describe('fail to get doctor record', () => {

            function loadPatient71() {
                po.navToReport('3822', 'CDM', 'CMRPT', 'boat');
                cy.wait(['@getPatient', '@getRequest', '@getDoctorError']);
            }

            beforeEach(() => {
                loadPatient72();

                // Stub the queryReport call to fail
                cy.route({
                    method: 'GET',
                    url: '/Doctor/*',
                    response: '',
                    status: 500
                }).as('getDoctorError');

                loadPatient71();
            });

            it('should show an error and log it', () => {
                tools.errorToast.should('be.visible');
                cy.wait('@logError');
            });

            it('should not show any patient / request / doctor / report', () => {
                shouldClearEverything();
                cy.wait('@logError');
            });
        });

        describe('fail to get patient record', () => {

            function loadPatient71() {
                po.navToReport('3822', 'CDM', 'CMRPT', 'boat');
                cy.wait(['@getPatientError', '@getRequest', '@getDoctor']);
            }

            beforeEach(() => {
                loadPatient72();

                // Stub the queryReport call to fail
                cy.route({
                    method: 'GET',
                    url: '/Patient/*',
                    response: '',
                    status: 500
                }).as('getPatientError');

                loadPatient71();
            });

            it('should show an error and log it', () => {
                tools.errorToast.should('be.visible');
                cy.wait('@logError');
            });

            it('should not show any patient / request / doctor / report', () => {
                shouldClearEverything();
                cy.wait('@logError');
            });
        });
    });


});