import {TestTools} from "../test-tools";

const tools = new TestTools();

export class CumulativeReportsPage {

    navToReport(request, panel, doctor, bid = 'boat', waitForReportToLoad = true) {
        tools.navigateToPage('showcmpatreport', JSON.stringify({
            'request': request,
            'panel': panel,
            'doctor': doctor,
            'tiebreaker': '0',
            'pformat': ''
        }), bid);

        if (waitForReportToLoad) { // We want to skip this if user has no perms
            cy.wait('@getReport');
        } else {
            cy.wait('@getPerms');
        }
    }

    loadDefaultReportAsUser(user, pass = 'test1234', waitForReportToLoad = true) {
        tools.navigateToWaiting(user, pass);
        this.navToReport('1413', 'RCM', 'CMRPT', user, waitForReportToLoad);
    }

    get patientDetails() {
        return cy.get('#patient-details');
    }

    get doctorDetails() {
        return cy.get('doctor-details-data');
    }

    get requestDetails() {
        return cy.get('#request-details');
    }

    get reportIframe() {
        return cy.get('iframe');
    }

    get patientId() {
        return cy.get('patient-details-data .display-heading-section');
    }

    get requestId() {
        return cy.get('.patient-request-doctor-panel-heading');
    }
}
