import {TestTools} from '../test-tools';
import {FormatEditorPage} from "./format-editor.po";

const tools = new TestTools();
const po = new FormatEditorPage(tools);

describe('Format Editor', () => {

  beforeEach(() => {
    cy.server();
    cy.route('/PatRptTemplate/$styleList?class=*').as('getStyleList');
    cy.route('/PatRptTemplate/E2E*').as('getTemplate');
    cy.route('/PatRptFormat/**INV~1').as('getFormat');
    cy.route('/PatRptFormat/$perms').as('getPerms');
    cy.route('/PatRptTemplate?class=**').as('getClasses');
    cy.route('POST', '/Proc/$logEvent').as('logError');
    cy.route('PUT', '/PatRptFormat/24COR~INV~1').as('saveFormat');
  });

  describe('Cancel format selection', () => {

    beforeEach(() => {
      tools.navigateToWaiting();
      po.navToFormat('24COR');
      po.cancelButton.click();
    });

    it('should clear format screen', () => {
      po.formatCode.should('not.exist');
    });
  });

  describe('Loading Formats', () => {

    beforeEach(() => {
      tools.navigateToWaiting();
    });

    it('should navigate to url', () => {
      po.navToFormat('24COR', 'INV', '1');
      cy.contains('Lab Format Editor');
    });

    describe.skip('Format with slashes', () => {

      beforeEach(() => {
        cy.server();
        po.navToFormat('//////', 'INV', '1');
      });

      it('should load a format with slashes', () => {
        po.formatCode.should('eq', '//////');
      });

    });


    describe('Load Typical Format', () => {

      beforeEach(() => {
        po.navToFormat('24COR');
      });

      it('should load a format @smoke', () => {
        po.formatCode.should('have.value', '24COR');
        po.formatName.should('have.value', ' 24 HR URINE CORTISOL');
        po.formatProcessUsing.should('have.value', '=mpf');
      });

      it('should load a list of styles', () => {
        po.styles.then((styles) => {
          expect(styles.length).to.equal(5);
        });
      });

      it('should not load a list of classes', () => {
        po.classes.then((classes) => {
          expect(classes.length).to.equal(1); // Just the placeholder
        });
      });

      it('should load the template contents', () => {
        tools.iFrameContains('24 HR URINE CORTISOL CONTENT');
      });

      it('should be able to switch to another format', () => {
        po.navToFormat('GLU');
        tools.iFrameContains('~glu-0');
      });

    });

    describe('Loading from template', () => {

      beforeEach(() => {
        po.navToFormat('24COR', 'INV', '1');
      });

      it('should load template in editor when load in editor selected', () => {
        po.selectStyle('serialrow');
        po.templateCode.select('E2ESERIALR');

        po.loadInEditor.click();
        cy.wait('@getTemplate').wait(500);

        tools.iFrameContains('E2E Serial By Row');
      });

    });

    describe('Generating formats from templates', () => {

      beforeEach(() => {
        po.navToFormat('24COR', 'INV', '1');
      });

      function shouldReplacePlaceHoldersWithGlu(style, template) {
        po.selectStyle(style);
        po.templateCode.select(template).wait(500);

        po.loadInEditor.click();
        cy.wait('@getTemplate');

        po.items.type('glu');
        po.generateFormat.click();

        tools.iFrameContains('^glu');
        tools.iFrameDoesntContain('^Item');
      }

      it('should replace the item placeholders in the template when generating SERIAL format', () => {
        shouldReplacePlaceHoldersWithGlu('serialrow', 'E2ESERIALR');
      });

      it('should replace the item placeholders in the template when generating SINGLE format', () => {
        shouldReplacePlaceHoldersWithGlu('single', 'E2ESINGLE');
      });

    });

  });


  describe('Permissions', () => {

    describe('Accessing format editor without find permissions', () => {
      beforeEach(() => {
        po.loadDefaultFormatAsUser('permno', false);
      });

      it('should not display inputs or format information', () => {
        po.formatForm.should('not.exist');
        po.htmlEditor.should('not.exist');

        tools.warningToast.contains('You do not have permission to view this page');
      });

    });

    describe('Accessing format editor with only find and change permissions', () => {
      beforeEach(() => {
        po.loadDefaultFormatAsUser('permfc');
        po.selectStyle('serialrow');
        po.templateCode.select('E2ESERIALR');
      });

      it('displays inputs', () => {
        po.formatForm.should('exist');
        po.htmlEditor.should('exist');
      });

      it('enables save and load in editor buttons', () => {
        po.loadInEditor.should('be.enabled');
        po.saveButton.should('be.enabled');
      });
    });

    describe('Accessing format editor with only find and add permissions', () => {
      beforeEach(() => {
        po.loadDefaultFormatAsUser('permfa');
          po.selectStyle('serialrow');
          po.templateCode.select('E2ESERIALR');
      });

      it('displays inputs', () => {
        po.formatForm.should('exist');
        po.htmlEditor.should('exist');
      });

      it('disables save and load in editor buttons', () => {
        po.loadInEditor.should('not.be.enabled');
        po.saveButton.should('not.be.enabled');
      });
    });

  });

  describe('eTag testing', () => {
    beforeEach(() => {
      tools.navigateToWaiting();
      po.navToFormat('24COR');
    });

    it('should be able to save a format twice (eTags are updated successfully)', () => {
      po.saveButton.click();

      cy.wait('@saveFormat').wait(500);

      po.saveButton.click();

      cy.wait('@saveFormat').wait(500);

      tools.successToast.should('be.visible');
      tools.errorToast.should('not.be.visible');
    });
  });

  describe('Network Failures', () => {

    beforeEach(() => {
      tools.navigateToWaiting();
    });

    describe('Failure getting format', () => {
      beforeEach(() => {
        po.navToFormat('GLU');
        tools.iFrameContains('GLU');
        po.formInputsShouldBeVisible();

        cy.route({
          url: '/PatRptFormat/**INV~1',
          status: 500,
          response: ''
        }).as('getFormatError');

        po.navToFormat('24COR', 'INV', '1', 'boat', false);
        cy.wait('@getFormatError');
      });

      it('should show an error toast', () => {
        tools.errorToast.should('be.visible');
        cy.wait('@logError');
      });

      it('should not show previous format after an error', () => {
        po.formInputsShouldNotBeVisible();
        tools.iFrameDoesntContain('GLU');
        cy.wait('@logError');
      });
    });

    describe('Failure loading template', () => {
      beforeEach(() => {
        cy.route({
          url: '/PatRptTemplate/E2E*',
          status: 500,
          response: ''
        }).as('getTemplateError');

        po.navToFormat('24COR');

        po.selectStyle('serialrow');
        po.templateCode.select('E2ESERIALR').wait(500);

        po.loadInEditor.click();
        cy.wait('@getTemplateError');
        cy.wait('@logError');
      });

      it('should show an error toast', () => {
        tools.errorToast.should('be.visible');
      });

      it('should not change the contents of the editor', () => {
        tools.iFrameContains('24 HR URINE CORTISOL CONTENT');
      });
    });

    describe('Failure saving template', () => {
      beforeEach(() => {
        cy.route('PUT', '/PatRptFormat/24COR~INV~1').as('saveFormat');
        cy.route({
          method: 'PUT',
          url: '/PatRptFormat/24COR~INV~1',
          status: 500,
          response: ''
        }).as('saveFormatError');

        po.navToFormat('24COR')
      });

      it('should show an error toast', () => {
        po.saveButton.click();

        cy.wait('@saveFormatError');

        tools.errorToast.should('be.visible');

        cy.wait('@logError');
      });
    });
  });
});
