import {Component} from '@angular/core';
import {NavbarDataService} from '../shared/components/navigation/navbar/navbar-data-service';

@Component({
  selector: 'waiting',
  template: `
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="panel panel-flat">
            <div class="panel-body text-center">
              <h2>Waiting for event...</h2>
            </div>
          </div>
        </div>
      </div>
    </div>`
})
export class WaitingComponent {

  constructor(private navbarService: NavbarDataService) {
    navbarService.setPage('Ultra Web');

    // For e2e testing
    (<any>window).navigatedTo = [];
  }

}
