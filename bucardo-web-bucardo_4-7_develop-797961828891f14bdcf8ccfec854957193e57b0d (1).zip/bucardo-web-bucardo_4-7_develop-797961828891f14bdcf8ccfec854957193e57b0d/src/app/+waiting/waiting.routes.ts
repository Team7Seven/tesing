import {Route} from '@angular/router';
import {WaitingComponent} from './waiting.component';

export const WaitingRoute: Route = {
  path: '',
  component: WaitingComponent
};
