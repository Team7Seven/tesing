import {Injectable} from '@angular/core';
import {LabNoteModel} from './models/lab-note.model';
import {Observable} from 'rxjs/Observable';
import {ConfigurationService} from '../../shared/services/configuration/configuration.service';
import {ApiClient} from '../../shared/services/api-client/api-client';

@Injectable()
export class LabNotesService {

  labApi: string;

  constructor(private apiClient: ApiClient, private config: ConfigurationService) {
    this.labApi = config.getConfig().labapi_url;
  }

  createNote(model: LabNoteModel, patientId: string): Observable<LabNoteModel> {
    const fhirModel = {
      resourceType: 'LabNote',
      patient: patientId,
      request: model.requestId,
      note: model.noteText
    };

    return this.apiClient.post(`${this.labApi}/LabNote`, fhirModel).map((json: any) => {
      return this.extractNoteEntry(json);
    });
  }

  getNotesForPatient(patientId: string): Observable<Array<LabNoteModel>> {
    return this.apiClient.get(`${this.labApi}/LabNote?patient=${patientId}`).map((json: any) => {
      return json.entry.map((note) => {
        return this.extractNoteEntry(note.resource);
      });
    });
  }

  getRequestsForPatient(patientId: string): Observable<Array<any>> {
    return this.apiClient.get(`${this.labApi}/Request?patient=${patientId}&_summary=id`).map((json: any) => {
      return json.entry.map((request) => {
        return request.resource;
      });
    });
  }

  getPermissions(): Observable<Array<LabNoteModel>> {
    return this.apiClient.get(`${this.labApi}/LabNote/$perms`);
  }


  private extractNoteEntry(note) {
    const requestId = (note.request) ? `${note.req_prefix}-${note.req_num}` : null;

    return {
      id: note.ri,
      requestId: requestId,
      timestamp: note.mt,
      userId: note.op,
      username: note.op_name,
      noteText: note.note,
    };
  }
}
