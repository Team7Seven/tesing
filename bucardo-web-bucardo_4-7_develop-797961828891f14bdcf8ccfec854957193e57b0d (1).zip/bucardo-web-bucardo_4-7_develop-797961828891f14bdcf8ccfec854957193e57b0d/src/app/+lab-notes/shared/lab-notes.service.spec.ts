/* tslint:disable:no-unused-variable */
import {LabNotesService} from './lab-notes.service';
import {Observable} from 'rxjs/Observable';
import {fakeAsync, tick} from '@angular/core/testing';
import {ConfigurationService} from '../../shared/services/configuration/configuration.service';
import {ApiClient} from '../../shared/services/api-client/api-client';

describe('Service: ClinicalNote', () => {
  const LAB_API_URL = 'http://seahorse:9292';
  const validNote = {noteText: 'Note 1'};
  const note1 = {
    request: '1235',
    req_prefix: '17',
    req_num: '1231314',
    ri: '1235',
    timestamp: '2017-01-08',
    op: 'Bob Bobertson',
    op_name: 'bbob',
    note: 'Note 1'
  };

  const note2 = {
    request: '1234',
    req_prefix: '17',
    req_num: '1231313',
    ri: '1234',
    timestamp: '2017-01-09',
    op: 'Bob Bobertson',
    op_name: 'bbob',
    note: 'Note 2'
  };

  const successfulTwoNotes = {
    entry: [
      {
        resource: note1
      },
      {
        resource: note2
      }
    ]
  };

  const patient = {
    'ri': '137493',
    'surname': 'Bobertson',
    'given_name': 'Bob',
    'nprefix': ' ',
    'nsuffix': ' ',
    'sex': 'Male',
    'dob': '1969-11-18T00:00:00Z',
    'age_units': 'years',
    'species': ' ',
    'breed': ' ',
    'lang': '0',
    'address': '10 Main Street, Bobtown'
  };

  const requests = {
    entry: [
      {
        resource: {ri: '12345', prefix: '17', num: '54321'}
      },
      {
        resource: {ri: '12346', prefix: '17', num: '54322'}
      }
    ]
  };

  const successfulCreationResponse = note1;
  const successfulRequestsResponse = requests;
  const successfulZeroNotesResponse = {entry: []};

  let service: LabNotesService;
  let apiClientMock: MockApiClient;
  let configMock: MockConfigService;

  class MockApiClient {
    post: Function;
    get: Function;
  }

  class MockConfigService {
    getConfig: Function;
  }

  beforeEach(() => {
    apiClientMock = new MockApiClient();
    configMock = new MockConfigService();
    configMock.getConfig = jasmine.createSpy('configMock').and.returnValue({labapi_url: LAB_API_URL});
    service = new LabNotesService(<ApiClient><any>apiClientMock, <ConfigurationService><any>configMock);
  });

  describe('Create Note', () => {

    beforeEach(() => {
      apiClientMock.post = jasmine.createSpy('createNote').and.callFake((note) => Observable.of(successfulCreationResponse));
    });

    it('should call the API with the passed in note model', () => {
      service.createNote(validNote, 'patientID');
      expect(apiClientMock.post).toHaveBeenCalledWith(`${LAB_API_URL}/LabNote`, {
        resourceType: 'LabNote',
        patient: 'patientID',
        request: undefined,
        note: validNote.noteText
      });
    });

    it('should receive a response and translate into a ClinicalNote observable', fakeAsync(() => {
      service.createNote(validNote, 'patientID').subscribe((note) => {
        expect(note.noteText).toEqual(validNote.noteText);
      });

      tick();
    }));

    it('should throw error when getting unparseable json', fakeAsync(() => {
      shouldPassOnExceptionWhenThrownFromApiClient(() => service.createNote(validNote, 'patientID'));
    }));
  });


  describe('Get Notes For Patient', () => {

    beforeEach(() => {
      apiClientMock.get = jasmine.createSpy('getNotesForPatient').and.returnValue(Observable.of(successfulTwoNotes));
    });

    it('should call the API with a patient ID', () => {
      service.getNotesForPatient('patientID');
      expect(apiClientMock.get).toHaveBeenCalledWith(`${LAB_API_URL}/LabNote?patient=patientID`);
    });

    it('should receive a response as an observable with an array of clinical notes', fakeAsync(() => {
      service.getNotesForPatient('patientID').subscribe((clinicalNotes) => {
        expect(clinicalNotes.length).toEqual(2);
        expect(clinicalNotes[1].noteText).toEqual('Note 2');
      });

      tick();
    }));

    it('should handle zero notes', fakeAsync(() => {
      apiClientMock.get = jasmine.createSpy('getZeroNotesForPatient').and.returnValue(Observable.of(successfulZeroNotesResponse));

      service.getNotesForPatient('patientID').subscribe((clinicalNotes) => {
        expect(clinicalNotes.length).toEqual(0);
      });
    }));

    it('should throw error when getting unparseable json', fakeAsync(() => {
      shouldPassOnExceptionWhenThrownFromApiClient(() => service.getNotesForPatient('patientID'));
    }));
  });

  describe('Get Requests For Patient', () => {

    beforeEach(() => {
      apiClientMock.get = jasmine.createSpy('getRequestsForPatient').and.returnValue(Observable.of(successfulRequestsResponse));
    });

    it('should call the API with a patient ID', () => {
      service.getRequestsForPatient('patientID');
      expect(apiClientMock.get).toHaveBeenCalledWith(`${LAB_API_URL}/Request?patient=patientID&_summary=id`);
    });

    it('should receive a response as an observable with an array of requests', fakeAsync(() => {
      service.getRequestsForPatient('patientID').subscribe((returnedRequests) => {
        expect(returnedRequests.length).toEqual(2);
        expect(returnedRequests[1]).toEqual({ri: '12346', num: '54322', prefix: '17'});
      });

      tick();
    }));

    it('should handle zero requests', fakeAsync(() => {
      apiClientMock.get = jasmine.createSpy('getZeroNotesForPatient').and.returnValue(Observable.of(successfulZeroNotesResponse));

      service.getNotesForPatient('patientID').subscribe((returnedRequests) => {
        expect(returnedRequests.length).toEqual(0);
      });
    }));

    it('should throw error when getting unparseable json', fakeAsync(() => {
      shouldPassOnExceptionWhenThrownFromApiClient(() => service.getNotesForPatient('patientID'));
    }));
  });

  function shouldPassOnExceptionWhenThrownFromApiClient(whatToCall: Function) {
    apiClientMock.get = jasmine.createSpy('errorMock').and.returnValue(Observable.throw('Panic!'));
    apiClientMock.post = jasmine.createSpy('errorMock').and.returnValue(Observable.throw('Panic!'));

    whatToCall().subscribe(
      (response) => {
        fail('Should have got an error, but got:' + JSON.stringify(response));
      },
      (error) => {
        expect(error).toEqual('Panic!');
      });

    tick();
  }


});
