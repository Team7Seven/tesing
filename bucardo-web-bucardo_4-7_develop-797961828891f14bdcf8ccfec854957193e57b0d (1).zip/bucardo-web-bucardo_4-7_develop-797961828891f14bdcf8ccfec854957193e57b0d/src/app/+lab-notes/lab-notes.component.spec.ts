/* tslint:disable:no-unused-variable */
import {fakeAsync} from '@angular/core/testing';
import {LabNotesComponent} from './lab-notes.component';
import {Observable} from 'rxjs/Observable';
import {LabNoteModel} from './shared/models/lab-note.model';
import {Subject} from 'rxjs/Subject';
import createSpy = jasmine.createSpy;

describe('LabNotesComponent', () => {
  const PATIENT_ID = '1234';
  const REQUEST_ID = 'REQ_ID';

  let component: LabNotesComponent;
  let serviceMock: LabNotesServiceMock;
  let payloadServiceMock: PayloadServiceMock;
  let navbarServiceMock: NavbarDataServiceMock;
  let toastServiceMock: ToastrServiceMock;
  let patientRequestDoctorHelperMock: PatientRequestDoctorHelperMock;
  let subscriptionMock: SubscriptionMock;

  const ERROR_MSG = 'An Error';
  const validNote: LabNoteModel = {noteText: 'This is a note'};

  /** Mock Services **/
  class LabNotesServiceMock {
    createNote: Function;
    getNotesForPatient = createSpy('getNotesForPatient').and.returnValue(Observable.of([]));
    getRequestsForPatient = createSpy('getRequestsForPatient').and.returnValue(Observable.of([]));
    getPermissions = createSpy('getPermissions').and.returnValue(Observable.of({find: true, add: true}));
  }

  class PayloadServiceMock {
    payloadData: Observable<any> = Observable.of({event: 'labNote', payload: {patient: PATIENT_ID}});
  }

  class NavbarDataServiceMock {
    setPage = createSpy('setPage');
  }

  class ToastrServiceMock {
    warning = createSpy('toastWarning');
    success = createSpy('toastSuccess');
  }

  class PatientRequestDoctorHelperMock {
    networkError = new Subject();
    resetObservables = createSpy('resetObservables');
    fetchPatientRequestDoctorFromRequestId = createSpy('fetchPatientRequestDoctorFromRequestId');
    fetchPatientDetails = createSpy('fetchPatientDetails');
  }

  class SubscriptionMock {
    unsubscribe = createSpy('unsub');
  }

  beforeEach(() => {
    serviceMock = new LabNotesServiceMock();
    payloadServiceMock = new PayloadServiceMock();
    navbarServiceMock = new NavbarDataServiceMock();
    toastServiceMock = new ToastrServiceMock();
    patientRequestDoctorHelperMock = new PatientRequestDoctorHelperMock();
    subscriptionMock = new SubscriptionMock();

    component = new LabNotesComponent(
      <any> serviceMock,
      <any> payloadServiceMock,
      <any> patientRequestDoctorHelperMock,
      <any> navbarServiceMock,
      <any> toastServiceMock,
      <any> {
        tick: createSpy('apptick')
      });

    spyOn(payloadServiceMock.payloadData, 'subscribe').and.callThrough();
    jasmine.createSpy('getNotesForPatient').and.returnValue(Observable.of([]));

  });


  it('should create successfully', () => {
    expect(component).toBeTruthy();
  });

  it('should subscribe to payload data on initialisation', fakeAsync(() => {
    component.ngOnInit();
    expect(payloadServiceMock.payloadData.subscribe).toHaveBeenCalled();
  }));

  describe('Creating Notes', () => {

    describe('Creating Notes Successfully', () => {

      beforeEach(() => {
        serviceMock.createNote = jasmine.createSpy('createNote').and.callFake((note) => Observable.of(note));

        component.permissions = {add: true, find: true};
        component.patientId = PATIENT_ID;

      });

      it('should call the service when creating a note', () => {
        component.onNoteAdded(validNote);
        expect(serviceMock.createNote).toHaveBeenCalledWith(validNote, PATIENT_ID);
      });

      it('should refresh the list of notes from the server', () => {
        component.onNoteAdded(validNote);
        expect(serviceMock.getNotesForPatient).toHaveBeenCalledWith(PATIENT_ID);
      });

    });

    describe('error on service call', () => {

      beforeEach(() => {
        serviceMock.createNote = jasmine.createSpy('createNote').and.returnValue(Observable.throw(ERROR_MSG));
        spyOn(console, 'error'); // avoids error text in the test report
        component.permissions = {add: true, find: true};
        component.patientId = PATIENT_ID;
        // recreateComponent();
      });

      it('should throw an exception', () => {
        try {
          component.onNoteAdded(validNote);
          fail('Exception expected');
        } catch (e) {
          expect(e).toEqual(ERROR_MSG);
        }

      });

    });

  });

  describe('Getting patient/doctor/request details', () => {

    it('should call the API to get patient details on init with null if no request supplied', () => {
      payloadServiceMock.payloadData = Observable.of({event: 'labNote', payload: {patient: PATIENT_ID}});
      component.ngOnInit();
      expect(patientRequestDoctorHelperMock.fetchPatientDetails).toHaveBeenCalledWith(PATIENT_ID);
    });

    it('should call the API to get patient / doctor / request details on init with supplied REQUEST_ID', () => {
      payloadServiceMock.payloadData = Observable.of({
        event: 'labNote',
        payload: {patient: PATIENT_ID, request: REQUEST_ID}
      });
      component.ngOnInit();
      expect(patientRequestDoctorHelperMock.fetchPatientRequestDoctorFromRequestId).toHaveBeenCalledWith(REQUEST_ID);
    });

    describe('when there is an error on service call', () => {

      it('should pass on exception', () => {
        serviceMock.getNotesForPatient = jasmine.createSpy('getNotesForPatient').and.returnValue(Observable.throw(ERROR_MSG));

        try {
          component.ngOnInit();
          fail('should not get here');
        } catch (e) {
          expect(e).toEqual(ERROR_MSG);
        }
      });

    });

  });

  describe('Getting patient notes', () => {

    it('should call the API to get patient notes on init', () => {
      component.ngOnInit();
      expect(serviceMock.getNotesForPatient).toHaveBeenCalledWith(PATIENT_ID);
    });

    describe('when there is an error on service call', () => {

      it('should pass on exception', () => {
        serviceMock.getNotesForPatient = jasmine.createSpy('getNotesForPatient').and.returnValue(Observable.throw(ERROR_MSG));

        try {
          component.ngOnInit();
          fail('should not get here');
        } catch (e) {
          expect(e).toEqual(ERROR_MSG);
        }
      });

    });

  });


  describe('Getting requests for patient', () => {

    beforeEach(() => {
      component.ngOnInit();
    });

    it('should call the API to get patient notes on init', () => {
      expect(serviceMock.getRequestsForPatient).toHaveBeenCalledWith(PATIENT_ID);
    });

  });
  describe('On shutdown', () => {

    beforeEach(() => {
      component.ngOnInit();
    });

    it('should unsubscribe from params subscription', () => {
      spyOn(component.payloadDataSubscription, 'unsubscribe');
      component.ngOnDestroy();
      expect(component.payloadDataSubscription.unsubscribe).toHaveBeenCalled();
    });

  });

  describe('with no permissions', () => {
    beforeEach(() => {
      serviceMock.getPermissions = jasmine.createSpy('getPermissions').and.returnValue(Observable.of({}));
      serviceMock.getNotesForPatient = jasmine.createSpy('getNotesForPatient');
      component.ngOnInit();
    });

    it('does not make calls to any other services on initialization', () => {
      expect(serviceMock.getPermissions).toHaveBeenCalled();
      expect(serviceMock.getRequestsForPatient).not.toHaveBeenCalled();
      expect(serviceMock.getNotesForPatient).not.toHaveBeenCalled();
      expect(toastServiceMock.warning).toHaveBeenCalledWith('You do not have permission to view this page');
    });
  });

  describe('with only \'find\' permissions', () => {
    beforeEach(() => {
      serviceMock.getPermissions = jasmine.createSpy('getPermissions').and.returnValue(Observable.of({find: true}));
      serviceMock.getNotesForPatient = jasmine.createSpy('getNotesForPatient').and.returnValue(Observable.of([]));
      serviceMock.createNote = jasmine.createSpy('createNote').and.callFake((note) => Observable.of(note));
      component.ngOnInit();
    });

    it('does not make a create note call to have been made', () => {
      const validNote1: LabNoteModel = {noteText: 'This is the first note'};
      component.onNoteAdded(validNote1);
      expect(serviceMock.createNote).not.toHaveBeenCalled();
      expect(component.notes[0]).not.toBe(validNote1);
    });

    it('makes calls to other services as normal on initialization', () => {
      expect(serviceMock.getPermissions).toHaveBeenCalled();
      expect(serviceMock.getRequestsForPatient).toHaveBeenCalled();
      expect(serviceMock.getNotesForPatient).toHaveBeenCalled();
      expect(patientRequestDoctorHelperMock.fetchPatientDetails).toHaveBeenCalled();
      expect(toastServiceMock.warning).not.toHaveBeenCalled();
    });
  });

  describe('with only \'add\' permissions', () => {
    beforeEach(() => {
      serviceMock.getPermissions = jasmine.createSpy('getPermissions').and.returnValue(Observable.of({}));
      serviceMock.getNotesForPatient = jasmine.createSpy('getNotesForPatient');
      component.ngOnInit();
    });

    it('does not make calls to any other services on initialization', () => {
      expect(serviceMock.getPermissions).toHaveBeenCalled();
      expect(serviceMock.getRequestsForPatient).not.toHaveBeenCalled();
      expect(serviceMock.getNotesForPatient).not.toHaveBeenCalled();
      expect(patientRequestDoctorHelperMock.fetchPatientRequestDoctorFromRequestId).not.toHaveBeenCalled();
      expect(toastServiceMock.warning).toHaveBeenCalledWith('You do not have permission to view this page');
    });
  });

});
