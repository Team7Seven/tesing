import {
  ChangeDetectorRef,
  Component, ElementRef, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges,
  ViewChild
} from '@angular/core';
import {LabNoteModel} from '../shared/models/lab-note.model';
import {RequestModel} from '../../shared/models/request.model';
import {SearchBoxComponent} from '../../shared/components/search-box/search-box.component';
import {SearchBoxItemModel} from '../../shared/components/search-box/search-box-item.model';
import {Observable} from 'rxjs/Observable';
import {FormControl} from '@angular/forms';
import {SelectBoxComponent} from '../../shared/components/select-box/select-box.component';

@Component({
  selector: 'note-form',
  template: `
    <div class="panel panel-default">
      <div class="panel-heading fill">
        <label for="note-entry" class="label-small-margin">Add Lab Note</label>
        <textarea id="note-entry" (keydown)="handleNoteEntryKeyDown($event)"
                  placeholder="Type note here... (ctrl+enter to submit)" title="Lab Note Text"
                  class="form-control" [(ngModel)]="noteText" autofocus #noteInput>
            </textarea>
        <span id="requests">
          <div class="input-group">
            <input type="text" class="form-control" id="search-box-input" [(ngModel)]="requestFilter"
                   [SelectBox]="selectBox"
                   [formControl]="requestFilterInput" (focusin)="clearFilter()">
            <span *ngIf="selectedRequest" id="cancel-button" (click)="clearSelectedRequest()"
                  class="input-group-addon"><i class="fa fa-2x fa-window-close"></i>
                    </span>
            </div>
        <select-box #selectBox="SelectBox"
                    [(ngModel)]="selectedRequest"
                    [triggerDisplayMap]="triggerMap"
                    [modelValueMap]="selectBoxValueMapper"
                    [multiple]="false"
                    (selectionChanged)="requestSelected($event)">
          <select-box-option *ngFor="let option of filteredRequests" [value]="option">
            {{option.prefix}}-{{option.num}}
          </select-box-option>
        </select-box>
            </span>
        <span class="add-button">
              <button id="submit-note" title="Ctrl+Enter to Submit" (click)="submitNote()"
                      [disabled]="!noteText.trim()" class="btn btn-primary notes-buttons">Add</button>
            </span>

        <div class="clearfix"></div>
      </div>
    </div>`,
  styleUrls: ['./note-form.component.scss']
})
export class NoteFormComponent implements OnChanges, OnInit {
  @Input() requests: Array<any>;
  @Input() selectedRequest: RequestModel;
  @Output() noteAdded = new EventEmitter<LabNoteModel>();
  @Output() requestIdChanged = new EventEmitter<string>();

  requestFilter = '';
  noteText = '';
  requestFilterInput = new FormControl();
  filteredRequests = [];


  @ViewChild('noteInput') noteInput: ElementRef;
  @ViewChild(SelectBoxComponent) selectBox: SelectBoxComponent;

  constructor(private changeDetectionRef: ChangeDetectorRef) {
  }

  ngOnInit() {
    this.filteredRequests = this.requests.slice(0, 10);
    this.requestFilterInput.valueChanges.debounceTime(200).startWith('').subscribe((val) => {
      this.filterRequests(val);
      this.changeDetectionRef.detectChanges();
    });
    if (this.selectedRequest) {
      this.requestFilter = this.selectedRequest.prefix + '-' + this.selectedRequest.num;
    }
  }

  filterRequests(filter) {
    this.filteredRequests = this.requests.filter((req) => {
      const name = req.prefix + '-' + req.num;
      return (name.toLowerCase().indexOf(filter.toLowerCase()) > -1) || filter === '';
    }).slice(0, 10);
  }


  ngOnChanges(changes: SimpleChanges): void {
    if ('selectedRequest' in changes && this.selectedRequest) {
      this.requestFilter = this.selectedRequest.prefix + '-' + this.selectedRequest.num;
    }
  }

  autoSelectRequest() {
  }

  handleNoteEntryKeyDown($event) {
    if ($event.keyCode === 13 && $event.ctrlKey) {
      this.submitNote();
    }
  }

  submitNote() {
    if (this.noteText.trim()) {
      let requestInfo = {};
      if (this.selectedRequest) {
        requestInfo = {requestId: this.selectedRequest.ri};
      }
      const modelToSubmit = Object.assign({}, {noteText: this.noteText}, requestInfo);
      this.noteAdded.emit(modelToSubmit);
      this.noteText = '';
      this.noteInput.nativeElement.focus();
      this.clearSelectedRequest();
    }
  }

  requestSelected($event) {
    if ($event && $event[0]) {
      this.selectedRequest = $event[0];
      this.requestIdChanged.emit($event[0]);
    } else {
      this.selectedRequest = null;
      this.requestIdChanged.emit(null);
    }
  }

  selectBoxValueMapper(option) {
    return option.ri;
  }

  triggerMap(option) {
    return option.prefix + '-' + option.num;
  }

  clearFilter() {
    this.requestFilter = '';
  }

  clearSelectedRequest() {
    this.selectedRequest = null;
    this.requestIdChanged.emit(null);
    this.clearFilter();
  }
}
