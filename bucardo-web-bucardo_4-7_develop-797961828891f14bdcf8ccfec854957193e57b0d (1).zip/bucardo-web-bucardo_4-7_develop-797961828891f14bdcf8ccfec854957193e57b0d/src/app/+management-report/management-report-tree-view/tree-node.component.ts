import {Component, Input, ViewEncapsulation, Output, EventEmitter, OnChanges, SimpleChanges} from '@angular/core';
import {TreeNode} from './tree-view.model';

@Component({
  selector: 'management-tree-node',
  templateUrl: 'tree-node.component.html',
  styleUrls: ['tree-view.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class TreeNodeComponent {
  @Input() nodes: Array<TreeNode>;
  @Input() selectedId: string;
  @Input() paramsAreLoading: boolean;
  @Output() onNodeToggled = new EventEmitter<TreeNode>();
  @Output() reportSelected = new EventEmitter<any>();

  selected(dir, $event) {
    if (!this.paramsAreLoading) {
      if (dir.nodes) {
        this.onNodeToggled.emit(dir);
        return;
      }
      if (!dir.event) {
        const emit = {selected: dir, event: $event};
        this.reportSelected.emit(emit);
        return;
      }
      this.reportSelected.emit(dir);
    }
  }
}


