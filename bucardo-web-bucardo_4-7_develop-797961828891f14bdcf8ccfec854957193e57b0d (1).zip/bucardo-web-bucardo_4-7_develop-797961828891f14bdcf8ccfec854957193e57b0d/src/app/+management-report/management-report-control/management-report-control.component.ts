import {ChangeDetectorRef, Component, Input, OnInit, ViewChild, ViewEncapsulation} from '@angular/core';
import {FormControl, FormGroup} from '@angular/forms';
import {ManagementReportParameterModel} from '../shared/management-report-parameter.model';
import {ManagementReportControlModel} from '../shared/management-report-control.model';
import {SearchBoxItemModel} from '../../shared/components/search-box/search-box-item.model';
import {SelectBoxComponent} from '../../shared/components/select-box/select-box.component';

@Component({
  selector: 'management-report-control',
  templateUrl: 'management-report-control.component.html',
  styleUrls: ['management-report-control.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ManagementReportControlComponent implements OnInit {

  @Input() model: ManagementReportParameterModel;
  @Input() form: FormGroup;
  @Input() controlModel: ManagementReportControlModel;
  @ViewChild(SelectBoxComponent) selectBox;

  selectBoxFilter: FormControl = new FormControl();
  options: SearchBoxItemModel[];
  selectedOptions: SearchBoxItemModel[] = [];

  constructor(private changeDetectionRef: ChangeDetectorRef) {
  }

  ngOnInit() {
    if (this.controlModel.element === 'search-box') {
      this.options = this.controlModel.selectionList;
      this.selectBoxFilter.valueChanges
        .debounceTime(200)
        .subscribe((value) => {
          this.options = this.controlModel.selectionList.filter((option) => {
            return !!(option.text.toLowerCase().indexOf(value) + 1) || !value;
          });
          this.changeDetectionRef.detectChanges();
        });
    }

  }

  get isValid() {
    return this.form.controls[this.model.name].valid;
  }

  setSelection(event) {
    let value: any;
    if (!event || event.length === 0) {
      value = null;
    } else if (this.controlModel.multiple) {
      value = event.map(item => {
        return item.id;
      });
    } else {
      value = event[0].id;
    }

    this.form.controls[this.model.name].setValue(value);
    this.form.controls[this.model.name].markAsDirty();
    this.form.controls[this.model.name].markAsTouched();
  }

  resetSearchBox() {
    this.form.controls[this.model.name].setValue(null);
  }

  triggerMap(option) {
    if (this.controlModel.multiple) {
      return '';
    } else {
      return option.text;
    }
  }

  selectDisplayValueMap(option) {
    return option.text;
  }

  selectBoxValueMapper(option) {
    return option.id;
  }

  deselectOption(value) {
    this.selectBox.deselectOption(value);
  }

  removeSelectBoxItem(value) {
    this.selectBox.deselectOption(value);
  }

  updateSelected(selectedValues) {
    this.selectedOptions = [];
    selectedValues.forEach((option) => {
      this.selectedOptions.push(this.selectDisplayValueMap(option));
    });
  }
}
