import {FormControl, FormGroup} from '@angular/forms';
import {ManagementReportControlComponent} from './management-report-control.component';
import {ManagementReportParameterModel} from '../shared/management-report-parameter.model';
import {ManagementReportControlModel} from '../shared/management-report-control.model';

describe('ManagementReportControlComponent', () => {

  const component: ManagementReportControlComponent = new ManagementReportControlComponent();
  const model: ManagementReportParameterModel = new ManagementReportParameterModel();
  let form: FormGroup;
  const controlModel: ManagementReportControlModel = new ManagementReportControlModel();

  describe('setting selections', () => {

    beforeEach(() => {
      model.name = controlModel.name = 'test';
      const fc = new FormControl(null);
      form = new FormGroup({'test': fc});

      component.model = model;
      component.form = form;
      component.controlModel = controlModel;
    });

    const MULTIPLE_SELECTION = [{id: 1, name: 'test1'}, {id: 2, name: 'test2'}];

    it('sets the control value to null when no items are selected', () => {
      component.setSelection([]);
      expect(form.controls['test'].value).toEqual(null);
    });

    it('sets the control value to a string when two items are selected', () => {
      component.setSelection(MULTIPLE_SELECTION);
      expect(form.controls['test'].value).toEqual(1);
    });

    it('sets the control value to an array of items when two items are selected and the multiple is true',
      () => {
      component.controlModel.multiple = true;
      component.setSelection(MULTIPLE_SELECTION);
      expect(form.controls['test'].value).toEqual([1, 2]);
    });

  });
});
