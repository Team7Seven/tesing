export class ManagementReportParameterModel {

  type: string;
  dataType: string;
  defaultValue: any;
  promptText: string;
  hidden: string;
  concealEntry: string;
  parameterGroup: string;
  parameterType: string;
  name: string;
  selectionList: any;
  required: string;
  displayFormat?: string;
  value: any;
  helpText: string;

  constructor () { }
}
