import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {ApiClient} from '../../shared/services/api-client/api-client';
import {ConfigurationService} from '../../shared/services/configuration/configuration.service';
import 'rxjs/add/operator/map';
import {ManagementReportParameterModel} from './management-report-parameter.model';
import {CustomValidators} from '../../shared/validators/custom.validators';
import {Validators} from '@angular/forms';
import {ManagementReportControlModel} from './management-report-control.model';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {UserService} from '../../shared/services/user/user.service';

@Injectable()
export class ManagementReportService {
  labAPIUrl: string;
  private currentUser;

  constructor(private apiClient: ApiClient, private config: ConfigurationService,
              private userService: UserService) {
    this.labAPIUrl = config.getConfig().labapi_url;
    userService.user.subscribe((user) => {
      if (user) {
        this.currentUser = user.code;
      }
    });
  }

  getAllReports(): Observable<Array<any>> {
    return this.apiClient.get(`${this.labAPIUrl}/MngRptTemplate?_summary=short`).map((json: any) => {
      return json.entry;
    });
  }

  getParameters(reportId: string): Observable<any> {
    return this.apiClient
      .post(`${this.labAPIUrl}/MngRptTemplate/$rptParams`, {template: reportId});
  }

  generateReport(reportId: string, format: string, parameters: any) {
    return this.apiClient
      .postAndExpectText(`${this.labAPIUrl}/MngRptTemplate/$rptRender`,
        {
          template: reportId,
          format: format,
          params: parameters
        });
  }

  generateReportFile(reportId: string, format: string, parameters: any, contentType: string) {
    return this.apiClient
      .postAndExpectFile(`${this.labAPIUrl}/MngRptTemplate/$rptRender`,
        {
          template: reportId,
          format: format,
          params: parameters
        }, contentType);
  }

  getPermissions() {
    return this.apiClient.get(`${this.labAPIUrl}/MngRptTemplate/$perms`);
  }

  uploadReportTemplate(reportDesignModel: any): Observable<any> {
    return this.apiClient.post(`${this.labAPIUrl}/MngRptTemplate`, reportDesignModel);
  }

  updateReportTemplate(reportDesignModel: any): Observable<any> {
    return this.apiClient.put(`${this.labAPIUrl}/MngRptTemplate/${reportDesignModel.code}`, reportDesignModel, this.currentUser);
  }

  getFullReportTemplateData(reportId: string): Observable<any> {
    return this.apiClient.get(`${this.labAPIUrl}/MngRptTemplate/${reportId}`);
  }

  deleteReportTemplate(reportId: string): Observable<any> {
    return this.apiClient.delete(`${this.labAPIUrl}/MngRptTemplate/${reportId}`);
  }

  getRenderUrl() {
    return `${this.labAPIUrl}/MngRptTemplate/$rptRender`;
  }

  getDateFormat(model: ManagementReportParameterModel): string {
    if (model.displayFormat) {
      switch (model.displayFormat) {
        case 'Medium Date':
          return 'D MMM YYYY';
        case 'Long Date':
          return 'D MMMM[,] YYYY';
        case 'Short Date':
          return 'DD/MM/YYYY';
        case 'General Date':
          return 'D MMMM YYYY [at] HH:mm:ss z';
      }
    }

    if (model.dataType === 'TYPE_DATE') {
      return 'Do MMMM, YYYY';
    }

    if (model.dataType === 'TYPE_TIME') {
      return 'HH:mm';
    }

    // Just return a full date format string
    return 'Do MMMM, YYYY HH:mm';
  }


  private getInputType(paramModel: ManagementReportParameterModel): string {
    if (paramModel.concealEntry === 'Yes') {
      return 'password';
    }
    if (paramModel.dataType === 'TYPE_FLOAT' || paramModel.dataType === 'TYPE_DECIMAL' || paramModel.dataType === 'TYPE_INTEGER') {
      return 'text';
    }
    return 'text';
  }

  private setTextBoxProperties(paramModel: ManagementReportParameterModel, controlModel) {
    switch (paramModel.dataType) {
      case 'TYPE_DATE':
        controlModel.showDatePicker = true;
        controlModel.element = 'datepicker';
        controlModel.format = this.getDateFormat(paramModel);
        controlModel.date = true;
        break;
      case 'TYPE_DATE_TIME':
        controlModel.showDatePicker = true;
        controlModel.showTimePicker = true;
        controlModel.element = 'datepicker';
        controlModel.format = this.getDateFormat(paramModel);
        controlModel.date = true;
        break;
      case 'TYPE_TIME':
        controlModel.showTimePicker = true;
        controlModel.element = 'datepicker';
        controlModel.format = this.getDateFormat(paramModel);
        controlModel.date = true;
        break;
      default:
        controlModel.element = 'input';
        controlModel.textInputType = this.getInputType(paramModel);
        break;
    }
  }

  convertParamToControlProperties(paramModel: ManagementReportParameterModel): ManagementReportControlModel {
    const controlModel = new ManagementReportControlModel();
    controlModel.multiple = (paramModel.parameterType === 'multi-value');
    controlModel.hidden = (paramModel.hidden === 'Yes');
    controlModel.name = paramModel.name;
    controlModel.label = (paramModel.promptText) ? paramModel.promptText : paramModel.name;
    controlModel.required = (paramModel.required === 'Yes');
    controlModel.helpText = (paramModel.helpText) ? paramModel.helpText : controlModel.label;

    switch (paramModel.type) {
      case 'LIST_BOX':
        controlModel.element = 'search-box';
        controlModel.selectionList = this.getSearchBoxOptions(paramModel, false);
        break;
      case 'RADIO_BUTTON':
        controlModel.element = 'radio';
        controlModel.selectionList = this.getSearchBoxOptions(paramModel);
        break;
      case 'CHECK_BOX':
        controlModel.element = 'checkbox';
        break;
      case 'TEXT_BOX':
      default:
        this.setTextBoxProperties(paramModel, controlModel);
        break;
    }

    this.setDefaultAndInitialValue(paramModel, controlModel);

    return controlModel;
  }

  private getSearchBoxOptions(paramModel: ManagementReportParameterModel, returnObservable = false): any {
    const list = paramModel.selectionList.map((selection) => {
      if (paramModel.dataType === 'TYPE_BOOLEAN') {
        return {id: this.getBooleanValue(selection.value), text: selection.label};
      }
      return {id: selection.value, text: selection.label};
    });

    if (returnObservable) {
      return new BehaviorSubject(list);
    }
    return list;
  }

  getValidators(paramModel: ManagementReportParameterModel) {
    const validators = [];
    if (paramModel.required === 'Yes') {
      validators.push(Validators.required);
    }
    if (paramModel.type === 'TEXT_BOX') {
      if (paramModel.dataType === 'TYPE_INTEGER') {
        validators.push(CustomValidators.validateInteger);
        validators.push(CustomValidators.maxIntSizeValidator);
      }
      if (paramModel.dataType === 'TYPE_DECIMAL' || paramModel.dataType === 'TYPE_FLOAT') {
        validators.push(CustomValidators.validateNumber);
        validators.push(CustomValidators.maxIntSizeValidator);
      }
      if (paramModel.dataType === 'TYPE_DATE') {
        validators.push(CustomValidators.createDateFormatValidator);
      }
    }

    return validators;
  }


  private getBooleanValue(value: any): boolean {
    if (value === true || value === false) {
      return value;
    }

    return value === 'true' || value === 'Yes';
  }

  setDefaultAndInitialValue(paramModel: ManagementReportParameterModel, controlModel: ManagementReportControlModel) {
    controlModel.defaultValue = (controlModel.multiple) ? <any> [] : '';
    controlModel.value = (controlModel.multiple) ? <any> [] : '';
    if (paramModel.defaultValue === null || paramModel.defaultValue === undefined) {
      return;
    }

    if (controlModel.element === 'search-box') {
      this.setSearchBoxDefault(paramModel, controlModel);
      return;
    }

    if (controlModel.element === 'datepicker') {
      controlModel.defaultValue = controlModel.value = <any>this.getDateDefault(paramModel);
      return;
    }

    if (paramModel.dataType === 'TYPE_BOOLEAN') {
      controlModel.defaultValue = controlModel.value = <any> this.getBooleanValue(paramModel.defaultValue);
      return;
    }

    controlModel.defaultValue = controlModel.value = paramModel.defaultValue;
  }

  private setSearchBoxDefault(paramModel, controlModel) {
    const options = this.getSearchBoxOptions(paramModel, false);

    let defaultValues = paramModel.defaultValue;
    if (!(defaultValues instanceof Array)) {
      defaultValues = [{value: defaultValues}];
    }

    defaultValues.forEach((defaultValue) => {
      options.forEach((option) => {
        if (option.id.toString() === defaultValue.value.toString()) {
          if (controlModel.multiple) {
            controlModel.defaultValue.push(option);
            controlModel.value.push(option.id);
          } else {
            controlModel.defaultValue = option;
            controlModel.value = option.id;
          }
        }
      });
    });
  }

  private getDateDefault(paramModel: ManagementReportParameterModel) {
    let value = paramModel.defaultValue.toString();
    if (value) {
      if (value.indexOf('0001') !== -1) {
        value = 0;
      }
      return new Date(value);
    }

    return null;
  }
}
