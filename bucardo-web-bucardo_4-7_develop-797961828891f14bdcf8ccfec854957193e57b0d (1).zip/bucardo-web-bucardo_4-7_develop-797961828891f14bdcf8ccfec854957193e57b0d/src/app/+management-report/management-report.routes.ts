import {Route} from '@angular/router';
import {ManagementReportComponent} from './management-report.component';

export const ManagementReportRoute: Route = {
  path: '', component: ManagementReportComponent
};
