import {fakeAsync, tick} from '@angular/core/testing';
import {Observable} from 'rxjs/Observable';
import {ManagementReportComponent} from './management-report.component';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import createSpy = jasmine.createSpy;
import {TreeNode} from '../shared/components/tree-view/tree-view.model';

class PayloadDataServiceSpy {
  payloadData = new BehaviorSubject('');
  sendPayload = createSpy('sendPayload').and.callFake((data) => {
    this.payloadData.next(data);
  });
}

describe('ManagementReportComponent', () => {

  let component: ManagementReportComponent;
  let navbarServiceMock: NavbarDataServiceMock;
  let toastServiceMock: ToastrServiceMock;
  let payloadDataServiceSpy: PayloadDataServiceSpy;
  let managementReportService: ManagementReportServiceMock;
  let changeDetectorMock: ChangeDetectorMock;
  let loginUtilsMock: LoginUtilsMock;

  const VALID_HTML = '<h1>Test Report</h1>';
  const SOME_CSV = 'a,b,c';
  const REPORT_ID = 123;
  const RENDER_URL = 'http://localhost/render';
  const REPORT_NAME = 'REPORT_NAME';
  const USER_DATA = {
    'resource': {
      'resourceType': 'MngRptTemplate', 'code': 'mng_1', 'name': 'Management Report One', 'class': 'management',
      'category': 'Testing', 'meta': {
        'versionId': 'RC89_20170821102148', 'lastUpdated': '2017-08-21T10: 21: 48.0+01: 00',
        'eTag': 'W/\'RC89_20170821102148\'', 'opr': 'paula', 'oprName': 'paula'
      }
    }
  };
  const VALID_RPT_RESPONSE =
    [{
      'resource': {
        'resourceType': 'MngRptTemplate', 'code': 'mng_1', 'name': 'Management Report One', 'class': 'management',
        'category': 'Report Cat 1', 'meta': {
          'versionId': 'mng_1_00010101000000', 'lastUpdated': '0001-01-01T00:00:00Z',
          'eTag': 'W\/\'mng_1_00010101000000\'', 'opr': 'paulac', 'oprName': 'paulac'
        }
      }
    }, {
      'resource': {
        'resourceType': 'MngRptTemplate', 'code': 'mng_2', 'name': 'Management Report Two', 'class': 'management',
        'category': 'Report Cat 1', 'meta': {
          'versionId': 'mng_1_00010101000000', 'lastUpdated': '0001-01-01T00:00:00Z',
          'eTag': 'W\/\'mng_1_00010101000000\'', 'opr': 'paulac', 'oprName': 'paulac'
        }
      }
    },
      {
        'resource': {
          'resourceType': 'MngRptTemplate', 'code': 'mng_3', 'name': 'Management Report Three', 'class': 'management',
          'category': 'Report Cat 2', 'meta': {
            'versionId': 'mng_1_00010101000000', 'lastUpdated': '0001-01-01T00:00:00Z',
            'eTag': 'W\/\'mng_1_00010101000000\'', 'opr': 'paulac', 'oprName': 'paulac'
          }
        }
      }
    ];


  /** Mock Services **/
  class ManagementReportServiceMock {
    getParameters = createSpy('getParams').and.returnValue(Observable.of([]));
    getAllReports = jasmine.createSpy('getAllReports').and.returnValue(Observable.of(VALID_RPT_RESPONSE));
    getPermissions = jasmine.createSpy('getPermissions').and.returnValue(Observable.of({find: true}));
    generateReport = jasmine.createSpy('generateReport ').and.returnValue(Observable.of(VALID_HTML));
    getRenderUrl = createSpy('getRenderUrl').and.returnValue(RENDER_URL);
    generateReportFile = createSpy('generateReportFile').and.returnValue(Observable.of(SOME_CSV));
  }

  class NavbarDataServiceMock {
    setPage = jasmine.createSpy('setPage');
  }

  class ToastrServiceMock {
    warning = createSpy('toastWarning');
  }

  class ChangeDetectorMock {
    detectChanges = createSpy('detectChanges');
  }

  class LoginUtilsMock {
    isUserLoggedIn = createSpy('isUserLoggedIn').and.returnValue(true);
  }


  const fakeDocument = {
    write: createSpy('docwriter'),
    close: createSpy('docclose')
  };

  const fakeIframeElement = {
    nativeElement: {
      contentWindow: {
        document: {
          open: createSpy('docopen').and.returnValue(fakeDocument)
        }
      }
    }
  };


  beforeEach(() => {

    payloadDataServiceSpy = new PayloadDataServiceSpy();
    navbarServiceMock = new NavbarDataServiceMock();
    toastServiceMock = new ToastrServiceMock();
    managementReportService = new ManagementReportServiceMock();
    changeDetectorMock = new ChangeDetectorMock();
    navbarServiceMock.setPage('Management Reports');
    loginUtilsMock = new LoginUtilsMock();

    component = new ManagementReportComponent(
      <any> managementReportService,
      <any> navbarServiceMock,
      <any> payloadDataServiceSpy,
      <any> toastServiceMock,
      <any> changeDetectorMock,
      <any> loginUtilsMock
    );

    component.contentFrame = fakeIframeElement;
  });

  describe('the server is functioning correctly', () => {

    describe('User is not logged in', () => {
      beforeEach(() => {
        spyOn(localStorage, 'getItem').and.returnValue(null);
        loginUtilsMock.isUserLoggedIn = createSpy('isUserLoggedIn').and.returnValue(false);
      });

      it('should not call getAllReports if payload data is null and user is not logged in', fakeAsync(() => {

        payloadDataServiceSpy.sendPayload(null);
        tick();
        expect(managementReportService.getAllReports).not.toHaveBeenCalled();
      }));

      it('should not call getAllReports if event is not showManagementReports and not logged in', () => {
        payloadDataServiceSpy.sendPayload({event: 'notShowManagementReports'});
        expect(managementReportService.getAllReports).not.toHaveBeenCalled();
      });
    });

    describe('User is logged in', () => {
      beforeEach(() => {
        spyOn(localStorage, 'getItem').and.returnValue(null);
        component.ngOnInit();
      });

      it('should create component', () => {
        expect(component).toBeTruthy();
      });

      it('should subscribe to payloadData', fakeAsync(() => {
        spyOn(payloadDataServiceSpy.payloadData, 'subscribe').and.callThrough();
        component.ngOnInit();
        tick();
        expect(payloadDataServiceSpy.payloadData.subscribe).toHaveBeenCalled();
      }));


      it('should call getAllReports if payload data is null and user is logged in', () => {
        loginUtilsMock.isUserLoggedIn = createSpy('isUserLoggedIn').and.returnValue(true);
        payloadDataServiceSpy.sendPayload(null);
        expect(managementReportService.getAllReports).toHaveBeenCalled();
      });

    });

    it('should call getAllReports if we are logged in', () => {
      spyOn(localStorage, 'getItem').and.returnValue('valid_token');
      component.ngOnInit();
      expect(managementReportService.getAllReports).toHaveBeenCalled();
    });

    describe('selecting a report', () => {
      let selectedNode;
      beforeEach(() => {
        selectedNode = {
          selected: {
            id: REPORT_ID,
            name: REPORT_NAME,
            userData: USER_DATA
          },
          event: {
            stopPropagation: createSpy('stopPropagation')
          }
        };
      });

      it('should stop event propagation when onReportSelected is called', () => {
        component.onReportSelected(selectedNode);
        expect(selectedNode.event.stopPropagation).toHaveBeenCalled();
      });

      it('sets the selected ID to the id passed into onReportSelected', () => {
        component.onReportSelected(selectedNode);
        expect(component.selectedReport.id).toEqual(REPORT_ID);
      });

      it('should set the report name to the name passed into onReportSelected', () => {
        component.onReportSelected(selectedNode);
        expect(component.selectedReport.name).toEqual(REPORT_NAME);
      });

      it('sets the selected id to null when the same report id is passed in as is already selected', () => {
        component.selectedReport = selectedNode.selected;
        component.onReportSelected(selectedNode);

        expect(component.selectedReport).toBeNull();
      });

      it('should get the parameters for that report', () => {
        component.selectedReport = selectedNode;
        component.onReportSelected(selectedNode);

        expect(managementReportService.getParameters).toHaveBeenCalledWith(123);
      });
    });

    describe('generating HTML reports', () => {
      it('calls the generate HTML endpoint', () => {
        component.documentType = 'Html';
        component.onParametersSave({format: 'Html', values: {}, reportId: 'Test'});
        expect(managementReportService.generateReport).toHaveBeenCalledWith('Test', 'html', []);
      });
    });

    describe('categorising reports', () => {
      it('should group reports into correct categories', () => {
        component.fetchReports();

        expect(component.reportTreeNodes[0].name).toEqual('Report Cat 1');
        expect(component.reportTreeNodes[0].nodes.length).toEqual(2);

        expect(component.reportTreeNodes[1].name).toEqual('Report Cat 2');
        expect(component.reportTreeNodes[1].nodes.length).toEqual(1);
      });
    });

    describe('no permissions', () => {
      beforeEach(() => {
        payloadDataServiceSpy.sendPayload({event: 'browser'});
        managementReportService.getPermissions = jasmine.createSpy('getPermissions').and.returnValue(Observable.of({}));
        component.ngOnInit();
      });

      it('should not call get reports', fakeAsync(() => {
        expect(managementReportService.getAllReports).not.toHaveBeenCalled();
      }));

      it('should display a toast', fakeAsync(() => {
        expect(toastServiceMock.warning).toHaveBeenCalledWith('You do not have permission to view this page');
      }));
    });

    describe('when saving parameters', () => {
      beforeEach(() => {
        component.selectedReport = {id: REPORT_ID, name: REPORT_NAME} as TreeNode;
        component.pdfPostData = {};
        component.pdfUrl = 'bob';
      });

      describe('on html event', () => {
        beforeEach(() => {
          component.iframeVisible = false;
          component.pdfViewerVisible = true;
          component.documentType = 'Html';
          component.onParametersSave({format: 'Html', reportId: REPORT_ID, values: {}});
        });

        it('should call generate report', () => {
          expect(managementReportService.generateReport).toHaveBeenCalledWith(REPORT_ID, 'html', []);
        });

        it('should show iframe', () => {
          expect(component.iframeVisible).toBeTruthy();
        });

        it('should hide pdf viewer', () => {
          expect(component.pdfViewerVisible).toBeFalsy();
          expect(component.pdfUrl).toBeNull();
          expect(component.pdfPostData).toBeNull();
        });

        it('should write the html to the iFrame', () => {
          expect(fakeIframeElement.nativeElement.contentWindow.document.open).toHaveBeenCalled();
          expect(fakeDocument.write).toHaveBeenCalledWith(VALID_HTML);
          expect(fakeDocument.close).toHaveBeenCalled();
        });
      });

      describe('on pdf event', () => {
        beforeEach(() => {
          component.iframeVisible = true;
          component.documentType = 'Pdf';
          component.pdfViewerVisible = false;
          component.onParametersSave({format: 'Pdf', reportId: REPORT_ID, values: {}});
        });

        it('should hide iframe', () => {
          expect(component.iframeVisible).toBeFalsy();
        });

        it('should show pdf viewer', () => {
          expect(component.pdfViewerVisible).toBeTruthy();
        });

        it('should set pdf information', () => {
          expect(component.pdfUrl).toEqual(RENDER_URL);
          expect(component.pdfPostData).toEqual({
            template: REPORT_ID,
            format: 'pdf',
            params: []
          });
        });

        it('should write the html to the iFrame', () => {
          expect(fakeIframeElement.nativeElement.contentWindow.document.open).toHaveBeenCalled();
          expect(fakeDocument.write).toHaveBeenCalledWith(VALID_HTML);
          expect(fakeDocument.close).toHaveBeenCalled();
        });
      });

      describe('on xls event', () => {
        beforeEach(() => {
          component.iframeVisible = true;
          component.pdfViewerVisible = true;
          component.documentType = 'Xls';
          component.fileSaver = {
            saveAs: createSpy('saveAs')
          };
          component.onParametersSave({format: 'Xls', reportId: REPORT_ID, values: {}});
        });

        it('should hide iframe', () => {
          expect(component.iframeVisible).toBeFalsy();
        });

        it('should hide pdf viewer', () => {
          expect(component.pdfViewerVisible).toBeFalsy();
          expect(component.pdfUrl).toBeNull();
          expect(component.pdfPostData).toBeNull();
        });

        it('should save file', () => {
          expect(component.fileSaver.saveAs).toHaveBeenCalled();
        });
      });

    });
  });

});
