import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';
import {HistoricalPatientRoute} from './historical-patient-results.routes';
import {CommonModule} from '@angular/common';
import {HistoricalPatientResultsComponent} from './historical-patient-results.component';
import {SharedModule} from '../shared/shared.module';

@NgModule({
  declarations: [HistoricalPatientResultsComponent],
  imports: [RouterModule.forChild([HistoricalPatientRoute]), CommonModule, SharedModule],
  exports: [HistoricalPatientResultsComponent]
})
export class HistoricalPatientResultsModule { }
