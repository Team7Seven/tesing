/* tslint:disable:no-unused-variable */
import {discardPeriodicTasks, fakeAsync, tick} from '@angular/core/testing';
import {CumulativeReportsComponent} from './cumulative-reports.component';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {Observable} from 'rxjs/Observable';
import {Subject} from 'rxjs/Subject';
import createSpy = jasmine.createSpy;
import Spy = jasmine.Spy;

describe('CumulativeReportsComponent', () => {

  const fakeDocument = {
    write: createSpy('docwriter'),
    close: createSpy('docclose')
  };

  const fakeIframeElement = {
    nativeElement: {
      contentWindow: {
        document: {
          open: createSpy('docopen').and.returnValue(fakeDocument)
        }
      }
    }
  };

  class PayloadDataServiceSpy {
    payloadData = new BehaviorSubject('');
    sendPayload = createSpy('sendPayload').and.callFake((data) => {
      this.payloadData.next(data);
    });
  }

  class ToastrServiceMock {
    warning = createSpy('toastWarning');
  }

  class PatientReportServiceMock {
    getReport: Spy;
    getPermissions: Spy;
  }

  class NavbarDataServiceMock {
    setPage = createSpy('setPage');
  }

  class PatientRequestDoctorHelperMock {
    networkError = new Subject();
    resetObservables = createSpy('resetObservables');
    fetchPatientRequestDoctorFromRequestId = createSpy('fetchPatientRequestDoctorFromRequestId');
  }

  class SubscriptionMock {
    unsubscribe = createSpy('unsub');
  }

  const validPayload = {request: '2518', panel: 'GLU', tiebreaker: '0', doctor: 'TEST', pformat: ''};

  let payloadDataServiceSpy: PayloadDataServiceSpy;
  let patientReportServiceMock: PatientReportServiceMock;
  let toasterServiceMock: ToastrServiceMock;
  let navbarServiceMock: NavbarDataServiceMock;
  let component: CumulativeReportsComponent;
  let patientRequestDoctorHelperMock: PatientRequestDoctorHelperMock;
  let subscriptionMock: SubscriptionMock;

  beforeEach(() => {
    payloadDataServiceSpy = new PayloadDataServiceSpy();
    patientReportServiceMock = new PatientReportServiceMock();
    toasterServiceMock = new ToastrServiceMock();
    navbarServiceMock = new NavbarDataServiceMock();
    patientRequestDoctorHelperMock = new PatientRequestDoctorHelperMock();
    subscriptionMock = new SubscriptionMock();

    patientReportServiceMock.getPermissions = jasmine.createSpy('getPermissions').and.returnValue(Observable.of({find: true}));

    component = new CumulativeReportsComponent(
      <any> payloadDataServiceSpy,
      <any> patientReportServiceMock,
      <any> patientRequestDoctorHelperMock,
      <any> toasterServiceMock,
      <any> navbarServiceMock
    );

    component.contentFrame = fakeIframeElement;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should subscribe to payloadData', fakeAsync(() => {
    spyOn(payloadDataServiceSpy.payloadData, 'subscribe').and.callThrough();
    component.ngOnInit();
    tick();
    expect(payloadDataServiceSpy.payloadData.subscribe).toHaveBeenCalled();
  }));

  it('should subscribe to network errors', fakeAsync(() => {
    spyOn(patientRequestDoctorHelperMock.networkError, 'subscribe').and.callThrough();
    component.ngOnInit();
    tick();
    expect(patientRequestDoctorHelperMock.networkError.subscribe).toHaveBeenCalled();
  }));

  it('should reset observables on the patient/request/doctor helper on init', fakeAsync(() => {
    component.ngOnInit();
    tick();
    expect(patientRequestDoctorHelperMock.resetObservables).toHaveBeenCalled();
  }));

  describe('the server is running correctly', () => {
    beforeEach(() => {
      patientReportServiceMock.getReport = createSpy('getReport').and.returnValue(Observable.of('reports galore'));
      component.ngOnInit();
    });

    it('should request the users permissions to view this page', () => {
      payloadDataServiceSpy.sendPayload({event: 'showpatreport', payload: validPayload});

      expect(patientReportServiceMock.getPermissions).toHaveBeenCalled();
    });

    it('should make call to the patient report service when a valid showpatreport event is sent', () => {
      payloadDataServiceSpy.sendPayload({event: 'showpatreport', payload: validPayload});

      expect(patientReportServiceMock.getReport).toHaveBeenCalledWith(validPayload);
    });

    it('should set the report text in iframe when the report is retrieved', fakeAsync(() => {
      payloadDataServiceSpy.sendPayload({event: 'showpatreport', payload: validPayload});
      tick();

      expect(fakeDocument.write).toHaveBeenCalledWith('reports galore');
      discardPeriodicTasks();
    }));

    it('should not call getReport if payload data is null', () => {
      payloadDataServiceSpy.sendPayload(null);
      expect(patientReportServiceMock.getReport).not.toHaveBeenCalled();
    });

    it('should not call getReport if event is not showpatreport', () => {
      payloadDataServiceSpy.sendPayload({event: 'somethingelse', payload: validPayload});
      expect(patientReportServiceMock.getReport).not.toHaveBeenCalled();
    });

  });

  describe('restricted permissions', () => {
    beforeEach(() => {
      payloadDataServiceSpy.sendPayload({event: 'showpatreport', payload: validPayload});
      patientReportServiceMock.getReport = createSpy('getReport').and.returnValue(Observable.of('reports galore'));
      patientReportServiceMock.getPermissions = jasmine.createSpy('getPermissions').and.returnValue(Observable.of({find: false}));
      component.ngOnInit();
    });

    it('does not request report or request details when the user does not have find permissions', () => {
      expect(patientReportServiceMock.getReport).not.toHaveBeenCalled();
      expect(patientRequestDoctorHelperMock.fetchPatientRequestDoctorFromRequestId).not.toHaveBeenCalled();
    });

    it('pops a warning toast when the user does not have find permissions', () => {
      expect(toasterServiceMock.warning).toHaveBeenCalledWith('You do not have permission to view this page.');
    });
  });

  describe('Network error', () => {

    it('should clear report html on network error', () => {
      component.ngOnInit();
      spyOn(component, 'setReportHtml').and.callThrough();
      patientRequestDoctorHelperMock.networkError.next(true);
      expect(fakeDocument.write).toHaveBeenCalledWith('');
    });

    it('should unsubscribe if we are fetching a report', () => {
      component.ngOnInit();
      component.reportSub = <any> subscriptionMock;
      patientRequestDoctorHelperMock.networkError.next(true);
      expect(subscriptionMock.unsubscribe).toHaveBeenCalled();
    });
  });
});
