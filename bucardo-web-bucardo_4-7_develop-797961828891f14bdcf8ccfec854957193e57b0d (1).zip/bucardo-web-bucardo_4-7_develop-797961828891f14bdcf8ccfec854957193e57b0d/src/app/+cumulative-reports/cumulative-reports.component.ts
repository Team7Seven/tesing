import {Component, ElementRef, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {Subscription} from 'rxjs/Subscription';
import {PatientReportService} from './shared/patient-report.service';
import {PayloadDataService} from '../shared/services/payload-data/payload-data.service';
import {NavbarDataService} from '../shared/components/navigation/navbar/navbar-data-service';
import {PatientRequestDoctorHelper} from '../shared/component-helpers/patient-request-doctor.helper';
import {ToastrService} from 'ngx-toastr';

@Component({
  selector: 'cumulative-reports',
  templateUrl: './cumulative-reports.component.html',
  styleUrls: ['./cumulative-reports.component.scss'],
  providers: [PatientReportService]
})

export class CumulativeReportsComponent implements OnInit, OnDestroy {

  permissions: any = {};
  reportSub: Subscription;
  permissionsSub: Subscription;

  private payloadDataSubscription: Subscription;
  @ViewChild('contentFrame') contentFrame: ElementRef;

  constructor(private payloadDataService: PayloadDataService,
              private patientReportService: PatientReportService,
              public patientRequestDoctorHelper: PatientRequestDoctorHelper,
              private toastService: ToastrService,
              private navbarService: NavbarDataService) {
    navbarService.setPage('Patient Reports');
  }

  ngOnInit() {
    this.patientRequestDoctorHelper.resetObservables();
    this.patientRequestDoctorHelper.networkError.subscribe(() => this.onNetworkError());

    this.payloadDataSubscription = this.payloadDataService.payloadData.subscribe(data => {
      if (data && data.event === 'showpatreport') {

        if (this.permissions.find) {
          this.fetchPageData(data.payload);
        }

        if (!this.permissionsSub) {
          this.permissionsSub = this.patientReportService.getPermissions().subscribe(
            (permissions) => {
              this.permissions = permissions;
              this.fetchPageData(data.payload);
            }
          );
        }
      }
    });
  }

  private fetchPageData(payload) {
    if (this.permissions.find) {
      this.fetchReport(payload);
      this.patientRequestDoctorHelper.fetchPatientRequestDoctorFromRequestId(payload.request);
    } else {
      this.toastService.warning('You do not have permission to view this page.');
    }
  }

  private onNetworkError() {
    if (this.reportSub) {
      this.reportSub.unsubscribe();
    }

    this.setReportHtml('');
  }

  private fetchReport(reportPayload) {
    this.reportSub = this.patientReportService.getReport(reportPayload).subscribe(
      reportContents => this.setReportHtml(reportContents)
      ,
      error => {
        this.patientRequestDoctorHelper.resetObservables();
        this.setReportHtml('');

        throw error;
      }
    );
  }

  private setReportHtml(contents) {
    if (this.contentFrame) {
      const newDoc = this.contentFrame.nativeElement.contentWindow.document.open('text/html', 'replace');
      newDoc.write(contents);
      newDoc.close();
    }
  }

  ngOnDestroy() {
    this.payloadDataSubscription.unsubscribe();
  }

}
