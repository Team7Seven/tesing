import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {HttpModule} from '@angular/http';
import {RouterModule} from '@angular/router';
import {SharedModule} from '../shared/shared.module';
import {HomeComponent} from './home.component';
import {AuthGuard} from '../guards/auth.guard';
import {AuthenticationService} from '../shared/services/authentication/authentication.service';

@NgModule({
  imports: [CommonModule, SharedModule, FormsModule, HttpModule, RouterModule],
  declarations: [HomeComponent],
  exports: [HomeComponent],
  providers: [AuthGuard, AuthenticationService]
})
export class HomeModule {
}
