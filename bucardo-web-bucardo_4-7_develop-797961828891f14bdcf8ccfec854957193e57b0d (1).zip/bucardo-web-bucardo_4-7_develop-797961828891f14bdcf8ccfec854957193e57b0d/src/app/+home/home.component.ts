import { Component } from '@angular/core';
import { AuthGuard } from '../guards/auth.guard';
import { AuthenticationService } from '../shared/services/authentication/authentication.service';
import {UserService} from '../shared/services/user/user.service';

/**
 * This class represents the lazy loaded HomeComponent.
 */
@Component({
  selector: 'sd-home',
  template: `
      <app-sidebar *ngIf="loggedIn"></app-sidebar>
      <div class="home-container">
          <router-outlet></router-outlet>
      </div>
  `,
  providers: [AuthGuard, AuthenticationService],
  styles: [`
    .home-container {
        padding-left: 55px;
    }
  `],
})

export class HomeComponent {
  loggedIn = false;
  constructor(private userService: UserService) {
    this.userService.user.subscribe((user) => {
      this.loggedIn = user !== null;
    });
  }
}

