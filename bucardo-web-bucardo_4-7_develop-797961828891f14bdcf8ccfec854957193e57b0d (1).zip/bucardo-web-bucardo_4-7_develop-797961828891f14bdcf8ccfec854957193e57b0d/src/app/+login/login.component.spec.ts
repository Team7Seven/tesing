import {LoginComponent} from './login.component';
import {Login} from './shared/models/login.model';
import {Observable} from 'rxjs/Observable';
import createSpy = jasmine.createSpy;

describe('LoginComponent', () => {
  let component: LoginComponent;
  let authServiceMock: MockAuthService;
  let routerMock: MockRouter;
  let apiClientMock: MockApiClient;
  let userServiceMock: MockUserService;
  let navServiceMock: MockNavService;

  class MockAuthService {
    login = createSpy('login');
    logout = createSpy('logout');
  }

  class MockRouter {
    navigate = createSpy('navigate');
  }

  class MockApiClient {
    setAuthToken = createSpy('setAuthToken');
  }

  class MockUserService {
    clearUser = createSpy('clearUser');
    getUserDetails = createSpy('getUserDetails').and.returnValue(Observable.of({}));
  }

  class MockNavService {
    setPage = createSpy('setPage');
  }

  beforeEach(() => {
    authServiceMock = new MockAuthService();
    routerMock = new MockRouter();
    apiClientMock = new MockApiClient();
    userServiceMock = new MockUserService();
    navServiceMock = new MockNavService();

    component = new LoginComponent(<any> authServiceMock,
      <any> routerMock,
      <any> apiClientMock,
      <any> userServiceMock,
      <any> navServiceMock);
  });


  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('on init', () => {
    beforeEach(() => {
      component.ngOnInit();
    });

    it('should reset login details', () => {
      expect(authServiceMock.logout).toHaveBeenCalled();
    });

    it('should clear user', () => {
      expect(userServiceMock.clearUser).toHaveBeenCalled();
    });

    it('should set the page name on the nav bar', () => {
      expect(navServiceMock.setPage).toHaveBeenCalled();
    });
  });

  describe('on successful login', () => {
    beforeEach(() => {
      setLoginResult(true);
      component.model = new Login('bobert', 'Jumbone', 'Bob', 'McConnell', '');
      component.onSubmit();
    });

    it('should call login on submit', () => {
      expect(authServiceMock.login).toHaveBeenCalledWith(component.model);
    });

    it('should navigate to management-report', () => {
      expect(routerMock.navigate).toHaveBeenCalledWith(['/management-report']);
    });
  });

  describe('on login fail', () => {
    beforeEach(() => {
      setLoginResult(false);
      component.onSubmit();
    });

    it('should not navigate to dashboard ', () => {
      expect(routerMock.navigate).not.toHaveBeenCalled();
    });

    it('should reset the loading flag', () => {
      expect(component.loading).toBeFalsy();
    });

    it('should set an error message', () => {
      expect(component.errorMessage).toBeTruthy();
    });
  });

  function setLoginResult(result: any) {
    authServiceMock.login = createSpy('login').and.returnValue(Observable.from([result]));
  }

});
