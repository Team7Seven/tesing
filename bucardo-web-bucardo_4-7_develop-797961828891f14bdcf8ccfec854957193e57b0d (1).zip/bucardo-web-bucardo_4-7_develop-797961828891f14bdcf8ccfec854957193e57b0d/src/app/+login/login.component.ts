import {Component, OnInit} from '@angular/core';
import {Login} from './shared/models/login.model';
import {AuthenticationService} from '../shared/services/authentication/authentication.service';
import {Router} from '@angular/router';
import {UserService} from '../shared/services/user/user.service';
import {ApiClient} from '../shared/services/api-client/api-client';
import {NavbarDataService} from '../shared/components/navigation/navbar/navbar-data-service';

/**
 * This class represents the lazy loaded AuthenticationComponent.
 */
@Component({
  selector: 'orac-authentication',
  templateUrl: 'login.component.html',
  styleUrls: ['login.component.scss'],
  providers: [AuthenticationService]
})

export class LoginComponent implements OnInit {

  regulatoryText = '';
  version = '4.7';
  model = new Login('', '', '', '', '');
  errorMessage = '';
  loading = false;

  /**
   * Creates an instance of the AuthenticationComponent with the injected
   * AuthenticationService.
   *
   * @param {AuthenticationService} authenticationService - The injected AuthenticationService.
   */
  constructor(private authenticationService: AuthenticationService,
              private router: Router,
              private apiClient: ApiClient,
              private userService: UserService,
              private navService: NavbarDataService) {
  }

  ngOnInit() {
    // reset login status
    this.authenticationService.logout();
    this.userService.clearUser();
    this.navService.setPage('Login');
  }

  onSubmit() {
    this.loading = true;
    this.authenticationService.login(this.model)
      .subscribe((token: string) => {
        if (token) {
          this.apiClient.setAuthToken(token);
          this.userService.getUserDetails(localStorage.getItem(this.authenticationService.USERNAME_TOKEN)).subscribe(() => {});
          this.router.navigate(['/management-report']);
        } else {
          // login failed
          this.errorMessage = 'Username or password is incorrect';
          this.loading = false;
        }
      });
  }
}

