import {AfterViewInit, Component, OnInit, ViewContainerRef} from '@angular/core';
import {AuthGuard} from './guards/auth.guard';
import {AuthenticationService} from './shared/services/authentication/authentication.service';
import {ConfigurationService} from './shared/services/configuration/configuration.service';
import {ApiErrorHandler} from './shared/services/api-client/api-error-handler';
import {UserService} from './shared/services/user/user.service';
import {Router} from '@angular/router';
import {ToastrService} from 'ngx-toastr';

/**
 * This class represents the main application component. Within the @Routes annotation is the configuration of the
 * applications routes, configuring the paths for the lazy loaded components (HomeComponent, AboutComponent).
 */
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  providers: [AuthGuard, AuthenticationService]
})
export class AppComponent implements AfterViewInit, OnInit {
  constructor(public viewContainerRef: ViewContainerRef, private router: Router, private config: ConfigurationService,
              private toastService: ToastrService, private userService: UserService) {

  }

  ngOnInit() {
    const username = localStorage.getItem('username');

    if (username) {
      this.userService.getUserDetails(username).subscribe(
        () => {
        },
        () => this.router.navigate(['login']));
    }
  }

  ngAfterViewInit(): void {
    if (!this.config.isInitialised()) {
      this.popNoConnectionToast();
    }
  }

  private popNoConnectionToast() {
    this.toastService.error(ApiErrorHandler.noServiceMsg, 'Error');
  }
}
