import {Routes} from '@angular/router';

import {HomeRoute} from './+home/home.routes';
import {LoginRoute} from './+login/login.routes';
import {MenuItem} from './shared/utils/menu-utils';

const DefaultRoute = {
  path: '**', redirectTo: '/'
};

export const MenuItems: MenuItem[] = [
  {
    path: '/management-report',
    iconClass: 'fa fa-heartbeat',
    name: 'Management Reports',
    shortcut: 'mgr',
    description: 'View management reports'
  },
  {
    path: '/request-scans',
    iconClass: 'fa fa-file-text',
    name: 'Request Scans',
    shortcut: 'rqs',
    description: 'View management reports'
  },
  {
    path: '/editor/body-formats',
    iconClass: 'fa fa-pencil-square-o',
    name: 'Format Editor',
    shortcut: 'edf',
    description: 'View management reports'
  },
  {
    path: '/editor/templates',
    iconClass: 'fa fa-pencil',
    name: 'Template Editor',
    shortcut: 'edt',
    description: 'View management reports'
  }
];

export const routes: Routes = [
  HomeRoute,
  LoginRoute,
  DefaultRoute
];
