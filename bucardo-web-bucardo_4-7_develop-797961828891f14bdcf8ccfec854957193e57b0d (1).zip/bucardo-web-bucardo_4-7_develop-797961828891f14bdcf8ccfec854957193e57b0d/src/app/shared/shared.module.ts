import {ModuleWithProviders, NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {RouterModule} from '@angular/router';

import {NavbarComponent} from './components/navigation/navbar/navbar.component';
import {PageHeaderComponent} from './components/navigation/page-header/page-header.component';

import {TreeNodeComponent} from './components/tree-view/tree-node.component';
import {TreeViewComponent} from './components/tree-view/tree-view.component';
import {PayloadDataService} from './services/payload-data/payload-data.service';

import {ApiClient} from './services/api-client/api-client';
import {SafeHtmlPipe} from './pipes/safe-html.pipe';
import {FyiComponent} from './components/fyi/fyi.component';
import {FyiDirective} from './components/fyi/fyi.directive';
import {FyiService} from './components/fyi/fyi.service';
import {NavbarDataService} from './components/navigation/navbar/navbar-data-service';
import {UserService} from './services/user/user.service';

import {RequestDetailsDataComponent} from './components/request-details/request-details-data.component';
import {MrnHtmlPipe} from './pipes/mrn-html.pipe';
import {PatientDetailsDataComponent} from './components/patient-details/patient-details-data.component';
import {DoctorDetailsDataComponent} from './components/doctor-details/doctor-details-data.component';
import {RequestDetailsService} from './services/request-details/request-details.service';
import {DoctorDetailsService} from './components/doctor-details/doctor-details.service';
import {PatientDetailsService} from './components/patient-details/patient-details.service';
import {DoctorDetailsToggleComponent} from './components/doctor-details/doctor-details-toggle.component';

import {PercentageHeightDirective} from './directives/percentage-height/percentage-height.directive';
import {PercentageHeightComponent} from './components/percentage-height/percentage-height.component';
import {SidebarComponent} from './components/navigation/sidebar/sidebar.component';
import {EscapeHtmlPipe} from './pipes/escape-html.pipe';
import {RestrictPatternDirective} from './directives/restrict-pattern/restrict-pattern.directive';
import {HtmlEditorComponent} from './components/html-editor/html-editor.component';
import {CKEditorModule} from 'ng2-ckeditor';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

import {CustomDatePipe} from './pipes/custom-date.pipe';

import {
  FormButtonRightComponent,
  FormCheckboxComponent,
  FormNameValueComponent,
  FormSelectComponent,
  FormTextAreaComponent,
  FormTextComponent,
  FormWideButtonComponent,
  ValidationComponent
} from './components/form-components';
import {IdleCheckerComponent} from './components/idle-checker/idle-checker.component';
import {ClearWhenIdleComponent} from './components/clear-when-idle/clear-when-idle.component';
import {ErrorReporterService} from './services/error-reporter/error-reporter.service';
import {ApiErrorHandler} from './services/api-client/api-error-handler';
import {IdleCheckerService} from './services/idle-checker/idle-checker.service';
import {SearchBoxItemListComponent} from './components/search-box/search-box-item-list.component';
import {SearchBoxComponent} from './components/search-box/search-box.component';
import {StatusService} from './services/status/status.service';
import {DateUtilsService} from './utils/date-utils.service';
import {NKDatetimeModule} from 'ng2-datetime/ng2-datetime';
import {PdfDisplayComponent} from './components/pdf-display/pdf-display.component';
import {FormDateTimePickerComponent} from './components/form-components/form-date-time-picker';
import {PatientRequestDoctorPanelComponent} from './components/patient-request-doctor-panel/patient-request-doctor-panel.component';
import {NavbarStatusDropdownComponent} from './components/navigation/navbar-status-dropdown/navbar-status-dropdown.component';
import {SocketClientComponent} from './components/socket-client/socket-client.component';
import {PdfViewerComponent} from './components/pdf-display/pdf-viewer.component';
import {LoginUtilsService} from './utils/login-utils.service';
import {DatepickerModule, PopoverModule, TimepickerModule} from 'ngx-bootstrap';
import {AbsoluteContainerComponent} from './components/form-components/form-helpers/absolute-container.component';
import {ResizeDetectDirective} from './directives/resize-detect/resize-detect.directive';
import {FocusAtStartDirective} from './directives/focus-at-start/focus-at-start.directive';
import {VisibleIfDateValidDirective} from './directives/visible-if-date-valid/visible-if-date-valid.directive';
import {PatientRequestDoctorHelper} from './component-helpers/patient-request-doctor.helper';
import {CommandPaletteComponent} from './components/navigation/sidebar/command-palette.component';
import {EventListenerService} from './services/krill-event-listener/event-listener.service';
import {SelectBoxModule} from './components/select-box/select-box.module';


/**
 * Do not specify providers for modules that might be imported by a lazy loaded module.
 */

@NgModule({
  imports: [CommonModule, RouterModule, CKEditorModule, FormsModule, NKDatetimeModule,
    PopoverModule.forRoot(), DatepickerModule.forRoot(), TimepickerModule.forRoot(), ReactiveFormsModule,
    SelectBoxModule],
  declarations: [NavbarComponent, TreeNodeComponent, TreeViewComponent, SafeHtmlPipe, MrnHtmlPipe,
    PatientDetailsDataComponent,
    PercentageHeightDirective, PercentageHeightComponent, RequestDetailsDataComponent,
    DoctorDetailsDataComponent, PageHeaderComponent, FyiDirective, FyiComponent, SidebarComponent, EscapeHtmlPipe,
    RestrictPatternDirective,
    HtmlEditorComponent,
    DoctorDetailsToggleComponent,
    FormTextComponent, FormSelectComponent, FormCheckboxComponent, FormTextAreaComponent, FormNameValueComponent,
    FormWideButtonComponent, FormButtonRightComponent, ValidationComponent, CustomDatePipe,
    IdleCheckerComponent, ClearWhenIdleComponent, SearchBoxComponent, SearchBoxItemListComponent,
    NavbarStatusDropdownComponent, FormDateTimePickerComponent, PatientRequestDoctorPanelComponent,
    SocketClientComponent, PdfDisplayComponent, PdfViewerComponent, AbsoluteContainerComponent, ResizeDetectDirective,
    FocusAtStartDirective, VisibleIfDateValidDirective, CommandPaletteComponent],
  exports: [NavbarComponent, TreeNodeComponent, TreeViewComponent,
    CommonModule, RouterModule, SafeHtmlPipe, MrnHtmlPipe, PatientDetailsDataComponent, PercentageHeightDirective,
    PercentageHeightComponent, RequestDetailsDataComponent, DoctorDetailsDataComponent, DoctorDetailsToggleComponent,
    PageHeaderComponent, FyiDirective, FyiComponent, RestrictPatternDirective, HtmlEditorComponent,
    FormTextComponent, FormSelectComponent, FormCheckboxComponent, FormTextAreaComponent, FormNameValueComponent,
    FormWideButtonComponent, FormButtonRightComponent, ValidationComponent, ClearWhenIdleComponent, SearchBoxComponent,
    NavbarStatusDropdownComponent, FormDateTimePickerComponent, PatientRequestDoctorPanelComponent, SocketClientComponent,
    PdfDisplayComponent, SidebarComponent, ResizeDetectDirective, FocusAtStartDirective, VisibleIfDateValidDirective],
  entryComponents: [SearchBoxItemListComponent, AbsoluteContainerComponent]
})
export class SharedModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: SharedModule,
      providers: [PayloadDataService, ApiClient, PatientDetailsService,
        DoctorDetailsService, RequestDetailsService, FyiService, NavbarDataService, UserService, ErrorReporterService,
        ApiErrorHandler, IdleCheckerService, StatusService, DateUtilsService, PatientRequestDoctorHelper, LoginUtilsService,
        EventListenerService]
    };
  }
}
