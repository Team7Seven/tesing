import createSpy = jasmine.createSpy;
import {PatientRequestDoctorHelper} from './patient-request-doctor.helper';
import {Observable} from 'rxjs/Observable';
import {fakeAsync, tick} from '@angular/core/testing';

describe('PatientRequestDoctorHelper', () => {

  const REQUEST_ID = 'REQ_ID';
  const REF_DOC_ID = 'REF_DOC_ID';
  const USUAL_DOC_ID = 'USUAL_DOC_ID';
  const PATIENT_ID = 'PATIENT_ID';

  const REQUEST = {
    doctor: REF_DOC_ID,
    patient: PATIENT_ID
  };

  const PATIENT = {
    name: 'Bob McBobface',
    usual_doc: USUAL_DOC_ID
  };

  const DOCTOR = {
    name: 'Dr. Who'
  };

  class PatientDetailsMock {
    getDetails = createSpy('getDetailsPatientDetailsMock').and.returnValue(Observable.of(PATIENT));
  }

  class RequestDetailsMock {
    getDetails = createSpy('getDetailsRequestDetailsMock').and.returnValue(Observable.of(REQUEST));
  }

  class DoctorDetailsMock {
    getDetails = createSpy('getDetailsDoctorDetailsMock').and.returnValue(Observable.of(DOCTOR));
  }

  let patientServiceMock: PatientDetailsMock;
  let requestServiceMock: RequestDetailsMock;
  let doctorServiceMock: DoctorDetailsMock;

  let component: PatientRequestDoctorHelper;
  let patient;
  let request;
  let requestingDoctor;
  let usualDoctor;

  beforeEach(() => {
    patientServiceMock = new PatientDetailsMock();
    requestServiceMock = new RequestDetailsMock();
    doctorServiceMock = new DoctorDetailsMock();

    component = new PatientRequestDoctorHelper(
      <any> patientServiceMock,
      <any> requestServiceMock,
      <any> doctorServiceMock
    );

    component.patient.subscribe((p) => patient = p);
    component.request.subscribe((r) => request = r);
    component.requestingDoctor.subscribe((rd) => requestingDoctor = rd);
    component.usualDoctor.subscribe((ud) => usualDoctor = ud);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('fetchPatientRequestDoctorFromRequestId', () => {

    it('should call request service with request ID', () => {
      component.fetchPatientRequestDoctorFromRequestId(REQUEST_ID);
      expect(requestServiceMock.getDetails).toHaveBeenCalledWith(REQUEST_ID);
    });

    it('should get the referring doctor from the request', fakeAsync(() => {
      component.fetchPatientRequestDoctorFromRequestId(REQUEST_ID);
      tick();
      expect(doctorServiceMock.getDetails).toHaveBeenCalledWith(REF_DOC_ID);
      expect(request.doctor).toEqual(REQUEST.doctor);
    }));

    it('should get the usual doctor from the patient', fakeAsync(() => {
      component.fetchPatientRequestDoctorFromRequestId(REQUEST_ID);
      tick();
      expect(doctorServiceMock.getDetails).toHaveBeenCalledWith(USUAL_DOC_ID);
    }));

    it('should get the patient from the request', fakeAsync(() => {
      component.fetchPatientRequestDoctorFromRequestId(REQUEST_ID);
      tick();
      expect(patientServiceMock.getDetails).toHaveBeenCalledWith(PATIENT_ID);
      expect(patient.name).toEqual(PATIENT.name);
    }));

    it('should reset all observables when request is null', fakeAsync(() => {
      requestingDoctor = DOCTOR;
      usualDoctor = DOCTOR;
      patient = PATIENT;
      request = REQUEST;

      component.fetchPatientRequestDoctorFromRequestId(null);

      tick();

      expect(requestingDoctor).toBeNull();
      expect(usualDoctor).toBeNull();
      expect(patient).toBeNull();
      expect(request).toBeNull();
    }));
  });


  describe('reset observables', () => {

    it('should reset all observables when request is null', fakeAsync(() => {
      requestingDoctor = DOCTOR;
      usualDoctor = DOCTOR;
      patient = PATIENT;
      request = REQUEST;

      component.resetObservables();

      tick();

      expect(requestingDoctor).toBeNull();
      expect(usualDoctor).toBeNull();
      expect(patient).toBeNull();
      expect(request).toBeNull();
    }));
  });

});
