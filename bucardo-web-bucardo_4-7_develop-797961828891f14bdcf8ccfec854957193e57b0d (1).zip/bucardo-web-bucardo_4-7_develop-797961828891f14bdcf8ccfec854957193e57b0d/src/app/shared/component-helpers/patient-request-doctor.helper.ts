import {PatientDetailsModel} from '../components/patient-details/patient-details.model';
import {RequestModel} from '../models/request.model';
import {DoctorDetailsModel} from '../components/doctor-details/doctor-details.model';
import {PatientDetailsService} from '../components/patient-details/patient-details.service';
import {DoctorDetailsService} from '../components/doctor-details/doctor-details.service';
import {RequestDetailsService} from '../services/request-details/request-details.service';
import {Observable} from 'rxjs/Observable';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {Injectable} from '@angular/core';
import {Subscription} from 'rxjs/Subscription';
import {Subject} from 'rxjs/Subject';
import {unsub} from '../utils/subsription-utils';

@Injectable()
export class PatientRequestDoctorHelper {
  private _patient: BehaviorSubject<PatientDetailsModel> = new BehaviorSubject(null);
  private _request: BehaviorSubject<RequestModel> = new BehaviorSubject(null);
  private _requestingDoctor: BehaviorSubject<DoctorDetailsModel> = new BehaviorSubject(null);
  private _usualDoctor: BehaviorSubject<DoctorDetailsModel> = new BehaviorSubject(null);
  private _networkError: Subject<Boolean> = new Subject();

  public readonly patient: Observable<PatientDetailsModel> = this._patient.asObservable();
  public readonly request: Observable<RequestModel> = this._request.asObservable().share();
  public readonly requestingDoctor: Observable<DoctorDetailsModel> = this._requestingDoctor.asObservable();
  public readonly usualDoctor: Observable<DoctorDetailsModel> = this._usualDoctor.asObservable();
  public readonly networkError: Observable<Boolean> = this._networkError.asObservable();

  private patientSub: Subscription;
  private requestSub: Subscription;
  private requestDocSub: Subscription;
  private usualDocSub: Subscription;

  constructor(private patientService: PatientDetailsService,
              private requestService: RequestDetailsService,
              private doctorService: DoctorDetailsService) {

  }

  public fetchPatientRequestDoctorFromRequestId(requestId): void {
    if (requestId) {
      this.requestSub = this.requestService.getDetails(requestId).subscribe(
        (request: RequestModel) => this.receiveNewRequest(request),
        error => this.handleNetworkError(error));
    } else {
      this.resetObservables();
    }
  }

  public fetchPatientDetails(patientId: string) {
    if (patientId && patientId.trim().length) {
      this.patientSub = this.patientService.getDetails(patientId.trim()).subscribe(
        patient => {
          this._patient.next(patient);
          this.fetchUsualDoctorFromPatientRecord(patient);
        },
        error => this.handleNetworkError(error));
    } else {
      this._patient.next(null);
    }
  }

  public resetObservables() {
    unsub(this.requestSub);
    unsub(this.patientSub);
    unsub(this.requestDocSub);
    unsub(this.usualDocSub);

    this._patient.next(null);
    this._request.next(null);
    this._requestingDoctor.next(null);
    this._usualDoctor.next(null);
  }

  receiveNewRequest(request: RequestModel) {
    this._request.next(request);
    this._requestingDoctor.next(null);

    this.fetchReferringDoctorFromRequest(request);
    this.fetchPatientFromRequest(request);
  }

  private fetchReferringDoctorFromRequest(request: RequestModel) {
    if (request.doctor && request.doctor.trim().length) {
      this.requestDocSub = this.doctorService.getDetails(request.doctor.trim()).subscribe(
        doctor => this._requestingDoctor.next(doctor),
        error => this.handleNetworkError(error));
    } else {
      this._requestingDoctor.next(null);
    }
  }

  private handleNetworkError(error) {
    this.resetObservables();
    this._networkError.next(true);
    throw error;
  }

  private fetchPatientFromRequest(request: RequestModel) {
    this.fetchPatientDetails(request.patient);
  }

  private fetchUsualDoctorFromPatientRecord(patient: PatientDetailsModel) {
    if (patient.usual_doc && patient.usual_doc.trim().length) {
      this.usualDocSub = this.doctorService.getDetails(patient.usual_doc.trim()).subscribe(
        doctor => this._usualDoctor.next(doctor),
        error => this.handleNetworkError(error));
    } else {
      this._usualDoctor.next(null);
    }
  }

}
