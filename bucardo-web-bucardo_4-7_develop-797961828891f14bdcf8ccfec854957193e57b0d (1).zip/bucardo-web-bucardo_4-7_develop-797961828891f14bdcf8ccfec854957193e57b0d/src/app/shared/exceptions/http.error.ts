import {Response} from '@angular/http';
import {CustomToast} from '../services/error-reporter/custom-toast';

export class HttpError extends Error {
  public errorType = 'HttpError';

  constructor(public response: Response, public message: string, public customToast?: CustomToast) {
    super(message);
  }
}
