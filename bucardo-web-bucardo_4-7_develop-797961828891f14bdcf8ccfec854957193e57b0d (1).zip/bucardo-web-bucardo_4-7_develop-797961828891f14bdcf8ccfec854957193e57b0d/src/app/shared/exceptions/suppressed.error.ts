export class SuppressedError extends Error {
  public errorType = 'SuppressedError';

  constructor(public message = '') {
    super(message);
  }
}
