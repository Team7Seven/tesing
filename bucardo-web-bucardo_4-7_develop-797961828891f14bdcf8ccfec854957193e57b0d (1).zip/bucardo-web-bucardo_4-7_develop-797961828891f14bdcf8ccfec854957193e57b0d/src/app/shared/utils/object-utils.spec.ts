import {removePropertiesFromObject} from './object-utils';

describe('ObjectUtils', () => {

  const myObject = {
    prop1: 1,
    prop2: 2,
    prop3: 3,
    prop4: 4
  };

  it('should filter properties if they exist', () => {
    const result = removePropertiesFromObject(myObject, ['prop2', 'prop3']);

    const resultKeys = Object.keys(result);

    expect(resultKeys.length).toBe(2);
    expect(resultKeys).toContain('prop1');
    expect(resultKeys).toContain('prop4');
    expect(resultKeys).not.toContain('prop2');
    expect(resultKeys).not.toContain('prop3');
  });

  it('should filter properties if they exist', () => {
    const result = removePropertiesFromObject(myObject, ['prop5', 'prop6']);

    expect(Object.keys(result).length).toBe(4);
  });
 });
