import {Data, LoadChildren, ResolveData, Route} from '@angular/router';
import {Type} from '@angular/core';
import {UrlMatcher} from '@angular/router/src/config';

export interface MenuItem {
  iconClass: string;
  name: string;
  shortcut: string;
  path: string;
  description?: string;
}

export interface MenuRoute extends Route {
  path?: string;
  pathMatch?: string;
  matcher?: UrlMatcher;
  component?: Type<any>;
  redirectTo?: string;
  outlet?: string;
  canActivate?: any[];
  canActivateChild?: any[];
  canDeactivate?: any[];
  canLoad?: any[];
  data?: Data;
  resolve?: ResolveData;
  children?: MenuRoute[];
  loadChildren?: LoadChildren;
  menuItem?: MenuItem;
}

export class MenuUtils {
  static parseRouteForMenuItems(menuRoute: MenuRoute, path = []) {
    console.info('menuRoute:', menuRoute);

    let menuItemList: { path: any[], menuItem: MenuItem }[] = [];

    if (menuRoute.path) {
      path.push(menuRoute.path);
    }

    if (menuRoute.menuItem) {
      console.info('pushing', menuRoute.menuItem);
      menuItemList.push({path, menuItem: menuRoute.menuItem});
    }

    if (menuRoute.children) {
      for (const child of menuRoute.children) {
        menuItemList = menuItemList.concat(MenuUtils.parseRouteForMenuItems(child, path.slice()));
      }
    }

    console.info('menuItemList', menuItemList);
    return menuItemList;
  }
}

