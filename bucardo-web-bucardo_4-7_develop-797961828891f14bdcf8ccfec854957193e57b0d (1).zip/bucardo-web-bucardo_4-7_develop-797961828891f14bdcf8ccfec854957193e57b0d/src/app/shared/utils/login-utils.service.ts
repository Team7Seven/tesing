import {Injectable} from '@angular/core';
import {ApiClient} from '../services/api-client/api-client';

@Injectable()
export class LoginUtilsService {

  constructor(private apiClient: ApiClient) {}

  isUserLoggedIn() {
    console.info('user logged in:', localStorage.getItem('token'));
    return localStorage.getItem('token') || this.apiClient.getAuthToken();
  }

}
