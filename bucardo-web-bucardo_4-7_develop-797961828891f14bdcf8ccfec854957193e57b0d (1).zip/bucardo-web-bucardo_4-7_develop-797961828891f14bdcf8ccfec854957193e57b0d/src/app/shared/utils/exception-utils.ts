export function isExceptionType(exception: any, type: string): boolean {
  return (exception.hasOwnProperty('errorType') && exception.errorType === type);
}

