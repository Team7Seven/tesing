export interface FormatModel {
  name: string;
  code: string;
  items: boolean;
}
