export class PanelModel {
  ri: string;
  status: string;
  request: string;
  panel: string;
  tiebreaker: string;
  line_number: string;
  urgent: string;
  report_status: string;
  date_modified: Date;
  requesting_lab: string;
  performing_lab: string;
  r_lab: string;
  short_desc: string;
}
