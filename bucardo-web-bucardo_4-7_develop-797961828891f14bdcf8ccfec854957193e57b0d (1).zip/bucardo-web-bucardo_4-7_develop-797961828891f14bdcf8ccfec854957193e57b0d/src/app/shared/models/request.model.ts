import {SpecimenModel} from '../components/request-details/specimen.model';
import {PanelModel} from './panel.model';

export class RequestModel {
  ri: string;
  prefix: string;
  num: string;
  requesting_lab: string;
  status: string;
  date_service: string;
  patient: string;
  date_refer: string;
  doctor: string;
  doctor_name: string;
  entered_by: string;
  date_entry: string;
  coln_centre: string;
  coln_centre_name: string;
  coln_by: string;
  date_coln: string;
  specimens: SpecimenModel[];
  panels: PanelModel[];
  urgent_text: string;
  confidential: string;
  visit: string;
  date_last_result: string;
  age: string;
  age_units: string;
}
