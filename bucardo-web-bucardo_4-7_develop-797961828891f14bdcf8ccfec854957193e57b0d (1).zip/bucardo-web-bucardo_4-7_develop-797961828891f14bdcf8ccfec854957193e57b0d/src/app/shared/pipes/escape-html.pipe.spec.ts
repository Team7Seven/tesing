import {EscapeHtmlPipe} from './escape-html.pipe';

describe('Escape HTML Pipe', () => {
  let pipe: EscapeHtmlPipe;

  beforeEach(() => {
    pipe = new EscapeHtmlPipe();
  });

  it('should replace & with &amp;', () => {
    expect(pipe.transform('Jake&Ben')).toEqual('Jake&amp;Ben');
  });

  it('should replace quotes with &quot;', () => {
      expect(pipe.transform('"Quotes"')).toEqual('&quot;Quotes&quot;');
  });

  it('should replace single quotes with &#39;', () => {
    expect(pipe.transform('\'SingleQuotes\'')).toEqual('&#39;SingleQuotes&#39;');
  });

  it('should replace spaces with &ensp;', () => {
    expect(pipe.transform('Hello Mum')).toEqual('Hello&ensp;Mum');
  });

  it('should replace html tags with &lt; and &gt;', () => {
    expect(pipe.transform('<div>SomeStuff</div>')).toEqual('&lt;div&gt;SomeStuff&lt;/div&gt;');
  });

  it('should replace new line character with br tag', () => {
    expect(pipe.transform('Return\nChar')).toEqual('Return<br/>Char');
  });
});
