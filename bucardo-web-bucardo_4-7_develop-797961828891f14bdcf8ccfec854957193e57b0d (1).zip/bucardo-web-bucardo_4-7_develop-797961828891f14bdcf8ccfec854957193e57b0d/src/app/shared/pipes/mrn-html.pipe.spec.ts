import {MrnHtmlPipe} from './mrn-html.pipe';

describe('Mrn HTML Pipe', () => {
  let pipe: MrnHtmlPipe;

  const mrnField = 'authority';
  const mrnValue = 'CHI';
  const chiMrn = [{authority: 'CHI', num: '1234567890', ri: '2'}];
  const famMrn = [{authority: 'FAM', num: '116', ri: '660'}];
  const blankArray = [];

  const mrnItems = [{authority: 'CHI', num: '1234567890', ri: '2'},
    {authority: 'FAM', num: '116', ri: '660'},
    {authority: 'AND', num: '1', ri: '613'},
    {authority: 'B', num: '567890', ri: '146'},
    {authority: 'ARI', num: '654321', ri: '147'}];

  const mrnItemsNoCHI = [{authority: 'FAM', num: '116', ri: '660'},
    {authority: 'AND', num: '1', ri: '613'},
    {authority: 'B', num: '567890', ri: '146'},
    {authority: 'ARI', num: '654321', ri: '147'}];

  beforeEach(() => {
    pipe = new MrnHtmlPipe();
  });

  it('should return a CHI MRN', () => {
    expect(pipe.transform(mrnItems, mrnField, mrnValue)).toEqual(chiMrn);
  });

  it('should return a FAM MRN', () => {
    expect(pipe.transform(mrnItemsNoCHI, mrnField, mrnValue)).toEqual(famMrn);
  });

  it('should return a blank array if the items are a blank array', () => {
    expect(pipe.transform(blankArray, mrnField, mrnValue)).toEqual(blankArray);
  });

  it('should return a blank array if the items are null', () => {
    expect(pipe.transform(blankArray, mrnField, mrnValue)).toEqual(blankArray);
  });

});
