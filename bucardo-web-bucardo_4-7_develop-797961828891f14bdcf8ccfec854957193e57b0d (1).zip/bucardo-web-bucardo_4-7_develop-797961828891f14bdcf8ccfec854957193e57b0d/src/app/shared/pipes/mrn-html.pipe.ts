import {Pipe, PipeTransform} from '@angular/core';

@Pipe({name: 'mrnHtml'})
export class MrnHtmlPipe implements PipeTransform {
  transform(items: any[], field: string, value: string): any[] {
    let mrnFiltered: any[];
    if (!items || items.length === 0) {
      return [];
    }

    mrnFiltered = items.filter(it => it[field] === value);

    if (mrnFiltered.length === 0) {
      // We couldn't find our MRN use the first one
      mrnFiltered.push(items[0]);
      return mrnFiltered;
    } else {
      return mrnFiltered;
    }
  }
}
