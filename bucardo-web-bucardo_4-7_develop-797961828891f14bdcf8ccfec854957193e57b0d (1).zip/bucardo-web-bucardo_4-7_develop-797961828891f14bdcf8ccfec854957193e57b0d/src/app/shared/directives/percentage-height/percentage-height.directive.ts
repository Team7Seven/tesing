import {Directive, ElementRef, Renderer, OnInit} from '@angular/core';

@Directive({
  selector: '[percentageHeight]'
})
export class PercentageHeightDirective implements OnInit {

  constructor(private element: ElementRef, private renderer: Renderer) { }

  ngOnInit() {
    this.renderer.setElementStyle(this.element.nativeElement, 'overflow-y', 'auto');
    this.renderer.setElementStyle(this.element.nativeElement, 'overflow-x', 'hidden');
  }
}
