import {PercentageHeightDirective} from './percentage-height.directive';
import {async} from '@angular/core/testing';

describe('PercentageHeightDirective', () => {

  class ElementRefStub {
    nativeElement: any;
  }

  class RendererStub {
    setElementStyle: Function;
  }

  let directive: PercentageHeightDirective;
  let elementRefMock: ElementRefStub;
  let rendererMock: RendererStub;

  beforeEach(async(() => {
    elementRefMock = new ElementRefStub();
    elementRefMock.nativeElement = {};
    rendererMock = new RendererStub();
    rendererMock.setElementStyle = jasmine.createSpy('setElementStyle').and.callFake(() => {});
    directive = new PercentageHeightDirective(elementRefMock, <any>rendererMock);
  }));

  it('should set overflow styles', () => {
    directive.ngOnInit();
    expect(rendererMock.setElementStyle).toHaveBeenCalledTimes(2);
    expect(rendererMock.setElementStyle).toHaveBeenCalledWith(elementRefMock.nativeElement, 'overflow-y', 'auto');
    expect(rendererMock.setElementStyle).toHaveBeenCalledWith(elementRefMock.nativeElement, 'overflow-x', 'hidden');
  });
});
