import {Directive, Input, HostListener, HostBinding} from '@angular/core';

@Directive({
  selector: '[restrict-pattern]'
})
export class RestrictPatternDirective {

  @HostBinding('pattern')
  @Input() pattern: string;

  @HostListener('input', ['$event']) onKeyPress(event) {
    const regex = new RegExp(this.pattern);

    if (!regex.test(event.target.value)) {
      event.target.value = event.target.value.slice(0, -1); // remove last char

      this.setAttachedAngularFormValue(event.target.form, event.target.name, event.target.value);
    }
  }

  private setAttachedAngularFormValue(form, formElementName, value) {
    const formValue = {};
    formValue[formElementName] = value;
    form.patchValue(formValue);
  }

}
