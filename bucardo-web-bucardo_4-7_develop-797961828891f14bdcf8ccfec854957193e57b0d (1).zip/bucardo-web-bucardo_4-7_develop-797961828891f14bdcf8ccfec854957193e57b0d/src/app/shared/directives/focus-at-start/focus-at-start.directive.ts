import {AfterViewInit, Directive, ElementRef, Input, Renderer} from '@angular/core';
import * as $ from 'jquery';

@Directive({
  selector: '[focusAtStart]'
})
export class FocusAtStartDirective implements AfterViewInit {

  @Input() focusAtStart: string;

  constructor(private element: ElementRef, private renderer: Renderer) {
  }

  ngAfterViewInit() {
    if (this.focusAtStart) {
      $(this.element.nativeElement).find(this.focusAtStart).focus();
    } else {
      this.element.nativeElement.focus();
    }
  }

}
