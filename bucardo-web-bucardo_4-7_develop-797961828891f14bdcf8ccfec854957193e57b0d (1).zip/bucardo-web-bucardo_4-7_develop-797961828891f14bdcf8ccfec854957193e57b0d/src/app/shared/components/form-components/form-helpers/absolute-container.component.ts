import {Component, ElementRef, HostListener, OnInit, ViewChild} from '@angular/core';

@Component({
  selector: 'absolute-container',
  template: `
      <div class="absolute-container" #container *ngIf="visible"
           [ngStyle]="{'left.px': horPos, 'top.px': vertPos, 'display': display}">
          <ng-content>
          </ng-content>
      </div>`,
  styleUrls: ['./absolute-container.component.scss']
})
export class AbsoluteContainerComponent implements OnInit {

  @ViewChild('container') container: ElementRef;

  top: number;
  left: number;
  offset: number;
  belowPos: number;
  abovePos: number;
  vertPos = -2000;
  horPos = -2000;
  visible = false;
  forceDropUp = false;
  display: string;
  inputElement: ElementRef;
  intervalRef: any;
  scrollableParent: Element;

  ngOnInit() {
  }

  setOffSet(offset: number) {
    this.offset = offset;
    this.updatePosition();
  }

  setPosition(top: number, left: number) {
    this.top = top;
    this.horPos = this.left = left;
    this.updatePosition();
  }

  updatePosition() {
    if (this.container) {
      const containerHeight = this.container.nativeElement.clientHeight;

      this.belowPos = this.top + this.offset;
      this.abovePos = this.top - containerHeight;

      if ((this.belowPos + containerHeight) > window.innerHeight || this.forceDropUp) {
        this.vertPos = this.abovePos;
      } else {
        this.vertPos = this.belowPos;
      }
    }
  }

  @HostListener('window:click', ['$event'])
  autocloseOnExternalClick(event) {
    if (!this.visible) {
      return;
    }

    if (event.path) {
      if (event.path.indexOf(this.container.nativeElement) === -1) {
        this.visible = false;
      }
      return;
    }

    let clicked = event.target;

    while (clicked !== null) {
      if (clicked === this.container.nativeElement) {
        return;
      }
      clicked = clicked.parentElement;
    }
    this.visible = false;
  }

  getScrollableParent(node: Element, i = 0): boolean {
    if (node === null) {
      return false;
    }

    if (node.scrollHeight > node.clientHeight) {
      this.scrollableParent = node;
      return true;
    }

    this.getScrollableParent(node.parentElement, i + 1);
  }

  calculatePosition() {
    // as this function is called in several places, check it is not already running
    if (!this.intervalRef && this.visible) {
      this.intervalRef = setInterval(() => {
        if (this.container) {
          const inputPosition = this.inputElement.nativeElement.getBoundingClientRect();
          this.setOffSet(this.inputElement.nativeElement.clientHeight);
          this.setPosition(inputPosition.top,
            (inputPosition.left + this.inputElement.nativeElement.clientWidth));
          this.display = 'block';
          clearInterval(this.intervalRef);
          this.intervalRef = null;
        }
      }, 2);
    }
  }

  recalculateOnParentScroll() {
    const waitingForElement = setInterval(() => {
      if (this.inputElement) {
        this.getScrollableParent(this.inputElement.nativeElement);
        if (this.scrollableParent) {
          this.scrollableParent.addEventListener('scroll', () => {
            this.visible = false;
          });
        }
        clearInterval(waitingForElement);
      }
    }, 500);
  }


}
