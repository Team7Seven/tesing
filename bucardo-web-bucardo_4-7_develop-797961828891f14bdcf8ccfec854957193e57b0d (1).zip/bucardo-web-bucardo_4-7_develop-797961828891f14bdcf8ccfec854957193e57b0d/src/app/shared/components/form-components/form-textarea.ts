import {
  Component,
  Optional,
  Inject,
  Input,
  ViewChild, SimpleChanges, OnChanges, OnInit,
} from '@angular/core';

import {
  NgModel,
  NG_VALUE_ACCESSOR,
  NG_VALIDATORS,
  NG_ASYNC_VALIDATORS,
} from '@angular/forms';

import {ElementBase} from './form-helpers';

let identifier = 0;

/* tslint:disable:no-access-missing-member */
@Component({
  selector: 'form-text-area',
  template: `
    <div class="form-group">
      <label class="control-label col-lg-12" *ngIf="label" [attr.for]="identifier">{{label}}</label>
      <div class="col-lg-12">
        <textarea
          type="text"
          class="form-control"
          [readonly]="readonly"
          [placeholder]="placeholder"
          [(ngModel)]="value"
          [ngClass]="{invalid: (invalid | async)}"
          [id]="identifier"
          [maxlength]="maxLength"
          [disabled]="disabled"
          [title]="ariaLabel"
        ></textarea>
      </div>
      <validation
        *ngIf="invalid | async"
        [messages]="failures | async">
      </validation>
    </div>
  `,
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: FormTextAreaComponent,
    multi: true,
  }],
})
export class FormTextAreaComponent extends ElementBase<string> implements OnChanges, OnInit {
  @Input() public label = '';
  @Input() public placeholder = '';
  @Input() public readonly = false;
  @Input() public maxLength = 1000000;
  @Input() public inputId;
  @Input() public disabled = false;

  @ViewChild(NgModel) model: NgModel;

  public identifier;
  public ariaLabel = '';

  constructor(
    @Optional() @Inject(NG_VALIDATORS) validators: Array<any>,
    @Optional() @Inject(NG_ASYNC_VALIDATORS) asyncValidators: Array<any>,
  ) {
    super(validators, asyncValidators);
  }

  ngOnChanges(changes: SimpleChanges): void {
    if ('inputId' in changes) {
      this.identifier = this.inputId || `form-text-${identifier++}`;
    }
  }

  ngOnInit() {
    this.ariaLabel = this.getAriaLabel();
  }
}
