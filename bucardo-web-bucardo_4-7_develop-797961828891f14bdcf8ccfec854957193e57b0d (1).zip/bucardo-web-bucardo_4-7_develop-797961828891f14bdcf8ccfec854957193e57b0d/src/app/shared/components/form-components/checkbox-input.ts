import {
  Component,
  Optional,
  Inject,
  Input,
  ViewChild, OnInit,
} from '@angular/core';

import {
  NgModel,
  NG_VALUE_ACCESSOR,
  NG_VALIDATORS,
  NG_ASYNC_VALIDATORS,
} from '@angular/forms';

import {ElementBase} from './form-helpers';

let identifier = 0;

/* tslint:disable:no-access-missing-member */
@Component({
  selector: 'form-checkbox',
  template: `
    <div class="form-group col-lg-6">
      <div class="checkbox">
          <label>
              <input disabled="{{readonly}}" type="checkbox"
                     [title]="ariaLabel"
              [(ngModel)]="value"
              [ngClass]="{invalid: (invalid | async)}"
              [id]="identifier"
              > {{label}}
          </label>
      </div>
    </div>
  `,
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: FormCheckboxComponent,
    multi: true,
  }],
})
export class FormCheckboxComponent extends ElementBase<boolean> implements OnInit {
  @Input() public label = '';
  @Input() public readonly = false;

  @ViewChild(NgModel) model: NgModel;

  public identifier = `form-checkbox-${identifier++}`;

  ariaLabel = '';

  constructor(@Optional() @Inject(NG_VALIDATORS) validators: Array<any>,
              @Optional() @Inject(NG_ASYNC_VALIDATORS) asyncValidators: Array<any>) {
    super(validators, asyncValidators);
  }

  ngOnInit() {
    this.getAriaLabel();
  }
}
