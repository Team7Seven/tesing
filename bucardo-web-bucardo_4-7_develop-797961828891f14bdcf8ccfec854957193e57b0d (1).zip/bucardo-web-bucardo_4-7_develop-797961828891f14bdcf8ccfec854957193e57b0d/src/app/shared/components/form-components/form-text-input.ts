import {Component, Optional, Inject, Input, ViewChild, OnChanges, SimpleChanges, OnInit} from '@angular/core';
import {NgModel, NG_VALUE_ACCESSOR, NG_VALIDATORS, NG_ASYNC_VALIDATORS} from '@angular/forms';
import {ElementBase} from './form-helpers';

let identifier = 0;

/* tslint:disable:no-access-missing-member */
@Component({
  selector: 'form-text',
  template: `
    <div class="form-group">
      <label class="control-label {{labelClass}}" *ngIf="label" [attr.for]="identifier">{{label}}</label>
      <div class="col-lg-9 {{inputClass}}">
        <input
          type="text"
          class="form-control"
          [title]="ariaLabel"
          [readonly]="readonly"
          [placeholder]="placeholder"
          [(ngModel)]="value"
          [ngClass]="{invalid: (invalid | async)}"
          [id]="identifier"
          [maxlength]="maxLength"
        />
      </div>
      <validation
        *ngIf="invalid | async"
        [messages]="failures | async">
      </validation>
    </div>
  `,
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: FormTextComponent,
    multi: true,
  }],
})
export class FormTextComponent extends ElementBase<string> implements OnChanges, OnInit {

  @Input() public label = '';
  @Input() public placeholder = '';
  @Input() public readonly = false;
  @Input() public maxLength = 1000000;
  @Input() public labelClass = 'col-lg-3';
  @Input() public inputClass = 'col-lg-9';
  @Input() public inputId;

  @ViewChild(NgModel) model: NgModel;
  public ariaLabel = '';
  public identifier;

  constructor(@Optional() @Inject(NG_VALIDATORS) validators: Array<any>,
              @Optional() @Inject(NG_ASYNC_VALIDATORS) asyncValidators: Array<any>) {
    super(validators, asyncValidators);

  }

  ngOnInit() {
    this.ariaLabel = this.getAriaLabel();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if ('inputId' in changes) {
      this.identifier = this.inputId || `form-text-${identifier++}`;
    }
  }

}

