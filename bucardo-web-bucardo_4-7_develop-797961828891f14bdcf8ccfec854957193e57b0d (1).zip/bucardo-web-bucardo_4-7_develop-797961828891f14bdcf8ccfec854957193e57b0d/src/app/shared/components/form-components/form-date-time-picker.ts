import {
  Component, Input, OnChanges, SimpleChanges, OnInit, forwardRef, ViewChild, HostListener, ComponentFactoryResolver,
  ApplicationRef, ComponentFactory, ComponentRef, Injector, ElementRef, EmbeddedViewRef, OnDestroy, Output,
  EventEmitter,
} from '@angular/core';
import {NG_VALUE_ACCESSOR, ControlValueAccessor, FormControl, NG_VALIDATORS} from '@angular/forms';
import {DatePickerComponent} from 'ngx-bootstrap';

import * as moment from 'moment';
import {AbsoluteContainerComponent} from './form-helpers/absolute-container.component';
import {CustomValidators} from '../../validators/custom.validators';

let identifier = 0;

@Component({
  selector: 'form-date-time-picker',
  template: `
    <div class="form-group">
      <label class="{{labelClass}}" *ngIf="label" [attr.for]="identifier">
        {{label}}<span class="required" *ngIf="required">*</span>
      </label>
      <div class="col-lg-8">
        <div class="input-group">
          <input [(ngModel)]="value" class="form-control" [title]="ariaLabel" #input>
          <span class="input-group-addon" *ngIf="showDatePicker" (click)="toggleCalendar()">
            <i class="fa fa-calendar"></i></span>
          <span class="input-group-addon" *ngIf="showTimePicker" (click)="toggleClock()">
            <i class="fa fa-clock-o"></i></span>
        </div>
      </div>
    </div>

    <div class="datepicker-container">
      <span *ngIf="showDatePicker" #dp>
        <datepicker [ngClass]="{'hidden': !dpVisible}" [showWeeks]="true" (selectionDone)="selectDate($event)"
                    [(ngModel)]="date"
                    #datepickerComponent></datepicker>
      </span>
      <span *ngIf="showTimePicker" #tp>
        <div [ngClass]="{'hidden': !tpVisible}" class="well well-sm bg-faded p-a card">
          <timepicker  [(ngModel)]="time" (ngModelChange)="timeChanged($event)" #timepicker></timepicker>
        </div>
      </span>
    </div>
  `,
  styles: [`
    .input-group-addon {
      padding: 0 !important;
      border: none;
    }
    span i {
      padding: 0 8px;
    }
  `],
  providers: [
    {provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => FormDateTimePickerComponent), multi: true},
    {provide: NG_VALIDATORS, useExisting: forwardRef(() => FormDateTimePickerComponent), multi: true}
  ],
})

export class FormDateTimePickerComponent implements OnChanges, OnInit, ControlValueAccessor, OnDestroy {

  @Input() public label = '';
  @Input() public labelClass = 'col-lg-4';
  @Input() public showTimePicker = true;
  @Input() public showDatePicker = true;
  @Input() public inputId;
  @Input() public format;
  @Input() public allowRelativeDates = true;
  @Input() public required = false;
  @Input('ngModel') _value: any;
  @Output() dateChanged = new EventEmitter<Date>();

  @ViewChild('dp') datepicker: ElementRef;
  @ViewChild('input') input: ElementRef;
  @ViewChild('tp') timepicker: any;
  @ViewChild('datepickerComponent') datepickerComponent: DatePickerComponent;

  date: Date;
  dpComponentRef: ComponentRef<AbsoluteContainerComponent>;
  tpComponentRef: ComponentRef<AbsoluteContainerComponent>;
  containerComponentFactory: ComponentFactory<AbsoluteContainerComponent>;
  datePickerContainer: AbsoluteContainerComponent;
  timePickerContainer: AbsoluteContainerComponent;
  rootComponent: any;
  time = '';
  identifier;
  dpVisible: boolean;
  tpVisible: boolean;
  interval: any;
  ariaLabel = '';
  validateFn: Function;

  private propagateChange = (_: any) => {
  }

  constructor(private factoryResolver: ComponentFactoryResolver, private applicationRef: ApplicationRef, private injector: Injector) {
    this.containerComponentFactory = this.factoryResolver.resolveComponentFactory(AbsoluteContainerComponent);
    this.rootComponent = this.applicationRef['_rootComponents'][0];
    this.dpVisible = false;
    this.tpVisible = false;
  }


  ngOnInit(): void {
    if (this.showDatePicker) {
      this.attachDatepickerWhenVisible();
    }
    if (this.showTimePicker) {
      this.attachTimepickerWhenReady();
    }
    this.ariaLabel = this.getAriaLabel();
    this.validateFn = CustomValidators.createDateFormatValidator(this.format, this.allowRelativeDates);
  }

  attachDatepickerWhenVisible() {
    const dpInterval = setInterval(() => {
      if (this.showDatePicker && this.datepicker && this.datepicker.nativeElement) {
        this.dpComponentRef = this.containerComponentFactory.create(this.injector, [[this.datepicker.nativeElement]]);
        this.datePickerContainer = this.setUpContainer(this.dpComponentRef);
        clearInterval(dpInterval);
      }
    }, 50);
  }

  attachTimepickerWhenReady() {
    const tpInterval = setInterval(() => {
      if (this.timepicker && this.timepicker.nativeElement) {
        this.tpComponentRef = this.containerComponentFactory.create(this.injector, [[this.timepicker.nativeElement]]);
        this.timePickerContainer = this.setUpContainer(this.tpComponentRef);
        clearInterval(tpInterval);
      }
    }, 50);
  }

  setUpContainer(componentRef: ComponentRef<any>) {
    this.applicationRef.attachView(componentRef.hostView);
    componentRef.onDestroy(() => {
      this.applicationRef.detachView(componentRef.hostView);
    });
    this.getComponentRootNode(this.rootComponent).appendChild(this.getComponentRootNode(componentRef));

    const componentInstance = componentRef.instance;
    componentInstance.forceDropUp = true;
    componentInstance.inputElement = this.input;
    componentInstance.calculatePosition();
    componentInstance.recalculateOnParentScroll();

    return componentInstance;
  }


  getComponentRootNode(componentRef: ComponentRef<any>): HTMLElement {
    return (componentRef.hostView as EmbeddedViewRef<any>).rootNodes[0] as HTMLElement;
  }


  ngOnChanges(changes: SimpleChanges): void {
    if ('inputId' in changes) {
      this.identifier = this.inputId || `form-text-${identifier++}`;
    }
    if ('_value' in changes && changes['_value'].currentValue instanceof Date) {
      this.date = changes['_value'].currentValue;
      this.value = moment(this.date).format(this.getFormat());
    }
    if ('format' in changes) {
      this.validateFn = CustomValidators.createDateFormatValidator(this.format, this.allowRelativeDates);
    }
  }

  writeValue(obj: any): void {
    if (obj) {
      this._value = obj;
    }
  }

  set value(value: string) {
    if (value !== null && value !== this.value) {
      this._value = value;
      const m = moment(value, this.getFormat(), true);
      if (m.isValid()) {
        this.date = m.toDate();
        this.propagateChange(this.date);
      } else {
        this.propagateChange(value);
      }
    }
  }

  get value() {
    if (this._value instanceof Date) {
      this._value = moment(this._value).format(this.getFormat());
    }
    return this._value;
  }

  registerOnChange(fn: any): void {
    this.propagateChange = fn;
  }

  registerOnTouched(fn: any): void {
  }

  onChange(data) {
    this.propagateChange(data);
  }

  selectDate(event: Date) {
    const dateOnly = moment(event).format('YYYY-MM-DD');
    const timeOnly = (this.time) ? moment(this.time, 'hh:mm a').format('HH:mm') : '00:00';

    const date = new Date(dateOnly + 'T' + timeOnly);

    this.value = moment(date).format(this.getFormat());

    this.dateChanged.emit(date);

    this.datePickerContainer.visible = false;
  }

  timeChanged(time) {
    const timeOnly = moment(time).format('HH:mm');
    const dateOnly = moment(this.date).format('YYYY-MM-DD');
    const date = new Date(dateOnly + 'T' + timeOnly);

    this.value = moment(date).format(this.getFormat());

    this.dateChanged.emit(date);
  }

  toggleCalendar() {
    if (this.datePickerContainer.visible) {
      // just return, autoclose in container will take care of closing
      return;
    }
    // debounce to allow for autoclose if click outside container
    setTimeout(() => {
      this.datePickerContainer.visible = this.dpVisible = !this.datePickerContainer.visible;
      this.datePickerContainer.calculatePosition();
    }, 40);
  }

  toggleClock() {
    if (this.timePickerContainer.visible) {
      // just return, autoclose in container will take care of closing
      return;
    }
    // debounce to allow for autoclose if click outside container
    setTimeout(() => {
      this.timePickerContainer.visible = this.tpVisible = !this.timePickerContainer.visible;
      this.timePickerContainer.calculatePosition();
    }, 20);
  }

  ngOnDestroy(): void {
    if (this.tpComponentRef) {
      this.tpComponentRef.destroy();
    }
    if (this.dpComponentRef) {
      this.dpComponentRef.destroy();
    }
  }

  getFormat() {
    if (this.format) {
      return this.format;
    }

    if (!this.showTimePicker) {
      return 'Do MMMM, YYYY';
    }

    if (!this.showDatePicker) {
      return 'HH:mm A';
    }

    return 'Do MMMM, YYYY HH:mm A';
  }

  getAriaLabel() {
    if (this.label) {
      return this.label;
    }
    if (!this.showTimePicker) {
      return 'Select Date';
    }
    if (!this.showDatePicker) {
      return 'Select Time';
    }
  }

  validate(c: FormControl) {
    return this.validateFn(c);
  }
}
