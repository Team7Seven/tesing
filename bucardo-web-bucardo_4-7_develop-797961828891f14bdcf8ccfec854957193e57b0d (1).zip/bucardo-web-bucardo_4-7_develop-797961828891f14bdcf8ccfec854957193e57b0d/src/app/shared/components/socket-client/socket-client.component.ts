import {Component, OnInit} from '@angular/core';
import {EventListenerService} from '../../services/krill-event-listener/event-listener.service';

import * as qs from 'querystring';

@Component({
  selector: 'socket-client',
  template: ``,
  providers: [EventListenerService]
})
export class SocketClientComponent implements OnInit {

  constructor(private krillEventListenerService: EventListenerService) {
  }

  ngOnInit() {
    this.getBidFromQueryParamsAndAddToLocalStorage(location.search.substr(1));
  }

  getBidFromQueryParamsAndAddToLocalStorage(queryString) {
    const params = this.parseQueryString(queryString);
    const bid: string = params['bid'] || localStorage.getItem('BID');

    if (bid) {
      localStorage.setItem('BID', bid);
      this.krillEventListenerService.registerSocketListener();
    }
  }

  private parseQueryString(queryString) {
    return qs.parse(queryString);
  }

}
