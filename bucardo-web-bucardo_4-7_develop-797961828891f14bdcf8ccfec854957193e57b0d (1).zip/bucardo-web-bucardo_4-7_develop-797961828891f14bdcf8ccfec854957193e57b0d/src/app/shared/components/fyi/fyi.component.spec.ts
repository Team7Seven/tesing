/* tslint:disable:no-unused-variable */
import {ComponentFixture, TestBed, fakeAsync, tick} from '@angular/core/testing';
import {By} from '@angular/platform-browser';
import {DebugElement} from '@angular/core';

import {FyiComponent} from './fyi.component';
import {FyiService} from './fyi.service';
import {Subject} from 'rxjs/Subject';

describe('FyiComponent', () => {
  let component: FyiComponent;
  let fixture: ComponentFixture<FyiComponent>;
  let fyiService: FyiService;
  let debugElement: DebugElement;
  let htmlElement: HTMLElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FyiComponent],
      providers: [FyiService]
    });
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FyiComponent);
    component = fixture.componentInstance;
    fyiService = fixture.debugElement.injector.get(FyiService);

    spyOn(fyiService, 'setFyiMessage').and.callFake((message) => {
      component.fyiMessage = message;
    });

    spyOn(fyiService.fyiMessage, 'subscribe').and.returnValue(new Subject());

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should subscribe to fyi message service when created', () => {
    expect(fyiService.fyiMessage.subscribe).toHaveBeenCalled();
  });

  it('should not be displayed if a message has not been sent', () => {
    debugElement = fixture.debugElement.query(By.css('.fyi-message'));

    expect(debugElement).toEqual(null);
  });

  it('should display the message passed in via the service', fakeAsync(() => {
    fyiService.setFyiMessage('test message');
    tick();
    fixture.detectChanges();

    debugElement = fixture.debugElement.query(By.css('.fyi-message'));
    htmlElement = debugElement.nativeElement;

    expect(htmlElement.textContent).toContain('test message');
  }));

});
