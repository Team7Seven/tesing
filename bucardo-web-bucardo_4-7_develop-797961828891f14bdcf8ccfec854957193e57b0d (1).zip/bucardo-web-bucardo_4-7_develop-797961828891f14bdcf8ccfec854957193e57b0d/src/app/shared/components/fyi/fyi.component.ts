import { Component, OnInit } from '@angular/core';
import {FyiService} from './fyi.service';

@Component({
  selector: 'fyi-component',
  templateUrl: 'fyi.component.html',
  styleUrls: ['fyi.component.scss']
})
export class FyiComponent implements OnInit {

  fyiMessage;

  constructor(private fyiService: FyiService) { }

  ngOnInit() {
    this.fyiService.fyiMessage.subscribe((message) => {
        this.fyiMessage = message;
    });
  }

}
