import {FyiDirective} from './fyi.directive';

describe('Directive: Fyi', () => {

  class FyiServiceMock {

  }

  it('should create an instance', () => {
    const directive = new FyiDirective(<any>new FyiServiceMock());
    expect(directive).toBeTruthy();
  });
});
