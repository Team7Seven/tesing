/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { FyiService } from './fyi.service';

describe('Service: Fyi', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FyiService]
    });
  });

  it('should ...', inject([FyiService], (service: FyiService) => {
    expect(service).toBeTruthy();
  }));
});
