import {Directive, Input, HostListener} from '@angular/core';
import {FyiService} from './fyi.service';

@Directive({
  selector: '[fyi]'
})
export class FyiDirective {

  @Input() fyi: string;

  constructor(private fyiService: FyiService) {}

  @HostListener('focus') onFocus() {
    this.fyiService.setFyiMessage(this.fyi);
  }

  @HostListener('blur') onBlur() {
    this.fyiService.setFyiMessage('');
  }

}
