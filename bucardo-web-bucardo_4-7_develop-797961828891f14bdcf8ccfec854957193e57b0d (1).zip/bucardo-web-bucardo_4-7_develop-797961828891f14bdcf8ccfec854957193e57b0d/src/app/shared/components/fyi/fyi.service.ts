import {Injectable} from '@angular/core';
import {Subject} from 'rxjs/Subject';

@Injectable()
export class FyiService {

  private fyiMessageSubject = new Subject();
  fyiMessage = this.fyiMessageSubject.asObservable();

  constructor() { }

  setFyiMessage(message: string) {
    this.fyiMessageSubject.next(message);
  }

}
