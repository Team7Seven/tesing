import {discardPeriodicTasks, fakeAsync, tick} from '@angular/core/testing';

import {SearchBoxComponent} from './search-box.component';
import {ChangeDetectorRef, SimpleChange} from '@angular/core';
import {SearchBoxItemListComponent} from './search-box-item-list.component';
import {SearchBoxItemModel} from './search-box-item.model';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import Spy = jasmine.Spy;
import createSpy = jasmine.createSpy;

const UP = 38;
const ENTER = 13;
const ESC = 27;
const TAB = 9;
const KEY_Y = 89;

describe('SearchBoxComponent', () => {
  class ComponentFactoryResolverMock {
    resolveComponentFactory: Spy;
  };

  class ComponentMock {
    instance: {
      viewContainerRef: {
        createComponent: Spy
      }
    };
  }

  class ApplicationRefMock {
    components: Array<any>;
    bootstrap: Spy;
    tick: Spy;
    componentTypes: Array<any>;
  }

  const changeDetectionMock = {
    detectChanges: (_: any) => {
    }
  } as ChangeDetectorRef;

  let cfr: ComponentFactoryResolverMock;
  let appRef: ApplicationRefMock;
  let rootComponent: ComponentMock;
  let listComponent: SearchBoxItemListComponent;
  let component: SearchBoxComponent;

  const items: BehaviorSubject<Array<SearchBoxItemModel>> = new BehaviorSubject([
    {id: '1', text: 'One'},
    {id: '2', text: 'Two'},
    {id: '3', text: 'Three'}
  ]);

  const ITEM = {id: 123, text: 'ITEM_VALUE'};

  function keyEvent(keyCode: number, ctrlKey = false) {
    return {
      keyCode: keyCode,
      ctrlKey: ctrlKey,
      preventDefault: jasmine.createSpy('preventDefault')
    };
  }

  beforeEach(() => {
    cfr = new ComponentFactoryResolverMock();
    appRef = new ApplicationRefMock();
    rootComponent = new ComponentMock();
    listComponent = new SearchBoxItemListComponent(changeDetectionMock);

    rootComponent.instance = {
      viewContainerRef: {
        createComponent: jasmine.createSpy('createComponent')
          .and.returnValue({
            instance: listComponent,
            changeDetectorRef: {
              detectChanges: jasmine.createSpy('changeDetector')
            }
          })
      }
    };

    appRef.components = [rootComponent];
    appRef.componentTypes = [{name: 'Test Component'}];

    cfr.resolveComponentFactory = jasmine.createSpy('reolveComponentFactory').and.returnValue({});


    component = new SearchBoxComponent(cfr, <any>appRef);
    component.items = items;
    component.setFilterValue('', false);


    // Fake the outputs
    component.ctrlEnterPressed = <any>{
      emit: jasmine.createSpy('ctrlEnterPressed')
    };
    component.selectedChanged = <any>{
      emit: jasmine.createSpy('selectedChanged')
    };

    component.ngOnInit();

  });

  describe('OnChanges', () => {

    it('should filter items if filter is changed', () => {
      component.listComponent.visible = true;
      component.setFilterValue('T');
      component.serverSideFiltering = false;
      component.filter = 'T';
      component.ngOnChanges({
        filter: new SimpleChange(null, 'T', true)
      });

      expect(listComponent.filteredItems.length).toEqual(2); // Two and Three match T
    });
  });

  describe('Focus and Blur', () => {


    describe('On Item List Blurred', () => {


      it('should hide item list if item list and filter aren`t focused', fakeAsync(() => {
        component.listComponent.inFocus = false;

        component.onFilterBlur();

        tick(1000);

        expect(listComponent.visible).toEqual(false);
      }));
    });

    describe('On Filter Focused', () => {
      let event: any;

      beforeEach(() => {
        component.filterFocused = <any>{emit: createSpy('filterFocused')};
        event = {
          target: {
            select: jasmine.createSpy('eventtargetselect')
          }
        };

        component.onFilterFocused(event);
      });

      it('should select all text when filter is focused', () => {
        expect(event.target.select).toHaveBeenCalled();
      });

      it('should set the item list to be visible', () => {
        expect(listComponent.visible).toEqual(true);
      });

      it('should set a flag to indicate the filter is focused', () => {
        expect(component.filterIsFocused).toEqual(true);
      });

      it('should emit an event saying that the filter was focused', () => {
        expect(component.filterFocused.emit).toHaveBeenCalled();
      });
    });

    describe('On Filter Blurred', () => {

      it('should set flag', () => {
        component.onFilterBlur();
        expect(component.filterIsFocused).toEqual(false);
      });

      it('should hide item list if item list and filter aren`t focused', fakeAsync(() => {
        listComponent.inFocus = false;
        listComponent.visible = true;
        component.onFilterBlur();

        tick(1000);

        expect(listComponent.visible).toEqual(false);
      }));
    });

  });

  describe('onFilterChange', () => {

    it('should filter requests', () => {
      component.listComponent.visible = true;
      component.filter = 'T';

      component.ngOnChanges({
        filter: new SimpleChange(null, 'T', true)
      });

      expect(listComponent.filteredItems.length).toEqual(2); // Two and Three match T
    });

  });

  describe('clear', () => {
    beforeEach(() => {
      listComponent.clearSelected = jasmine.createSpy('clearSelected on list').and.callThrough();
      component.selected = [{id: '123', text: '123', selected: true}];
      component.setFilterValue('filter');
      component.clear();
    });

    it('should call clear on list component', () => {
      expect(listComponent.clearSelected).toHaveBeenCalled();
    });

    it('should clear filter', () => {
      expect(component.filter).toEqual('');
      expect(listComponent.filter).toEqual('');
    });

    it('should hide the item list', () => {
      expect(listComponent.visible).toEqual(false);
    });
  });


  describe('onFilterKeyDown', () => {

    describe('navigation keys', () => {
      beforeEach(() => {
        listComponent.filteredItems = [{}, {}];
        listComponent.handleOptionsNavigation = jasmine.createSpy('listComponentNavigation');
      });

      it('should call the navigation handler of the list component when the direction keys are pressed', () => {
        const event = keyEvent(UP);
        component.onFilterKeyDown(event);

        expect(listComponent.handleOptionsNavigation).toHaveBeenCalledWith(event);
      });

    });

    describe('Enter Pressed', () => {

      beforeEach(() => {
        listComponent.filteredItems = [{}, {}];
        listComponent.handleOptionsNavigation = jasmine.createSpy('listComponentNavigation');
        listComponent.selectHighlighted = jasmine.createSpy('selectHighlighted');
      });

      it('should emit an event if ctrl+enter is pressed', () => {
        component.onFilterKeyDown(keyEvent(ENTER, true));
        expect(component.ctrlEnterPressed.emit).toHaveBeenCalled();
      });

      it('should select item if enter is pressed', () => {
        component.onFilterKeyDown(keyEvent(ENTER));
        expect(listComponent.selectHighlighted).toHaveBeenCalled();
      });
    });

    describe('Set Visibility of list from key', () => {
      beforeEach(() => {
        listComponent.hideList = jasmine.createSpy('hidelist');
      });

      it('should hide item list with ESC/TAB/ENTER', () => {
        component.onFilterKeyDown(keyEvent(ESC));
        expect(listComponent.hideList).toHaveBeenCalled();

        component.onFilterKeyDown(keyEvent(TAB));
        expect(listComponent.hideList).toHaveBeenCalled();

        component.onFilterKeyDown(keyEvent(ENTER));
        expect(listComponent.hideList).toHaveBeenCalled();
      });

      it('should not call hide list if a key other than ESC/TAB/ENTER pressed', () => {
        component.onFilterKeyDown(keyEvent(KEY_Y));
        expect(listComponent.hideList).not.toHaveBeenCalled();
      });
    });
  });

  describe('hiding/showing input text on filter/blur', () => {
    beforeEach(() => {
      component.clearFilterOnFocus = true;
      component.searchBoxInput.patchValue('Test');
    });

    it('on blur adds filter back in', fakeAsync(() => {
      component.listComponent.selectedItems = [{id: 1, text: 'Test'}];
      component.onFilterFocused({
        target: {
          select: () => {
          }
        }
      });
      component.onFilterBlur();
      tick(200);
      tick(200); // Needed if we have another async task in the setTimeout
      expect(component.searchBoxInput.value).toEqual('Test');
      discardPeriodicTasks();
    }));
  });

  describe('server-side filtering', () => {

  });


});
