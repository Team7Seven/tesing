import {ChangeDetectorRef} from '@angular/core';
import {SearchBoxItemListComponent} from './search-box-item-list.component';

const UP = 38;
const DOWN = 40;

describe('SearchBoxItemListComponent', () => {

  let component: SearchBoxItemListComponent;

  const items = <any>[
    {id: 1, text: 'One'},
    {id: 2, text: 'Two'},
    {id: 3, text: 'Three'}
  ];

  const ITEM = {id: 123, text: 'ITEM_VALUE'};
  const ITEM2 = {id: 456, text: 'SECOND_ITEM_VALUE'};

  function keyEvent(keyCode: number, ctrlKey = false) {
    return {
      keyCode: keyCode,
      ctrlKey: ctrlKey,
      preventDefault: jasmine.createSpy('preventDefault')
    };
  }

  const changeDetectionMock = {
    detectChanges: (_: any) => {
    }
  } as ChangeDetectorRef;

  beforeEach(() => {
    component = new SearchBoxItemListComponent(changeDetectionMock);
    component.items = items;
  });

  describe('filtering', () => {
    it('should filter out all except one when "one" is supplied as the filter', () => {
      component.filter = 'One';
      component.onFilterChange();
      expect(component.filteredItems.length).toEqual(1);
    });

    it('should show all items after all items filtered out and then no filter supplied', () => {
      component.filter = 'Oneta';
      component.onFilterChange();
      expect(component.filteredItems.length).toEqual(0);

      component.filter = '';
      component.onFilterChange();
      expect(component.filteredItems.length).toEqual(3);
    });


    it('should NOT filter out all except one when "one" is supplied as the filter and serverSideFiltering is ' +
      'enabled', () => {
      component.serverSideFiltering = true;
      component.filter = 'One';
      component.onFilterChange();
      expect(component.filteredItems.length).toEqual(3);
    });
  });

  describe('hiding/showing list', () => {
    it('should set the list as visible when showList is called', () => {
      component.visible = false;
      component.showList();
      expect(component.visible).toBeTruthy();
    });

    it('should set the list as not visible by default when hideList is called', () => {
      component.visible = true;
      component.hideList();
      expect(component.visible).toBeFalsy();
    });

    it('should not hide list when debug is true', () => {
      component.visible = true;
      component.debug = true;
      component.hideList();
      expect(component.visible).toBeTruthy();
    });
  });

  describe('selecting items', () => {

    beforeEach(() => {
      component.selectedChanged.emit = jasmine.createSpy('selectedChanged event emitter');
      component.hideList = jasmine.createSpy('hideList');
    });

    describe('in non-multiple mode', () => {
      it('should set selected as an array with a single item in it', () => {
        component.selectItem(ITEM, true);
        expect(component.selectedItems).toEqual([ITEM]);
      });

      it('should not append another item to selectedItems when a second item is selected', () => {
        component.selectItem(ITEM, true);
        component.selectItem(ITEM2, true);
        expect(component.selectedItems).not.toEqual([ITEM, ITEM2]);
        expect(component.selectedItems).toEqual([ITEM2]);
      });

      it('should call hide list and emit event', () => {
        component.selectItem(ITEM, true);
        expect(component.hideList).toHaveBeenCalled();
        expect(component.selectedChanged.emit).toHaveBeenCalledWith([ITEM]);
      });
    });

    describe('in multiple mode', () => {
      beforeEach(() => {
        component.multiple = true;
        component.selectedItems = [ITEM];
      });

      it('should append second item to selectedItems when a two items are selected', () => {
        component.selectItem(ITEM2, true);
        expect(component.selectedItems).not.toEqual([ITEM2]);
        expect(component.selectedItems).toEqual([ITEM, ITEM2]);
      });

      it('should call hide list and emit event', () => {
        ITEM2['selected'] = false;
        component.selectItem(ITEM2, true);
        expect(component.hideList).toHaveBeenCalled();
        expect(component.selectedChanged.emit).toHaveBeenCalledWith([ITEM, ITEM2]);
      });

      it('should not do anything if item is already selected', () => {
        ITEM2['selected'] = true;
        component.selectItem(ITEM2, true);
        expect(component.hideList).not.toHaveBeenCalled();
        expect(component.selectedChanged.emit).not.toHaveBeenCalledWith([ITEM, ITEM2]);
      });

    });

  });

  describe('deselecting items', () => {
    beforeEach(() => {
      component.selectItem(component.items[0], true);
      component.selectItem(component.items[1], true);
    });

    it('should set items selected property as false', () => {
      component.deselect(component.items[0]);
      expect(component.items[0].selected).toBeFalsy();
    });

    it('remove the item passed in from the selected items array', () => {
      component.deselect(component.items[0]);
      expect(component.selectedItems.indexOf(component.items[0])).toEqual(-1);
    });
  });

  describe('navigation keys', () => {

    beforeEach(() => {
      component.onFilterChange();
    });

    it('should pick the last item if DOWN is pressed and we have the first item selected', () => {
      component.highlightIndex = 0;
      component.handleOptionsNavigation(keyEvent(UP));
      expect(component.highlightIndex).toEqual(2);
    });

    it('should pick the next item if DOWN is pressed', () => {
      component.highlightIndex = 0;

      component.handleOptionsNavigation(keyEvent(DOWN));

      expect(component.highlightIndex).toEqual(1);
    });

    it('should pick the last item if up is pressed and we have the first item selected', () => {
      component.highlightIndex = 2;

      component.handleOptionsNavigation(keyEvent(DOWN));

      expect(component.highlightIndex).toEqual(0);
    });

    it('should limit the maximum selectedItemId to be within the size of the list', () => {
      component.highlightIndex = 999;

      component.handleOptionsNavigation(keyEvent(UP));

      expect(component.highlightIndex).toEqual(2);
    });

  });

  describe('clearing selected items', () => {
    beforeEach(() => {
      component.selectItem(component.items[0], true);
      component.selectItem(component.items[1], true);
      component.selectItem(component.items[2], true);
      component.selectedChanged.emit = jasmine.createSpy('selectedChanged event emitter');
    });

    it('should set selected property on all items to false', () => {
      component.clearSelected();

      component.items.forEach((item) => {
        expect(item.selected).toBeFalsy();
      });
    });

    it('should set list to not visible', () => {
      component.clearSelected();

      expect(component.visible).toBeFalsy();
    });

    it('should set selected items to be an empty array and emit selection changed', () => {
      component.clearSelected();
      expect(component.selectedItems).toEqual([]);
      expect(component.selectedChanged.emit).toHaveBeenCalled();
    });
  });

});
