import {
  ApplicationRef,
  Component, ComponentFactory, ComponentFactoryResolver, ElementRef, EventEmitter, Input,
  OnChanges,
  OnDestroy,
  Output,
  SimpleChanges, ViewChild, OnInit,
} from '@angular/core';
import {SearchBoxItemListComponent} from './search-box-item-list.component';
import {SearchBoxItemModel} from './search-box-item.model';
import {Observable} from 'rxjs/Observable';
import {FormControl} from '@angular/forms';

const UP = 38;
const DOWN = 40;
const ENTER = 13;
const ESC = 27;
const TAB = 9;

@Component({
  selector: 'search-box',
  template: `
    <span *ngIf="items">
                <span class="search-box">
                  <div class="input-container" role="combobox">
                    <input
                      #filterInput
                      type="text"
                      class="form-control"
                      placeholder="{{placeholder}}"
                      name="requestId"
                      [title]="ariaLabel"
                      [(ngModel)]="filter"
                      (focus)="onFilterFocused($event)"
                      (blur)="onFilterBlur()"
                      (keydown)="onFilterKeyDown($event)"
                      [formControl]="searchBoxInput"
                      id="{{inputId}}"
                      aria-autocomplete="true"
                      autocomplete="off"
                    />
                     <span *ngIf="multiple">
                       Selected:
                      <span class="selected-item" *ngFor="let item of listComponent.selectedItems" aria-selected="true">
                        {{item.text}}
                        <i class="fa fa-times" aria-hidden (click)="remove(item)"></i>
                      </span>
                    </span>
                  </div>
                  <span *ngIf="filter && listComponent.selectedItems.length === 1" id="cancel-button" (click)="clear()"
                        class="input-group-addon"><i class="fa fa-2x fa-window-close"></i>
                  </span>
              </span>
            </span>
  `,
  styleUrls: ['./search-box.component.scss']
})
export class SearchBoxComponent implements OnChanges, OnDestroy, OnInit {
  @Input() items: Observable<Array<SearchBoxItemModel>>;
  @Input() dropUp = false;
  @Input() maxItems = 10;
  @Input() multiple = false;
  @Input() placeholder: string;
  @Input() autoSelected: any;
  @Input() inputId = 'search-box-input';
  @Input() clearSelected: EventEmitter<any>;
  @Input() clearFilterOnFocus = false;
  @Input() serverSideFiltering = false;
  @Input() set filter (value) {
    if (value === this._filter) {
      return;
    }
    if (value) {
      this._filter = value;
    } else {
      this._filter = value;
    }
    this.onFilterChange(value);
  }
  get filter () {
    return this._filter;
  }


  @Output() selectedChanged = new EventEmitter<Array<any>>();
  @Output() ctrlEnterPressed = new EventEmitter();
  @Output() filterFocused = new EventEmitter();
  @Output() filterChanged = new EventEmitter<string>();

  _filter = '';
  filterIsFocused = false;
  listComponent: SearchBoxItemListComponent;
  componentRef;
  selected: Array<SearchBoxItemModel> = [];
  label: string;
  searchBoxInput: FormControl;

  @ViewChild('filterInput') filterInput;

  public ariaLabel = '';

  constructor(private factoryResolver: ComponentFactoryResolver, private applicationRef: ApplicationRef) {

    this.searchBoxInput = new FormControl();

    this.searchBoxInput.valueChanges
      .debounceTime(600)
      .subscribe((value) => {
        this.onFilterChange(value);
      });

    const listComponent: ComponentFactory<SearchBoxItemListComponent> =
      this.factoryResolver.resolveComponentFactory(SearchBoxItemListComponent);

    const appInstance = this.applicationRef.components[0].instance;

    if (!appInstance.viewContainerRef) {
      const appName = this.applicationRef.componentTypes[0].name;
      throw new Error(`Missing 'viewContainerRef' declaration in ${appName} constructor`);
    }


    this.componentRef = appInstance.viewContainerRef.createComponent(listComponent);

    this.listComponent = this.componentRef.instance;
  }

  ngOnInit() {
    this.listComponent.selectedChanged.subscribe((items) => {
      if (!this.multiple && items[0]) {
        this.setFilterValue(items[0].text, false);
      }
      this.listComponent.selectedItems = items;
      this.selectedChanged.emit(items);
    });

    this.ariaLabel = this.getAriaLabel();
    this.items.subscribe((items) => {
      this.listComponent.items = items;
      this.listComponent.onFilterChange();
      if (this.autoSelected) {
        this.preselectOptions(this.autoSelected);
      } else if (this.selected.length) {
        this.clear(true);
      }
    });
  }

  ngOnChanges(changes: SimpleChanges) {
    this.updateListComponentProperties();

    if ('items' in changes) {
      this.listComponent.onFilterChange();
      this.preselectOptions(this.autoSelected);
    }
    if ('filter' in changes && !changes['filter'].firstChange) {
      this.setFilterValue(this.filter, false);
    }

    if ('autoSelected' in changes && !changes['autoSelected'].firstChange) {
      this.preselectOptions(this.autoSelected);
    }

    if (this.clearSelected) {
      this.clearSelected.subscribe((event) => {
        this.clear();
      });
    }
    this.updateListComponentProperties();
  }

  preselectOptions(selected: any) {
    this.listComponent.clearSelected(false);
    if (selected instanceof Array) {
      selected.forEach((item) => {
        this.selectItem(item, false);
      });
    } else {
      this.selectItem(selected, false);
    }
  }

  selectItem(item: SearchBoxItemModel, emitEvent = true) {
    if (item) {
      let listItem = this.findItemInItemList(item);
      if (!listItem) {
        // trust item is valid even if not found in list
        listItem = item;
      }

      this.listComponent.selectItem(listItem, emitEvent);

      if (!this.multiple) {
        this.setFilterValue(item.text, true);
      }
    } else if (item === null) {
      this.clear(emitEvent);
    }
  }

  setFilterValue(text: string, doFilter = true) {
    if (!text) {
      text = '';
      this.filter = '';
    }
    if (this.filter === text) {
      return;
    }
    this.filter = text;
    if (!this.serverSideFiltering && doFilter) {
      this.searchBoxInput.patchValue(text, {emitEvent: false});
      this.onFilterChange(text);
    } else {
      this.searchBoxInput.patchValue(text, {emitEvent: doFilter});
    }
    this.componentRef.changeDetectorRef.detectChanges();
  }

  findItemInItemList(item) {
    let foundItem, listItem, i = 0;
    while (i < this.listComponent.items.length && !foundItem) {
      listItem = this.listComponent.items[i];
      if (!foundItem && listItem.id.toString() === item.id.toString()) {
        foundItem = listItem;
      }
      i++;
    }
    return foundItem;
  }

  updateListLayoutWhenInputRendered(): void {
    let checkForElementInterval;

    // need to repeatedly check for this as the input element may not yet be rendered
    checkForElementInterval = setInterval(() => {
      if (this.filterInput && this.filterInput.nativeElement) {
        const element = this.filterInput.nativeElement;

        this.listComponent.setListWidth(element.clientWidth);

        const inputHeight = element.clientHeight;
        const xPosition = element.getBoundingClientRect().left;
        const yPosition = element.getBoundingClientRect().top;

        this.listComponent.setListPosition(yPosition, xPosition, inputHeight);

        clearInterval(checkForElementInterval);
      }
    }, 500);
  }

  onFilterFocused(event) {
    this.updateListLayoutWhenInputRendered();
    event.target.select();
    this.filterIsFocused = true;
    this.listComponent.inFocus = false;
    this.listComponent.showList();
    this.filterFocused.emit();
    if (this.clearFilterOnFocus) {
      this.setFilterValue('', true);
    }
  }

  onFilterBlur() {
    this.filterIsFocused = false;
    if (this.listComponent.selectedItems && this.listComponent.selectedItems.length && !this.multiple) {
      this.setFilterValue(this.listComponent.selectedItems[0].text, false);
    } else {
      this.setFilterValue('', true);
      if (this.listComponent.selectedItems.length === 0) {
        this.selectedChanged.emit(null);
      }
    }
    this.hideSelectIfItemListAndFilterNotFocused();
  }

  private hideSelectIfItemListAndFilterNotFocused() {
    setTimeout(() => {
      if (!this.listComponent.inFocus && !this.filterIsFocused) {
        this.listComponent.hideList();
      }
    }, 200);
  }

  public onFilterChange(value) {
    this.filterChanged.emit(value);
    this.filter = value;
    this.listComponent.filter = value;
    this.listComponent.onFilterChange();
  }

  clear(emitEvent = true) {
    this.listComponent.clearSelected(emitEvent);
    this.setFilterValue('', true);
  }


  private updateListComponentProperties() {
    this.listComponent.serverSideFiltering = this.serverSideFiltering;
    this.listComponent.multiple = this.multiple;
    this.listComponent.dropUp = this.dropUp;
    this.listComponent.maxItems = this.maxItems;
    this.listComponent.onFilterChange();
    this.componentRef.changeDetectorRef.detectChanges();
  }

  private setListVisibilityFromKeyEvent(event) {
    if (this.isKeyOneOf(event, [ESC, TAB, ENTER])) {
      this.listComponent.hideList();
    }
  }

  private isKeyNavigation(event) {
    return (event.keyCode === UP || event.keyCode === DOWN);
  }

  private isKeyOptionSelection(event) {
    return (event.keyCode === ENTER);
  }

  private isKeyOneOf(event, list: Array<number>) {
    return list.indexOf(event.keyCode) !== -1;
  }


  onFilterKeyDown(event) {
    if (this.isKeyNavigation(event)) {
      this.listComponent.handleOptionsNavigation(event);
    }

    if (this.isKeyOptionSelection(event) && this.listComponent.filteredItems.length > 0) {
      this.onEnterPressed(event);
    }

    this.setListVisibilityFromKeyEvent(event);
  }

  private onEnterPressed(event) {
    this.listComponent.selectHighlighted();
    if (event.ctrlKey) { // CTRL + ENTER to submit
      this.ctrlEnterPressed.emit();
    }
    event.preventDefault();
  }

  remove(item) {
    this.listComponent.deselect(item);
  }

  ngOnDestroy() {
    this.componentRef.destroy();
  }

  getAriaLabel(): string {
    if (this.label) {
      return this.label;
    }

    if (this.placeholder) {
      return this.placeholder;
    }

    return '';

  }
}
