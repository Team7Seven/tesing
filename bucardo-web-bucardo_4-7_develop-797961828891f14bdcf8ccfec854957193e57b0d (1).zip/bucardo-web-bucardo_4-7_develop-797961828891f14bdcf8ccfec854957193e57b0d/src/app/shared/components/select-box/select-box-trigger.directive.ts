import {
  ApplicationRef, ChangeDetectionStrategy,
  ChangeDetectorRef, ComponentFactory, ComponentFactoryResolver, ComponentRef, Directive, ElementRef, EmbeddedViewRef,
  forwardRef,
  Inject, Injector,
  Input,
  NgZone,
  OnDestroy, OnInit, Optional,
  ViewContainerRef
} from '@angular/core';
import {SelectBoxComponent} from './select-box.component';
import {DOCUMENT} from '@angular/common';
import {ControlValueAccessor, NG_VALUE_ACCESSOR} from '@angular/forms';
import {Subscription} from 'rxjs/Subscription';
import {DOWN_ARROW, ENTER, ESCAPE, UP_ARROW, TAB} from '@angular/cdk/keycodes';
import {Observable} from 'rxjs/Rx';
import {Subject} from 'rxjs/Subject';
import {merge} from 'rxjs/operator/merge';
import {DomPortalHost, TemplatePortal} from '@angular/cdk/portal';
import {first} from 'rxjs/operator/first';
import {map} from 'rxjs/operator/map';
import {isNullOrUndefined} from 'util';


@Directive({
  selector: 'input[SelectBox]',
  host: {
    'role': 'combobox',
    'autocomplete': 'off',
    'aria-autocomplete': 'list',
    '[attr.aria-activedescendant]': 'activeOption?.id',
    '[attr.aria-expanded]': 'listOpen.toString()',
    '[attr.aria-owns]': 'autocomplete?.id',
    // Note: we use `focusin`, as opposed to `focus`, in order to open the panel
    // a little earlier. This avoids issues where IE delays the focusing of the input.
    '(focusin)': '_handleFocus()',
    '(blur)': '_handleBlur()',
    '(input)': '_handleInput($event)',
    '(keydown)': '_handleInput($event)',
    '(keyup)': '_updateValue($event)'
  },
  providers: [
    {provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => SelectBoxTriggerDirective), multi: true},
  ]
})
export class SelectBoxTriggerDirective implements OnDestroy, ControlValueAccessor, OnInit {

  tabPressed: Subject<KeyboardEvent> = new Subject();
  closingActionSubscription: Subscription;
  scrollEventSubscription: Subscription;
  // private _positionStrategy: ConnectedPositionStrategy;
  //
  templatePortal: TemplatePortal<any>;
  portalHost: DomPortalHost;
  listOpen = false;
  _value: any;

  @Input('SelectBox') selectionList: SelectBoxComponent;
  selectionListRef: EmbeddedViewRef<SelectBoxComponent>;

  _onChange: (value: any) => void = () => {
  }
  _onTouched = () => {
  }


  constructor(private factoryResolver: ComponentFactoryResolver,
              private applicationRef: ApplicationRef,
              private _element: ElementRef,
              private _viewContainerRef: ViewContainerRef,
              private injector: Injector,
              private _zone: NgZone,
              private _changeDetectorRef: ChangeDetectorRef,
              @Optional() @Inject(DOCUMENT) private _document: any) {
  }

  ngOnDestroy() {
    this.destroyList();
  }

  ngOnInit() {
    if (!this.portalHost) {
      this.portalHost = new DomPortalHost(
        document.body,
        this.factoryResolver,
        this.applicationRef,
        this.injector);
    }
  }

  destroyList() {
    if (this.selectionListRef) {
      this.closeList();
      this.selectionListRef.destroy();
      this.selectionListRef = null;
    }
  }

  _handleFocus() {
    this._openList();
  }

  _handleBlur() {
    if (!this.selectionList.multiple && this._element.nativeElement.value === '') {
      this.selectionList.clearSelected();
    }
    this.selectIfValueMatches();
    this._onTouched();
  }

  private selectIfValueMatches() {
    if (!this.selectionList.multiple) {
      this.selectionList.options.forEach((option) => {
        let optionTriggerValue = option.value;
        if (this.selectionList.triggerDisplayMap) {
          optionTriggerValue = this.selectionList.triggerDisplayMap(option.value);
        }
        if (optionTriggerValue === this._element.nativeElement.value) {
          option.selectOption();
        }
      });
      if (this.selectionList.options.length === 0 && this._element.nativeElement.value) {
        this.selectionList.value = null;
        this.setTriggerValue('');
        this._changeDetectorRef.detectChanges();
      }
    }
  }

  _openList() {
    this.attachList();
    this.listOpen = true;
    this.selectionList.visible = true;
  }


  private attachList() {

    if (!this.selectionListRef) {
      this.templatePortal = new TemplatePortal(this.selectionList.template, this._viewContainerRef);
      this.selectionListRef = this.portalHost.attachTemplatePortal(this.templatePortal);
    }

    if (this.templatePortal && !this.portalHost.hasAttached()) {
      this.selectionListRef = this.portalHost.attach(this.templatePortal);
      this.closingActionSubscription = this.subscribeToClosing();
      this.scrollEventSubscription = this.subscribeToScrollEvent();
    }

    this.selectionList.updateLayout(this._element);
    this.selectionList.visible = this.listOpen = true;
  }

  setTriggerValue(value) {
    if (value === undefined) {
      value = '';
    }
    this._element.nativeElement.value = value;
    this.value = value;
    this._onChange(value);
  }

  writeValue(value: any): void {
    Promise.resolve(null).then(() => this.setTriggerValue(value));
  }

  registerOnChange(fn: any): void {
    this._onChange = fn;
  }

  registerOnTouched(fn: any): void {
    this._onTouched = fn;
  }

  set value(obj) {
    if (!obj) {
      this._value = obj;
    }
  }

  get value() {
    return this._value;
  }

  subscribeToClosing(): Subscription {
    const zoneStable = first.call(this._zone.onStable.asObservable());

    return merge.call(zoneStable, this.selectionList.options.changes)
      .switchMap(() => {
        this._changeDetectorRef.markForCheck();
        return this.panelClosingActions;
      })
      .subscribe((event) => {
        if (!isNullOrUndefined(event.value)) {
          let displayValue = event.value;
          if (this.selectionList.triggerDisplayMap) {
            displayValue = this.selectionList.triggerDisplayMap(event.value);
          }
          this.setTriggerValue(displayValue);
          this.selectionList.emitSelected();
        }
        this.closeList();
      });
  }

  get panelClosingActions() {
    return merge.call(this.optionSelections, this.tabPressed.asObservable(), this.clickOutside);
  }

  get optionSelections() {
    let merged: Observable<any>[] = [];
    merged = this.selectionList.options.map(option => option.onSelectionChange);
    return Observable.merge(...merged);
  }

  _handleInput($event) {
    if ($event.keyCode === TAB) {
      this.tabPressed.next($event);
    }

    if ($event.keyCode === UP_ARROW || $event.keyCode === DOWN_ARROW) {
      if (!this.listOpen) {
        this._openList();
      }
      this.selectionList.handleKeyNavigation($event.keyCode);
    }

    if ($event.keyCode === ENTER && this.listOpen) {
      this.selectionList.selectActiveOption();
    }
  }

  closeList() {
    if (this.templatePortal && this.templatePortal.isAttached) {
      this.portalHost.detach();
      this.selectionListRef.destroy();
      this.closingActionSubscription.unsubscribe();
      this.scrollEventSubscription.unsubscribe();
      this.selectionList.resetActive();
    }

    if (this.listOpen) {
      this.selectionList.visible = this.listOpen = false;
      this._changeDetectorRef.detectChanges();
    }
  }

  get clickOutside() {
    if (!this._document) {
      return Observable.of(null);
    }

    return Observable.merge(
      Observable.fromEvent(this._document, 'click'),
      Observable.fromEvent(this._document, 'touchend')
    ).filter((event: MouseEvent | TouchEvent) => {
      const clickTarget = event.target as HTMLElement;
      return this.listOpen &&
        clickTarget !== this._element.nativeElement &&
        (!!this.selectionListRef && !this.selectionListRefElement.contains(clickTarget));
    });
  }

  get selectionListRefElement(): Node {
    let selectionElement;
    this.selectionListRef.rootNodes.forEach((item: Node) => {
      if (item.nodeType === Node.ELEMENT_NODE) {
        selectionElement = item;
      }
    });
    return selectionElement;
  }

  subscribeToScrollEvent(): Subscription {
    const scrollObservables: Observable<any>[] = [];
    let el = this._element.nativeElement;
    while (!isNullOrUndefined(el)) {
      scrollObservables.push(Observable.fromEvent(el, 'scroll'));
      el = el.parentElement;
    }
    return Observable.merge(...scrollObservables).subscribe((scroll) => {
      this.selectionList.updateLayout(this._element);
    });
  }

  private _updateValue(event) {
    this._onChange(this._element.nativeElement.value);
  }

}
