import {CUSTOM_ELEMENTS_SCHEMA, NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {SelectBoxComponent} from './select-box.component';
import {SelectBoxTriggerDirective} from './select-box-trigger.directive';
import {SelectBoxOptionComponent} from './select-box-option/select-box-option.component';

@NgModule({
  imports: [CommonModule],
  declarations: [
    SelectBoxComponent,
    SelectBoxTriggerDirective,
    SelectBoxOptionComponent
  ],
  exports: [
    SelectBoxComponent,
    SelectBoxTriggerDirective,
    SelectBoxOptionComponent
  ]
})
export class SelectBoxModule {
}
