import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {SelectBoxComponent} from './select-box.component';
import {Component, OnInit, ViewChild} from '@angular/core';
import {FormControl, FormsModule, ReactiveFormsModule} from '@angular/forms';
import {SelectBoxModule} from './select-box.module';
import {By} from '@angular/platform-browser';
import {SelectBoxTriggerDirective} from './select-box-trigger.directive';
import {SelectBoxOptionComponent} from './select-box-option/select-box-option.component';
import {DOWN_ARROW, UP_ARROW, TAB, ENTER} from '@angular/cdk/keycodes';


export function dispatchFakeEvent(node: Node, type: string) {
  const event = document.createEvent('Event');
  event.initEvent(type, true, true);
  node.dispatchEvent(event);
}

export function dispatchFakeKeyEvent(type: string, keyCode: number, node: Node) {
  const event = document.createEvent('KeyboardEvent') as any;

  const initEventFn = (event.initKeyEvent || event.initKeyboardEvent).bind(event);

  initEventFn(type, true, true, window, 0, 0, 0, 0, 0, keyCode);

  Object.defineProperties(event, {
    keyCode: {get: () => keyCode}
  });

  node.dispatchEvent(event);
}

describe('SelectBoxComponent', () => {

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [SelectBoxModule, FormsModule, ReactiveFormsModule],
      declarations: [MultipleSelectBoxInputComponent,
        MultipleSelectBoxInputWithMapsComponent,
        SingleSelectBoxInputWithMapsComponent]
    })
      .compileComponents();
  }));

  describe('list toggle', () => {
    let fixture: ComponentFixture<MultipleSelectBoxInputComponent>;
    let input: HTMLInputElement;

    beforeEach(() => {
      fixture = TestBed.createComponent(MultipleSelectBoxInputComponent);
      fixture.detectChanges();

      input = fixture.debugElement.query(By.css('input')).nativeElement;
    });

    it('should open list when focus on input', () => {
      expect(fixture.componentInstance.trigger.listOpen).toBeFalsy();

      dispatchFakeEvent(input, 'focusin');

      fixture.whenStable().then(() => {
        fixture.detectChanges();
        expect(fixture.componentInstance.trigger.listOpen).toBeTruthy();
      });
    });

    it('should close list when blur on input', () => {
      expect(fixture.componentInstance.trigger.listOpen).toBeFalsy();

      dispatchFakeEvent(input, 'focusin');

      fixture.whenStable().then(() => {
        fixture.detectChanges();
        expect(fixture.componentInstance.trigger.listOpen).toBeTruthy();

        dispatchFakeEvent(document, 'click');

        fixture.whenStable().then(() => {
          fixture.detectChanges();
          expect(fixture.componentInstance.trigger.listOpen).toBeFalsy();
        });
      });
    });
  });

  describe('selecting/deselecting list item', () => {
    let fixture: ComponentFixture<MultipleSelectBoxInputComponent>;
    let input: HTMLInputElement;

    beforeEach(() => {
      fixture = TestBed.createComponent(MultipleSelectBoxInputComponent);
      fixture.detectChanges();

      input = fixture.debugElement.query(By.css('input')).nativeElement;
    });

    it('selects the first item when it has been preselected', () => {
      expect(fixture.componentInstance.trigger.selectionList.options.first.selected).toBeFalsy();

      fixture.componentInstance.trigger.selectionList._value = [fixture.componentInstance.values[0]];

      fixture.whenStable().then(() => {
        expect(fixture.componentInstance.trigger.selectionList.options.first.selected).toBeTruthy();
      });
    });

    it('selects the first item and maps the value correctly', () => {
      expect(fixture.componentInstance.trigger.selectionList.options.first.selected).toBeFalsy();

      fixture.componentInstance.trigger.selectionList._value = [fixture.componentInstance.values[0]];

      fixture.whenStable().then(() => {
        expect(fixture.componentInstance.trigger.selectionList.options.first.selected).toBeTruthy();
      });
    });

    it('deselects the first item after selection when it has been preselected', () => {
      expect(fixture.componentInstance.trigger.selectionList.options.first.selected).toBeFalsy();

      fixture.componentInstance.trigger.selectionList._value = [fixture.componentInstance.values[0]];
      dispatchFakeEvent(input, 'focusin');

      fixture.whenStable().then(() => {
        const option: SelectBoxOptionComponent = fixture.componentInstance.trigger.selectionList.options.first;
        option.handleSelection();
        fixture.whenStable().then(() => {
          expect(fixture.componentInstance.trigger.selectionList.options.first.selected).toBeFalsy();

        });
      });
    });
  });

  describe('trigger keyboard events', () => {
    let fixture: ComponentFixture<MultipleSelectBoxInputComponent>;
    let input: HTMLInputElement;

    beforeEach(() => {
      fixture = TestBed.createComponent(MultipleSelectBoxInputComponent);
      fixture.detectChanges();

      input = fixture.debugElement.query(By.css('input')).nativeElement;
      dispatchFakeEvent(input, 'focusin');
    });

    it('list closes when tab is pressed', () => {
      fixture.whenStable().then(() => {
        expect(fixture.componentInstance.trigger.listOpen).toBe(true);
        dispatchFakeKeyEvent('keydown', TAB, input);
        fixture.whenStable().then(() => {
          expect(fixture.componentInstance.trigger.listOpen).toBe(false);
        });
      });
    });

    it('increments the active item index and corresponding item is set as active when up arrow is pressed',
      () => {
        expect(fixture.componentInstance.trigger.selectionList.options.first.active).toBe(false);
        expect(fixture.componentInstance.trigger.selectionList.activeIndex).toEqual(-1);
        dispatchFakeKeyEvent('keydown', DOWN_ARROW, input);
        expect(fixture.componentInstance.trigger.selectionList.activeIndex).toEqual(0);
        expect(fixture.componentInstance.trigger.selectionList.options.first.active).toBe(true);
        dispatchFakeKeyEvent('keydown', DOWN_ARROW, input);
        expect(fixture.componentInstance.trigger.selectionList.activeIndex).toEqual(1);
        expect(fixture.componentInstance.trigger.selectionList.options.first.active).toBe(false);
      });

    it('decrements the active item index and corresponding item is set as active when up arrow is pressed',
      () => {
        const listLength = fixture.componentInstance.trigger.selectionList.options.length;
        fixture.componentInstance.trigger.selectionList.activeIndex = listLength - 1;
        dispatchFakeKeyEvent('keydown', UP_ARROW, input);
        expect(fixture.componentInstance.trigger.selectionList.activeIndex).toEqual(listLength - 2);

        fixture.componentInstance.trigger.selectionList.options.forEach((option, index) => {
          expect(option.active).toBe(index === (listLength - 2));
        });
      });

    it('does not allow activeIndex to go below -1',
      () => {
        expect(fixture.componentInstance.trigger.selectionList.activeIndex).toEqual(-1);
        dispatchFakeKeyEvent('keydown', UP_ARROW, input);
        expect(fixture.componentInstance.trigger.selectionList.activeIndex)
          .toEqual(fixture.componentInstance.trigger.selectionList.options.length - 1);
      });

    it('does not allow activeIndex to go above the total number of options',
      () => {
        const maxIndex = fixture.componentInstance.trigger.selectionList.options.length - 1;
        fixture.componentInstance.trigger.selectionList.activeIndex = maxIndex;
        dispatchFakeKeyEvent('keydown', DOWN_ARROW, input);
        expect(fixture.componentInstance.trigger.selectionList.activeIndex).toEqual(0);
      });

    it('inverts the activeIndex on keypress when the list is dropping up', () => {
      fixture.componentInstance.trigger.selectionList.dropUp = true;
      dispatchFakeKeyEvent('keydown', UP_ARROW, input);
      expect(fixture.componentInstance.trigger.selectionList.options.last.active).toBe(true);
    });

    it('selects the active item when the enter key is pressed', () => {
      fixture.componentInstance.trigger.selectionList.dropUp = true;
      dispatchFakeKeyEvent('keydown', UP_ARROW, input);
      dispatchFakeKeyEvent('keydown', ENTER, input);
      fixture.whenStable().then(() => {
        expect(fixture.componentInstance.trigger.selectionList.options.last.selected).toBe(true);
        expect(fixture.componentInstance.trigger.selectionList.options.last.active).toBe(false);
      });
    });

    it('resets the active index when an item is selected', () => {
      fixture.componentInstance.trigger.selectionList.dropUp = true;
      dispatchFakeKeyEvent('keydown', UP_ARROW, input);
      dispatchFakeKeyEvent('keydown', ENTER, input);
      expect(fixture.componentInstance.trigger.selectionList.options.last.active).toBe(false);
      expect(fixture.componentInstance.trigger.selectionList.activeIndex).toEqual(-1);
    });
  });
  describe('option value mapping', () => {
    let fixture: ComponentFixture<MultipleSelectBoxInputWithMapsComponent>;
    let input: HTMLInputElement;

    beforeEach(() => {
      fixture = TestBed.createComponent(MultipleSelectBoxInputWithMapsComponent);
      fixture.detectChanges();

      input = fixture.debugElement.query(By.css('input')).nativeElement;
      dispatchFakeEvent(input, 'focusin');
    });

    it('maps the model value correctly when an option is selected', () => {
      fixture.whenStable().then(() => {
        fixture.componentInstance.trigger.selectionList.options.first.selectOption();
        expect(fixture.componentInstance.trigger.selectionList._value).toEqual(['Charles Chaplin']);
      });
    });

    it('maps the trigger value correctly when an option is selected', () => {
      fixture.whenStable().then(() => {
        fixture.componentInstance.trigger.selectionList.options.first.selectOption();
        expect(input.value).toEqual('1');
      });
    });
  });

  describe('multi-select mode', () => {
    let fixture: ComponentFixture<MultipleSelectBoxInputWithMapsComponent>;
    let input: HTMLInputElement;

    beforeEach(() => {
      fixture = TestBed.createComponent(MultipleSelectBoxInputWithMapsComponent);
      fixture.detectChanges();

      input = fixture.debugElement.query(By.css('input')).nativeElement;
      dispatchFakeEvent(input, 'focusin');
    });

    it('adds both items to the value array', () => {
      fixture.whenStable().then(() => {
        fixture.componentInstance.trigger.selectionList.options.first.selectOption();
        fixture.componentInstance.trigger.selectionList.options.last.selectOption();
        expect(fixture.componentInstance.trigger.selectionList._value).toEqual(['Charles Chaplin', 'Robert De Niro']);
      });
    });

    it('deselects item when selectOption called on it for second time', () => {
      fixture.whenStable().then(() => {
        fixture.componentInstance.trigger.selectionList.options.first.selectOption();
        fixture.componentInstance.trigger.selectionList.options.last.selectOption();
        fixture.componentInstance.trigger.selectionList.options.first.deselectOption();
        expect(fixture.componentInstance.trigger.selectionList._value).toEqual(['Robert De Niro']);
        expect(fixture.componentInstance.trigger.selectionList.options.first.selected).toBe(false);
      });
    });
  });

  describe('single select mode', () => {
    let fixture: ComponentFixture<MultipleSelectBoxInputWithMapsComponent>;
    let input: HTMLInputElement;

    beforeEach(() => {
      fixture = TestBed.createComponent(SingleSelectBoxInputWithMapsComponent);
      fixture.detectChanges();

      input = fixture.debugElement.query(By.css('input')).nativeElement;
      dispatchFakeEvent(input, 'focusin');
    });

    it('only adds the second option selected to the value, value is not array', () => {
      fixture.whenStable().then(() => {
        fixture.componentInstance.trigger.selectionList.options.first.selectOption();
        fixture.componentInstance.trigger.selectionList.options.last.selectOption();
        expect(fixture.componentInstance.trigger.selectionList._value).toEqual('Robert De Niro');
      });
    });
  });
});


@Component({
  template: `<input type="text" [SelectBox]="select" [formControl]="filterControl">
  <select-box #select="SelectBox" (selectionChanged)="optionSelected($event)" [(ngModel)]="selected" [multiple]="true">
    <select-box-option *ngFor="let option of options" [value]="option">
      {{option.name}}
    </select-box-option>
  </select-box>`,
})
export class MultipleSelectBoxInputComponent implements OnInit {

  selected: any = '';
  options: any;
  filterControl: FormControl = new FormControl();
  @ViewChild(SelectBoxTriggerDirective) trigger: SelectBoxTriggerDirective;
  @ViewChild(SelectBoxComponent) select: SelectBoxComponent;

  values = [
    {name: 'Charles Chaplin', id: 1},
    {name: 'Marlon Brandon', id: 2},
    {name: 'Jack Nicholson', id: 3},
    {name: 'Daniel Day-Lewis', id: 4},
    {name: 'Meryl Streep', id: 5},
    {name: 'Tom Hanks', id: 6},
    {name: 'Robert De Niro', id: 7},
  ];

  constructor() {

  }

  ngOnInit() {
    this.options = this.values;
    this.filterControl.valueChanges
      .distinctUntilChanged()
      .startWith('')
      .subscribe((val: string) => {
        if (!val) {
          val = '';
        }
        this.performFilter(val);
      });
  }

  change(event) {
  }

  optionSelected(event) {
  }


  performFilter(val: string) {
    this.options = this.values.filter((option) => {
      if (!val) {
        val = '';
      }
      return option.name.toLowerCase().indexOf(val.toLowerCase()) + 1;
    });
  }

}


@Component({
  template: `<input type="text" [SelectBox]="select">
  <select-box #select="SelectBox" (selectionChanged)="optionSelected($event)" [(ngModel)]="selected" [multiple]="true"
              [triggerDisplayMap]="triggerMapper" [modelValueMap]="valueMapper">
    <select-box-option *ngFor="let option of options" [value]="option">
      {{option.name}}
    </select-box-option>
  </select-box>`,
})
export class MultipleSelectBoxInputWithMapsComponent implements OnInit {

  selected: any = '';
  options: any;
  @ViewChild(SelectBoxTriggerDirective) trigger: SelectBoxTriggerDirective;
  @ViewChild(SelectBoxComponent) select: SelectBoxComponent;

  values = [
    {name: 'Charles Chaplin', id: 1},
    {name: 'Marlon Brandon', id: 2},
    {name: 'Jack Nicholson', id: 3},
    {name: 'Daniel Day-Lewis', id: 4},
    {name: 'Meryl Streep', id: 5},
    {name: 'Tom Hanks', id: 6},
    {name: 'Robert De Niro', id: 7},
  ];

  constructor() {

  }

  valueMapper(option) {
    return option.name;
  }

  triggerMapper(option) {
    return option.id;
  }

  ngOnInit() {
    this.options = this.values;
  }

  change(event) {
  }

  optionSelected(event) {
  }
}


@Component({
  template: `<input type="text" [SelectBox]="select">
  <select-box #select="SelectBox" (selectionChanged)="optionSelected($event)" [(ngModel)]="selected" [multiple]="false"
              [triggerDisplayMap]="triggerMapper" [modelValueMap]="valueMapper">
    <select-box-option *ngFor="let option of options" [value]="option">
      {{option.name}}
    </select-box-option>
  </select-box>`,
})
export class SingleSelectBoxInputWithMapsComponent implements OnInit {

  selected: any = '';
  options: any;
  @ViewChild(SelectBoxTriggerDirective) trigger: SelectBoxTriggerDirective;
  @ViewChild(SelectBoxComponent) select: SelectBoxComponent;

  values = [
    {name: 'Charles Chaplin', id: 1},
    {name: 'Marlon Brandon', id: 2},
    {name: 'Jack Nicholson', id: 3},
    {name: 'Daniel Day-Lewis', id: 4},
    {name: 'Meryl Streep', id: 5},
    {name: 'Tom Hanks', id: 6},
    {name: 'Robert De Niro', id: 7},
  ];

  constructor() {

  }

  valueMapper(option) {
    return option.name;
  }

  triggerMapper(option) {
    return option.id;
  }

  ngOnInit() {
    this.options = this.values;
  }

  change(event) {
  }

  optionSelected(event) {
  }
}
