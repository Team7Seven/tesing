import {ChangeDetectorRef, Component, ElementRef, EventEmitter, Input, OnInit, Output} from '@angular/core';

@Component({
  selector: 'select-box-option',
  host: {
    'role': 'option',
    '[class.selected]': 'selected',
    '[class.option-multiple]': 'multiple',
    '[class.active]': 'active',
    '[attr.aria-selected]': 'selected.toString()',
    '(click)': 'handleSelection()',
    'class': 'select-box-option',
  },
  templateUrl: './select-box-option.component.html',
  styleUrls: ['./select-box-option.component.css']
})
export class SelectBoxOptionComponent implements OnInit {

  selected = false;
  multiple = false;
  active = false;

  @Input() value: any;
  @Output() onSelectionChange = new EventEmitter<SelectBoxOptionComponent>();

  constructor(private element: ElementRef,
              private changeDetectorRef: ChangeDetectorRef) {
  }

  ngOnInit() {
  }

  selectOption() {
    this.selected = true;
    this.changeDetectorRef.markForCheck();
    this.onSelectionChange.emit(this);
  }

  deselectOption() {
    this.selected = false;
    this.changeDetectorRef.markForCheck();
    this.onSelectionChange.emit(this);
  }

  handleSelection() {
    if (this.selected) {
      this.deselectOption();
    } else {
      this.selectOption();
    }
  }


}
