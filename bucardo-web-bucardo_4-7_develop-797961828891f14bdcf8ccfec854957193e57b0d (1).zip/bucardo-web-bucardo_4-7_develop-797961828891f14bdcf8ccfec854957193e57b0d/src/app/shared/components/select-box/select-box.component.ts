import {
  AfterContentInit, ChangeDetectionStrategy,
  Component, ContentChildren, ElementRef, EventEmitter, forwardRef, Input, NgZone, OnDestroy, OnInit, Output, QueryList,
  TemplateRef,
  ViewChild, ViewEncapsulation
} from '@angular/core';
import {SelectBoxOptionComponent} from './select-box-option/select-box-option.component';
import {ControlValueAccessor, NG_VALUE_ACCESSOR} from '@angular/forms';
import {Observable} from 'rxjs/Observable';
import {first} from 'rxjs/operator/first';
import {merge} from 'rxjs/operator/merge';
import {Subscription} from 'rxjs/Subscription';
import {Subject} from 'rxjs/Subject';
import {DOWN_ARROW, ENTER, UP_ARROW} from '@angular/cdk/keycodes';

@Component({
  selector: 'select-box',
  templateUrl: './select-box.component.html',
  styleUrls: ['./select-box.component.css'],
  exportAs: 'SelectBox',
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [
    {provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => SelectBoxComponent), multi: true},
  ]
})
export class SelectBoxComponent implements OnInit, AfterContentInit, OnDestroy, ControlValueAccessor {

  visible = false;
  @ViewChild(TemplateRef) template: TemplateRef<any>;
  @ViewChild('list') list: ElementRef;
  @ContentChildren(SelectBoxOptionComponent, {descendants: true}) options: QueryList<SelectBoxOptionComponent>;
  @Output() selectionChanged: EventEmitter<any> = new EventEmitter();
  @Input() multiple = false;
  @Input() modelValueMap: ((value: any) => any) | null;
  @Input() triggerDisplayMap: ((value: any) => any) | null;

  _value: any;
  selectedChangedSubscription: Subscription;
  style: any = {};
  activeIndex = -1;
  activeItem: SelectBoxOptionComponent;
  dropUp = false;


  _onChange: (value: any) => void = () => {
  }
  _onTouched = () => {
  }

  constructor(private _zone: NgZone) {
  }

  ngOnInit() {
    if (!this.modelValueMap) {
      this.modelValueMap = option => option;
    }
    if (!this.triggerDisplayMap) {
      this.triggerDisplayMap = option => option;
    }
  }

  ngAfterContentInit() {
    this.selectedChangedSubscription = this.selectionSubscription;
  }

  ngOnDestroy() {
    this.selectedChangedSubscription.unsubscribe();
  }

  get selectionSubscription(): Subscription {
    const zoneStable = first.call(this._zone.onStable.asObservable());
    return merge.call(zoneStable, this.options.changes).switchMap(() => {
      this.updateOptionsSelectedProperty();
      return Observable.merge(...this.options.map(option => option.onSelectionChange));
    }).subscribe((option: SelectBoxOptionComponent) => {
      if (option.selected) {
        this.addToSelected(option);
      } else {
        this.removeFromSelected(option);
      }
      this.resetActive();
    });
  }

  emitSelected() {
    const selectedOptions = this.options.filter(option => option.selected).map(option => option.value);
    this.selectionChanged.emit(selectedOptions);
  }

  private addToSelected(option: SelectBoxOptionComponent) {
    const mappedValue = this.modelValueMap(option.value);

    if (!this.multiple) {
      this.options.forEach((op) => {
        op.selected = false;
      });
      this.value = mappedValue;
    } else {
      if (!(this._value instanceof Array)) {
        this._value = [];
      }
      this.value.push(mappedValue);
      this._onChange(this._value);
    }

    option.selected = true;
  }

  private removeFromSelected(option: SelectBoxOptionComponent) {
    option.selected = false;
    if (!this.multiple) {
      this.value = '';
    } else {
      const optionSelectedIndex = this.value.indexOf(this.modelValueMap(option.value));
      if (optionSelectedIndex > -1) {
        this.value.splice(optionSelectedIndex, 1);
      }
      if (this.value.length === 0) {
        this.value = null;
      }
    }
  }

  get value() {
    return this._value;
  }

  set value(obj: any) {
    this._value = obj;
    this._onChange(this._value);
  }

  writeValue(obj: any): void {
    if (obj) {
      this.value = obj;
    }
  }

  registerOnChange(fn: any): void {
    this._onChange = fn;
  }

  registerOnTouched(fn: any): void {
    this._onTouched = fn;
  }


  updateLayout(trigger: ElementRef) {
    const triggerBounds = trigger.nativeElement.getBoundingClientRect();
    this.style = {};
    this.style['top.px'] = triggerBounds.bottom;
    this.style['left.px'] = triggerBounds.left;
    this.style['width.px'] = trigger.nativeElement.clientWidth;
    const listHeight = (this.list && this.list.nativeElement.clientHeight) ? this.list.nativeElement.clientHeight : 300;
    if (triggerBounds.bottom + listHeight > window.innerHeight) {
      this.dropUp = true;
      this.style['bottom.px'] = window.innerHeight - triggerBounds.top;
      delete this.style['top.px'];
    }
  }

  handleupArrow() {
    if (this.activeIndex === -1 || this.activeIndex === 0) {
      this.activeIndex = this.options.length - 1;
    } else {
      this.activeIndex--;
    }
    this.updateActiveItem();
  }

  handleDownArrow() {
    if (this.activeIndex === this.options.length - 1 || this.activeIndex === -1) {
      this.activeIndex = 0;
    } else {
      this.activeIndex++;
    }
    this.updateActiveItem();
  }

  selectActiveOption() {
    if (this.activeItem) {
      this.activeItem.handleSelection();
      this.resetActive();
    }
  }

  resetActive() {
    this.activeIndex = -1;
    this.activeItem = null;
    this.options.forEach((item, index) => {
      item.active = false;
    });
  }

  handleKeyNavigation(keyCode) {
    switch (keyCode) {
      case UP_ARROW:
        this.handleupArrow();
        break;
      case DOWN_ARROW:
        this.handleDownArrow();
        break;
      case ENTER:
        this.selectActiveOption();
        break;
      default:
        return;
    }
  }

  private updateActiveItem() {
    this.options.forEach((item, index) => {
      item.active = this.activeIndex === index;
      if (this.activeIndex === index) {
        this.activeItem = item;
      }
    });
  }

  private updateOptionsSelectedProperty() {
    if (this.value) {
      let currentlySelected: Array<any>;
      if (!(this.value instanceof Array)) {
        currentlySelected = [this.value];
      } else {
        currentlySelected = Object.assign([], this.value);
      }

      this.options.forEach((option) => {
        let optionValue = option.value;
        if (this.modelValueMap) {
          optionValue = this.modelValueMap(option.value);
        }

        option.selected = (currentlySelected.indexOf(optionValue) > -1);
      });
    }
  }

  private getOptionFromMappedValue(mappedValue): SelectBoxOptionComponent {
    let selectedOption: SelectBoxOptionComponent;
    this.options.forEach((option) => {
      const currentOptionMapped = this.modelValueMap(option.value);
      if (this.areOptionsEqual(currentOptionMapped, mappedValue)) {
        selectedOption = option;
      }
    });
    return selectedOption;
  }

  private areOptionsEqual(option1: any, option2: any): boolean {
    return JSON.stringify(option1) === JSON.stringify(option2);
  }

  clearSelected() {
    this.options.forEach((option) => {
      option.selected = false;
    });
    this.value = null;
  }

  deselectOption(value: any) {
    const option: SelectBoxOptionComponent = this.getOptionFromMappedValue(value);
    this.removeFromSelected(option);
  }
}
