import {PanelModel} from '../../models/panel.model';
export class SpecimenModel {
  ri: string;
  request: string;
  status: string;
  status_code: string;
  barcode: string;
  specimen_type: string;
  specimen_type_code: string;
  specimen_num: string;
  specimen_group: string;
  container: string;
  container_coln: string;
  aliquot: string;
  aiquot_specimen_num: string;
  min_draw_vol: string;
  min_test_vol: string;
  date_expires: string;
  label_printed: string;
  date_coln: string;
  date_recieved: string;
  panels: PanelModel[];
  lab: string;
}
