export const DefaultEditorConfig = {
    language: 'en',
    toolbarLocation: 'top',
    toolbarCanCollapse: true,
    height: 200,
    skin: 'bootstrapck',
    font_defaultLabel: 'Courier New',
    fontSize_defaultLabel: '16pt', // approx = to 12pt = 10cpi print
    font_names: 'Arial, Helvetica, sans-serif;' +
    'Times New Roman/Times New Roman, Times, serif;' +
    'Courier New, Courier, DejaVu Sans Mono, monospace;',
    // The toolbar groups arrangement, optimized for two toolbar rows.
    extraPlugins: 'colorbutton,colordialog,contextmenu,dialog,font,maximize,table,tabletools,tableresize,quicktable',
    toolbar: [
      {name: 'clipboard', items: ['Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord', '-', 'Undo', 'Redo']},
      {name: 'editing', items: ['Scayt']},
      {name: 'links', items: ['Link', 'Unlink', 'Anchor']},
      {name: 'insert', items: ['Image', 'Table', 'HorizontalRule', 'SpecialChar']},
      {name: 'tools', items: ['Maximize']},
      {name: 'document', items: ['Source']},
      '/',
      {
        name: 'basicstyles',
        items: ['Bold', 'Italic', 'Underline', 'Strike', 'Subscript', 'Superscript', '-', 'RemoveFormat']
      },
      {name: 'paragraph', items: ['NumberedList', 'BulletedList', '-', 'Outdent', 'Indent', '-', 'Blockquote']},
      {name: 'styles', items: ['Styles', 'Format', 'Font', 'FontSize']},
    ],
    /* Image plugin removed until a repository of images is made available */
    removePlugins: 'image'
  }
;
