import {Input, Component} from '@angular/core';
import {DoctorDetailsModel} from './doctor-details.model';

@Component({
  selector: 'doctor-details-data',
  template: `
      <div *ngIf="doctor" class="row">
      <span class="col-xs-12">
      <span class="no-margin text-left">Name: </span>
      {{doctor.surname}}, {{doctor.given_name}}
          <span *ngIf="doctor.title && doctor.title.trim().length">({{doctor.title}})</span>
      </span>
          <span class="col-xs-6"><span
                  class="no-margin text-left">Tel: </span>{{doctor.telephone}}</span>
          <span class="col-xs-6">
                <span *ngIf="doctor.home_phone" class="no-margin text-left">Tel (Alt.): </span>
                {{doctor.home_phone}}
            </span>
          <span class="col-xs-12">
                <span class="no-margin text-left">Code:</span>
                {{doctor.code}} (Ext. Code: {{doctor.extended_code}})
            </span>
      </div>
  `

})
export class DoctorDetailsDataComponent {
  @Input() doctor: DoctorDetailsModel;
}
