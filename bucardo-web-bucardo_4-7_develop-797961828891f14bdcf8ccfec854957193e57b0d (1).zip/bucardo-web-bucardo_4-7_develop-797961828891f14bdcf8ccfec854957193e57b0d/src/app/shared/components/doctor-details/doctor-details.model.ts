export class DoctorDetailsModel {
  code: string;
  key_num: string;
  num: string;
  extended_code: string;
  status: string;
  title: string;
  surname: string;
  given_name: string;
  middle_name: string;
  address_1: string;
  address_2: string;
  address_3: string;
  city: string;
  state: string;
  postcode: string;
  area: string;
  telephone: string;
  coln_centre: string;
  email?: string;
  home_phone: string;
}
