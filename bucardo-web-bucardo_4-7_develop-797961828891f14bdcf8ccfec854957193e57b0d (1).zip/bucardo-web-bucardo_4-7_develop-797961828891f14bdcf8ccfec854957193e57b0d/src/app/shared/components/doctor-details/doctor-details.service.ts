import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {DoctorDetailsModel} from './doctor-details.model';
import {ApiClient} from '../../services/api-client/api-client';
import {ConfigurationService} from '../../services/configuration/configuration.service';

@Injectable()
export class DoctorDetailsService {
  labAPIUrl: string;

  constructor(private apiClient: ApiClient, private config: ConfigurationService) {
    this.labAPIUrl = config.getConfig().labapi_url;
  }

  getDetails(id: string): Observable<DoctorDetailsModel> {
    return this.apiClient.get(`${this.labAPIUrl}/Doctor/${id}`);
  }

}
