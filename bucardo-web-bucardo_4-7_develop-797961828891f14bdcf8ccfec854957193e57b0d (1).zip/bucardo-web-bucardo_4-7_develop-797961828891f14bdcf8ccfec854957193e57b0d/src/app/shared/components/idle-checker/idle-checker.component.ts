import {
  Component, EventEmitter, HostListener, Input, NgZone, OnChanges, OnInit, Output,
  SimpleChanges
} from '@angular/core';
import {IdleCheckerService} from '../../services/idle-checker/idle-checker.service';

@Component({
  selector: 'idle-checker',
  template: ''
})
export class IdleCheckerComponent implements OnInit, OnChanges {

  @Input() doCheck = true;
  @Input() timeoutAfterSecs;
  @Input() warnAfterSecs;
  @Output() timeout = new EventEmitter();
  @Output() timeoutWarning = new EventEmitter();

  constructor(private idleCheckerService: IdleCheckerService) {
  }

  ngOnInit() {
    if (this.doCheck) {
      this.resetTimers();
    }

    this.idleCheckerService.setTimeoutCallback(() => {
      this.timeout.emit();
    });
    this.idleCheckerService.setWarningCallback(() => {
      this.timeoutWarning.emit();
    });
  }

  ngOnChanges(changes: SimpleChanges): void {
    this.idleCheckerService.setEnableCheck(this.doCheck);
    this.idleCheckerService.setTimeoutTime(this.timeoutAfterSecs);
    this.idleCheckerService.setWarningTime(this.warnAfterSecs);
    this.idleCheckerService.resetTimers();
  }


  @HostListener('document:keypress')
  @HostListener('document:mousedown')
  @HostListener('document:mouseup')
  @HostListener('document:click')
  @HostListener('document:onscroll')
  @HostListener('document:ontouchstart')
  resetTimers() {
    this.idleCheckerService.resetTimers();
  }


}
