import {Component, ViewChild} from '@angular/core';
import {Search, SimpleTokenizer, StemmingTokenizer, TokenHighlighter} from 'js-search';
import * as stem from 'stemmer';
import {EventListenerService} from '../../../services/krill-event-listener/event-listener.service';
import {paletteCommands} from './palette-commands';


declare const $: any;

@Component({
  selector: 'command-palette',
  template: `
      <div #modal id="commandPalette" class="modal fade">
          <div class="modal-dialog" role="document">
              <div class="modal-content">
                  <div class="form-group">
                      <input #input class="form-control input-lg" placeholder="Go to..."
                             (ngModelChange)="onKeyPress($event)" (keydown.enter)="onEnterPressed()"
                             [(ngModel)]="searchTerm">
                  </div>

                  <ul class="results">
                      <li *ngFor="let result of highlightedResults; let i = index"
                          [class.highlight]="i == highlightIndex"
                          (click)="navToResult(result)">
                          <span [innerHtml]="result"></span>
                          <span class="category pull-right">{{results[i].category}}</span>
                      </li>
                  </ul>
              </div>
          </div>
      </div>
  `,
  styles: [
      `
          .modal-content {
              background-color: rgba(255, 255, 255, 0.8);
              height: 90px;
          }

          .modal-content input {
              height: 50px;
              margin-top: 20px;
              padding-left: 20px;
              padding-right: 20px;
              color: #37474F;
              font-size: 25px;
              font-weight: bold;
              background-color: transparent;
              border-bottom-color: transparent;
          }

          .results {
              background-color: rgba(255, 255, 255, 0.8);
              font-size: 16px;
              color: #37474F;
              padding-left: 0;
          }

          .results li {
              padding-left: 10px;
              list-style: none;
              cursor: hand;
          }

          .results li:hover, .highlight {
              background-color: #37474F;
              color: #EEEEEE;
          }

          .category {
              padding-right: 5px;
              opacity: 0.4;
          }

    `
  ]
})
export class CommandPaletteComponent {

  results = [];
  highlightedResults = [];
  searchTerm = '';
  highlightIndex = 0;
  search: Search = new Search('id');
  highlighter: TokenHighlighter = new TokenHighlighter(null, null, 'b');

  @ViewChild('modal') modal;
  @ViewChild('input') input;

  constructor(private eventListenerService: EventListenerService) {
    this.search.tokenizer = new StemmingTokenizer(stem, new SimpleTokenizer());
    this.search.addIndex('desc');
    this.search.addDocuments(paletteCommands);
  }

  public show() {
    this.searchTerm = '';
    $(this.modal.nativeElement).modal('show');
    this.updateSearchResults('');
    setTimeout(() => {
      $(this.input.nativeElement).focus();
    }, 500);
  }

  public hide() {
    $(this.modal.nativeElement).modal('hide');
  }

  get visible() {
    return $(this.modal.nativeElement).css('display') !== 'none';
  }

  onKeyPress(changes) {
    this.updateSearchResults(changes);
  }

  onEnterPressed() {
    if (this.results.length) {
      this.navToResult(this.results[0]);
    }
  }

  navToResult(result) {
    this.eventListenerService.sendEvent(result.event);
    this.hide();
  }

  updateSearchResults(searchTerm) {
    if (searchTerm) {
      this.results = this.search.search(searchTerm);
    } else {
      this.results = paletteCommands;
    }

    const tokens = this.search.tokenizer.tokenize(searchTerm);

    this.highlightedResults = this.results.map((result) => {
      return this.highlighter.highlight(result.desc, tokens);
    });
  }

}
