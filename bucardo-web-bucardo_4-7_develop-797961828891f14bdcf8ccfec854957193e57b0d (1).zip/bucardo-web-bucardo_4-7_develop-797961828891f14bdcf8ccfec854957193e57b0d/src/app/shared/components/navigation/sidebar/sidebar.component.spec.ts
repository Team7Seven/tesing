/* tslint:disable:no-unused-variable */
import {SidebarComponent} from './sidebar.component';
import createSpy = jasmine.createSpy;

describe('SidebarComponent', () => {
  let component: SidebarComponent;
  let routerMock: MockRouter;

  class MockRouter {
    navigate = createSpy('navigate');
  }

  beforeEach(() => {
    routerMock = new MockRouter();
    component = new SidebarComponent(<any>routerMock);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
