export const paletteCommands = [
  {
    id: 1,
    desc: 'Management Reports ( mgr )',
    event: {event: 'menu', payload: {module: 'management-report'}},
    category: 'page'
  },
  {id: 2, desc: 'Request Scans ( rqs )', event: {event: 'document'}, category: 'page'},
  {id: 3, desc: 'Editor > Body Formats ( ebf )', event: {event: 'editLabFormats'}, category: 'page'},
  {id: 4, desc: 'Editor > Templates ( edt )', event: {event: 'editCommonTemplate'}, category: 'page'},
  {
    id: 5,
    desc: 'Editor > Panel Group Formats ( egf )',
    event: {event: 'menu', payload: {module: 'editor/panel-group-formats'}},
    category: 'page'
  },
  {
    id: 6,
    desc: 'Editor > Page Formats ( epf )',
    event: {event: 'menu', payload: {module: 'editor/page-formats'}},
    category: 'page'
  },
  {id: 7, desc: 'Clear Screen ( cls )', event: {event: 'clear'}, category: 'action'},
  {id: 8, desc: 'Logout', event: {event: 'menu', payload: {module: 'login'}}, category: 'action'}];
