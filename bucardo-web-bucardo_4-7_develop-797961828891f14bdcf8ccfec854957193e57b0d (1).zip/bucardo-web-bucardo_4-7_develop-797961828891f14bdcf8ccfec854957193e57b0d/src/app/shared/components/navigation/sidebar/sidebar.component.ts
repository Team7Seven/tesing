import {Component, ElementRef, HostListener, OnInit, ViewChild} from '@angular/core';
import {MenuItems} from '../../../../app.routes';
import {MenuItem} from '../../../utils/menu-utils';
import {Router} from '@angular/router';
import {CommandPaletteComponent} from './command-palette.component';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {

  public menuItems: MenuItem[] = MenuItems;
  public navText: string;
  public navExpanded = false;

  @ViewChild(CommandPaletteComponent) commandPalette: CommandPaletteComponent;

  constructor(private router: Router) {
  }

  ngOnInit() {
  }

  @HostListener('window:keydown', ['$event'])
  keydownListener(event: KeyboardEvent) {
    if (event.key === 'G' && event.altKey && event.shiftKey) {
      if (this.commandPalette.visible) {
        this.commandPalette.hide();
      } else {
        this.commandPalette.show();
      }
    }
  }

  toggleExpanded() {
    this.navExpanded = !this.navExpanded;
  }

  closeSidebar() {
    this.navExpanded = false;
  }

  clickLink(event, path) {
    event.stopPropagation();
    this.navigateTo(path);
  }

  private navigateTo(path) {
    this.navText = '';
    this.router.navigate([path]);
    this.closeSidebar();
  }
}
