import {Component} from '@angular/core';
import {NavbarDataService} from './navbar-data-service';
import {UserService} from '../../../services/user/user.service';
import {UserModel} from '../../../models/user.model';
import {AuthenticationService} from '../../../services/authentication/authentication.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent {

  user: UserModel;
  page: string;

  constructor(private navbarData: NavbarDataService, private userService: UserService,
              private authService: AuthenticationService, private router: Router) {
    navbarData.page.subscribe((page) => this.page = page);
    userService.user.subscribe((user) => this.user = user);
  }

  logout() {
    this.authService.logout();
    this.userService.clearUser();
    this.router.navigate(['login']);
  }

}
