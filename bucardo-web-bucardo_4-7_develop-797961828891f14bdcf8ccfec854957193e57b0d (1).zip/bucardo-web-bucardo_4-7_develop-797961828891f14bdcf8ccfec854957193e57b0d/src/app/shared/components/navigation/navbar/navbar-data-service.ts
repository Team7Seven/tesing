import {Injectable} from '@angular/core';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';

@Injectable()
export class NavbarDataService {
  private pageBS = new BehaviorSubject<string>('');
  page = this.pageBS.share();
  constructor() {}

  setPage(data: string) {
    this.pageBS.next(data);
  }

}
