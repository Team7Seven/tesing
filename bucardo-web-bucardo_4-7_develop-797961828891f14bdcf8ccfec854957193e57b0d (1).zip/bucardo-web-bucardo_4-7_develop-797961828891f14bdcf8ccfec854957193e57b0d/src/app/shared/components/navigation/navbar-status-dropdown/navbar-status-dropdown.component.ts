import {Component, NgZone, OnDestroy, OnInit} from '@angular/core';
import {StatusService} from '../../../services/status/status.service';
import {ConfigurationService} from '../../../services/configuration/configuration.service';

const SLOW_THRESHOLD_TIME = 500;
const PING_POLL_TIME = 5000;

@Component({
  selector: '[navbar-status-dropdown]',
  template: `
      <a *ngIf="pingEnabled" class="nav-dot dropdown-toggle" data-toggle="dropdown">
                    <span class="dot dot-sm {{status}}">

                    </span>
      </a>
      <ul *ngIf="pingEnabled" class="dropdown-menu dropdown-menu-right">
          <li class="extraInfo">{{ extraInfo }}</li>
          <li *ngIf="pingTime" class="extraInfo">({{ pingTime }} ms)</li>
      </ul>
  `,
  styles: [`
      .extraInfo {
          padding: 10px;
      }
  `]
})
export class NavbarStatusDropdownComponent implements OnInit, OnDestroy {
  status = 'dot-success';
  extraInfo = '';
  pingTime = '';
  pingEnabled = true;

  private timerId;
  private slowPingThresholdTime: number;
  private pingPollTime: number;

  constructor(private _ngZone: NgZone, private statusService: StatusService, private config: ConfigurationService) {
    if (config.getConfig().w_ping === 'false' || config.getConfig().w_ping === false) {
      this.pingEnabled = false;
    }
    this.slowPingThresholdTime = Number(config.getConfig().w_ping_slow) || SLOW_THRESHOLD_TIME;
    this.pingPollTime = Number(config.getConfig().w_ping_freq) || PING_POLL_TIME;
  }

  ngOnInit() {
    this.repeatedlyUpdateStatus();
  }

  ngOnDestroy() {
    if (this.timerId) {
      clearInterval(this.timerId);
    }
  }

  private repeatedlyUpdateStatus() {
    if (this.pingEnabled) {
      this.updateStatus();

      this._ngZone.runOutsideAngular(() => {
        this.timerId = setInterval(() => {
          this._ngZone.run(() => this.updateStatus());
        }, this.pingPollTime);
      });
    }
  }

  private updateStatus() {
    this.statusService.ping().subscribe(
      (result) => this.handlePingResult(result),
      (error) => this.handlePingError(error)
    );
  }

  private handlePingResult(result) {
    if (result.elapsedTime > this.slowPingThresholdTime) {
      this.status = 'dot-warning';
      this.extraInfo = `Link to ultra is slow`;
    } else {
      this.status = 'dot-success';
      this.extraInfo = `Link to ultra is healthy`;
    }

    this.pingTime = result.elapsedTime;
  }

  private handlePingError(error) {
    this.status = 'dot-danger';
    this.extraInfo = 'Ultra services down';
    this.pingTime = '';
    console.error(error);
  }


}
