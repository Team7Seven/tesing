export class MrnModel {
  ri: string;
  authority: string;
  num: string;
}
