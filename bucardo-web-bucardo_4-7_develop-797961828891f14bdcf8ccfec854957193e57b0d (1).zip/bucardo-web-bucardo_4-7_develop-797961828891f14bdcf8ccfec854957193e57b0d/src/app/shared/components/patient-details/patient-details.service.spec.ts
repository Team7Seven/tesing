import {ApiClient} from '../../services/api-client/api-client';
import {ConfigurationService} from '../../services/configuration/configuration.service';
import {PatientDetailsService} from './patient-details.service';
import {Observable} from 'rxjs/Observable';
import {PatientDetailsModel} from './patient-details.model';
import {async} from '@angular/core/testing';
import createSpy = jasmine.createSpy;
import Spy = jasmine.Spy;

describe('PatientDetailsService', () => {

  class ApiClientMock {
    get: Spy;
  }

  const labApiUrl = 'http://labApiUrl:8000';
  const validId = '70';
  let configService: ConfigurationService;
  let apiClientMock: ApiClientMock;
  let patientDetailsService: PatientDetailsService;


  beforeEach(() => {
    apiClientMock = new ApiClientMock();
    configService = new ConfigurationService(<ApiClient><any>apiClientMock);
    patientDetailsService = new PatientDetailsService(<ApiClient><any>apiClientMock, configService);
    apiClientMock.get = jasmine.createSpy('get').and.returnValue(Observable.from([PatientDetailsModel]));
  });

  it('should initialise PatientDetailsService successfully', () => {
    expect(patientDetailsService).toBeTruthy();
  });

  it('should return patient details from GET call to Lab API', async(() => {
    patientDetailsService.getDetails(validId).subscribe(
        () => {
          expect(apiClientMock.get).toHaveBeenCalledWith(`${this.labAPIUrl}/Patient/${validId}`);
        }
      );
    })
  );


});





