import {MrnModel} from './mrn.model';

export class PatientDetailsModel {
  ri: string;
  surname: string;
  given_name: string;
  middle_name?: string;
  title: string;
  sex: string;
  species?: string;
  breed?: string;
  usual_doc?: string;
  account_type: string;
  address1?: string;
  address2?: string;
  address3?: string;
  address4?: string;
  city?: string;
  state?: string;
  postcode?: string;
  home_phone?: string;
  work_phone?: string;
  email?: string;
  dob: string;
  mrn?: MrnModel[];
  age?: number;
  age_units?: string;
  birthdate?: string;
  gender: string;
  account_type_desc?: string;
  institution?: string;
  ward?: string;
  room?: string;
  bed?: string;
  display_uid?: string;
  display_authority?: string;
}
