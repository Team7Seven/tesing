import {Component, Input, EventEmitter, Output, OnChanges, SimpleChanges} from '@angular/core';
import {TreeNode} from './tree-view.model';
import * as _ from 'lodash';

@Component({
  selector: 'tree-view',
  templateUrl: 'tree-view.component.html',
  styleUrls: ['tree-view.component.scss']
})
export class TreeViewComponent implements OnChanges {
  @Input() nodes: Array<TreeNode>;
  @Input() query = '';
  @Output() onNodeToggled = new EventEmitter<TreeNode>();

  filteredNodes: Array<TreeNode> = [];

  ngOnChanges(changes: SimpleChanges): void {
    if ('query' in changes || 'nodes' in changes) {
      this.onFilterChanged();
    }
  }

  onFilterChanged() {
    if (!this.query || this.query.length === 0) {
      this.filteredNodes = this.nodes;
    } else {
      this.filteredNodes = this.removeBranchesWithNoMatches(_.cloneDeep(this.nodes), this.query.toLowerCase());
    }
  }

  private removeBranchesWithNoMatches(nodes: Array<any>, query: string) {
    if (nodes && nodes.length > 0) {
      const filteredBranches = nodes.filter((node) => {
        return (this.branchHasMatches(node, query));
      });

      filteredBranches.forEach((branch) => {
        if (!this.nodeMatchesQuery(branch, query)) {
          branch.nodes = this.removeBranchesWithNoMatches(branch.nodes, query);
        }
      });

      return filteredBranches;
    } else {
      return nodes;
    }
  }

  private branchHasMatches(node: any, query: string) {
    if (node && node.name) {
      if (this.nodeMatchesQuery(node, query)) {
        return true;
      } else {
        for (let i = 0; i < node.nodes.length; ++i) {
          const branch = node.nodes[i];
          if (this.branchHasMatches(branch, query)) {
            return true;
          }
        }
      }
    }

    return false;
  }

  private nodeMatchesQuery(node: any, query: string) {
    return node.name.toLowerCase().indexOf(query) !== -1;
  }
}
