export class TreeNode {

    expanded? = true;
    checked? = false;
    partial? = false;

    constructor(public id: number,
                public type: string,
                public name: string,
                public userData: any,
                public nodes: Array<TreeNode>) {
    }

    toggle() {
        this.expanded = !this.expanded;
    }

    getIcon() {

        if (this.expanded) {
            return '-';
        } else if (this.nodes.length > 0) {
            return '+';
        } else {
            return '';
        }


    }

    check() {
        this.checked = !this.checked;
        this.checkRecursive(this.checked);
    }

    checkRecursive(state: boolean) {
        this.nodes.forEach(d => {
            d.checked = state;
            d.checkRecursive(state);
        });
    }
}
