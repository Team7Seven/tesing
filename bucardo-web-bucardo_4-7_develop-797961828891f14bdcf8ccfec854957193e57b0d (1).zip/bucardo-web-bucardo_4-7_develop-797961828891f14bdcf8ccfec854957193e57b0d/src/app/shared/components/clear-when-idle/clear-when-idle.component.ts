import {Component, OnInit, ViewChild} from '@angular/core';
import {NavigationStart, Router} from '@angular/router';
import {UserService} from '../../services/user/user.service';
import {PayloadDataService} from '../../services/payload-data/payload-data.service';
import {IdleCheckerComponent} from '../idle-checker/idle-checker.component';
import {ToastrService} from 'ngx-toastr';

@Component({
  selector: 'clear-when-idle',
  template: `
      <idle-checker #idleChecker [doCheck]="doIdleCheck"
                    [timeoutAfterSecs]="timeoutAfterSecs"
                    [warnAfterSecs]="warnAfterSecs"
                    (timeout)="onTimedOut()"
                    (timeoutWarning)="onTimeoutWarning()"

      ></idle-checker>`
})
export class ClearWhenIdleComponent implements OnInit {
  timeoutAfterSecs = 1200;
  warnAfterSecs = 1170;
  doIdleCheck = true;

  @ViewChild('idleChecker') idleChecker: IdleCheckerComponent;

  constructor(private router: Router,
              private toastService: ToastrService,
              private userService: UserService,
              private payloadDataService: PayloadDataService) {
  }

  ngOnInit(): void {
    this.setDoIdleCheckFromUrl(this.router.url);
    this.checkShouldWeIdleCheckAfterUrlChange();
    this.resetIdleTimersOnPageDataChange();
    this.getUserSpecificTimeoutTimes();
  }

  private checkShouldWeIdleCheckAfterUrlChange() {
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationStart) {
        this.setDoIdleCheckFromUrl(event.url);
      }
    });
  }

  private resetIdleTimersOnPageDataChange() {
    this.payloadDataService.payloadData.subscribe(() => {
      this.idleChecker.resetTimers();
    });
  }

  private getUserSpecificTimeoutTimes() {
    this.userService.user.subscribe((user) => {
      if (user && user.login_timeout_min) {
        this.timeoutAfterSecs = Number(user.login_timeout_min) * 60;
        this.warnAfterSecs = Number(user.login_timeout_warn_min) * 60;
      }
    });
  }

  private setDoIdleCheckFromUrl(url: string) {
    this.doIdleCheck = url !== '/';
  }

  onTimedOut() {
    this.router.navigate(['/']);
    this.toastService.error('Session Timed Out');
    this.payloadDataService.sendPayload(null); // clear the payload in case of back button pressed
  }

  onTimeoutWarning() {
    this.toastService.warning('Session is about to timeout');
  }

}
