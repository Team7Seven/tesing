import {ApiClient} from './api-client';
import {Http, ResponseOptions, Response, Headers} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import Spy = jasmine.Spy;
import {ApiErrorHandler} from './api-error-handler';
import {SuppressedError} from '../../exceptions/suppressed.error';
import {isExceptionType} from '../../utils/exception-utils';

describe('Service: ApiClient', () => {
  const TEST_URL = 'http://somewhere.com';
  const AUTH_TOKEN = 'TOKEN123';
  const RESPONSE_E_TAG = 'RESPONSE_E_TAG';
  const VALID_OBJECT = {hello: 'world'};
  const VALID_BODY = {
    body: 'SomeBody',
    meta: {
      eTag: 'eTag'
    }
  };
  const eTagHeader = new Headers({ETag: RESPONSE_E_TAG});
  const PLAIN_TEXT = 'Plain Text';
  const AN_ERROR = 'ERROR';
  const VALID_RESPONSE = new Response(new ResponseOptions({
    body: JSON.stringify(VALID_OBJECT),
    headers: eTagHeader,
    status: 200
  }));
  const VALID_EMPTY_RESPONSE = new Response(new ResponseOptions({body: '', status: 200}));
  const PLAIN_TEXT_RESPONSE = new Response(new ResponseOptions({body: PLAIN_TEXT, status: 200}));

  let apiClient: ApiClient;
  let mockHttp: HttpMock;
  let errorHandlerMock: ErrorHandlerMock;

  class ErrorHandlerMock {
    fail: Spy;
  }

  class HttpMock {
    get: Spy;
    post: Spy;
    put: Spy;
    delete: Spy;
    postAndExpectText: Spy;
  }

  beforeEach(() => {
    mockHttp = new HttpMock();
    errorHandlerMock = new ErrorHandlerMock();
    apiClient = new ApiClient(<Http><any>mockHttp, <ApiErrorHandler><any>errorHandlerMock);
    errorHandlerMock.fail = jasmine.createSpy('fail').and.throwError(AN_ERROR);
  });

  describe('when calling apiClient.get', () => {

    describe('and getting a successful response', () => {

      beforeEach(() => {
        mockHttp.get = jasmine.createSpy('get').and.returnValue(Observable.of(VALID_RESPONSE));
      });

      it('should call http.get', () => {
        apiClient.get(TEST_URL);
        expect(mockHttp.get).toHaveBeenCalledWith(TEST_URL, jasmine.anything());
      });

      it('should add token auth header if auth token has been set', () => {
        apiClient.setAuthToken(AUTH_TOKEN);
        apiClient.get(TEST_URL);
        expect(mockHttp.get.calls.mostRecent().args[1].headers.get('Authorization')).toEqual('Token TOKEN123');
      });

      it('should not add token auth header if auth flag is set to false', () => {
        apiClient.setAuthToken(AUTH_TOKEN);
        apiClient.get(TEST_URL, null, false);
        expect(mockHttp.get.calls.mostRecent().args[1].headers.get('Authorization')).toBeNull();
      });

      it('should get response as a parsed javascript object', () => {
        apiClient.get(TEST_URL).subscribe(
          (response) => expect(response).toEqual(VALID_OBJECT),
          (error) => fail('should not reach here')
        );
      });
    });


    describe('and getting an error response', () => {

      it('Should rethrow an error thrown by errorHandler.fail', () => {
        mockHttp.get = jasmine.createSpy('get').and.returnValue(Observable.throw(AN_ERROR));

        apiClient.get(TEST_URL).subscribe(
          (response) => fail('should not reach here'),
          (error) => expect(errorHandlerMock.fail).toHaveBeenCalled());
      });

      it('Should throw a suppressed error if we call get with suppress errors', () => {
        mockHttp.get = jasmine.createSpy('get').and.returnValue(Observable.throw(AN_ERROR));

        apiClient.get(TEST_URL, null, false, true).subscribe(
          (response) => fail('should not reach here'),
          (error) => {
            expect(errorHandlerMock.fail).not.toHaveBeenCalled();
            expect(isExceptionType(error, 'SuppressedError')).toBeTruthy();
          });
      });
    });

  });


  describe('when calling apiClient.post', () => {

    describe('and getting a successful response', () => {

      beforeEach(() => {
        mockHttp.post = jasmine.createSpy('post').and.returnValue(Observable.of(VALID_RESPONSE));
      });

      it('should call http.get', () => {
        apiClient.post(TEST_URL, VALID_BODY);
        expect(mockHttp.post).toHaveBeenCalledWith(TEST_URL, VALID_BODY, jasmine.anything());
      });

      it('should not add token auth header if auth flag is set to false', () => {
        apiClient.setAuthToken(AUTH_TOKEN);
        apiClient.post(TEST_URL, VALID_BODY, null, false);
        expect(mockHttp.post.calls.mostRecent().args[2].headers.get('Authorization')).toBeNull();
      });

      it('should add token auth header if auth token has been set', () => {
        apiClient.setAuthToken(AUTH_TOKEN);
        apiClient.post(TEST_URL, VALID_BODY);
        expect(mockHttp.post.calls.mostRecent().args[2].headers.get('Authorization')).toEqual('Token TOKEN123');
      });

      it('should get response as a parsed javascript object', () => {
        apiClient.post(TEST_URL, VALID_BODY).subscribe(
          (response) => expect(response).toEqual(VALID_OBJECT),
          (error) => fail('should not reach here')
        );
      });

      it('should accept an empty response without error', () => {
        mockHttp.post = jasmine.createSpy('post').and.returnValue(Observable.of(VALID_EMPTY_RESPONSE));

        apiClient.post(TEST_URL, VALID_BODY).subscribe(
          (response) => expect(response).toEqual(''),
          (error) => fail('should not reach here')
        );
      });
    });


    describe('and getting an error response', () => {

      it('Should rethrow an error thrown by errorHandler.fail', () => {
        mockHttp.post = jasmine.createSpy('get').and.returnValue(Observable.throw(AN_ERROR));

        apiClient.post(TEST_URL, VALID_BODY).subscribe(
          (response) => fail('should not reach here'),
          (error) => expect(errorHandlerMock.fail).toHaveBeenCalled());
      });

      it('Should throw a suppressed error if we call post with suppress errors', () => {
        mockHttp.post = jasmine.createSpy('post').and.returnValue(Observable.throw(AN_ERROR));

        apiClient.post(TEST_URL, VALID_BODY, null, false, true).subscribe(
          (response) => fail('should not reach here'),
          (error) => {
            expect(errorHandlerMock.fail).not.toHaveBeenCalled();
            expect(isExceptionType(error, 'SuppressedError')).toBeTruthy();
          });
      });

    });

  });

  describe('when calling apiClient.put', () => {

    describe('and getting a successful response', () => {

      beforeEach(() => {
        mockHttp.put = jasmine.createSpy('put').and.returnValue(Observable.of(VALID_RESPONSE));
      });

      it('should call http.put', () => {
        apiClient.put(TEST_URL, VALID_BODY, '');
        expect(mockHttp.put).toHaveBeenCalledWith(TEST_URL, VALID_BODY, jasmine.anything());
      });

      it('should not add token auth header if auth flag is set to false', () => {
        apiClient.setAuthToken(AUTH_TOKEN);
        apiClient.put(TEST_URL, VALID_BODY, '', null, false);
        expect(mockHttp.put.calls.mostRecent().args[2].headers.get('Authorization')).toBeNull();
      });

      it('should add token auth header if auth token has been set', () => {
        apiClient.setAuthToken(AUTH_TOKEN);
        apiClient.put(TEST_URL, VALID_BODY, '');
        expect(mockHttp.put.calls.mostRecent().args[2].headers.get('Authorization')).toEqual('Token TOKEN123');
      });

      it('should call http.put with an eTag if it is supplied', () => {
        mockHttp.put = jasmine.createSpy('putValid').and.returnValue(Observable.of(VALID_RESPONSE));
        apiClient.put(TEST_URL, VALID_BODY, 'bob');
        expect(mockHttp.put.calls.mostRecent().args[2].headers.get('If-Match')).toEqual('eTag');
      });

      it('should get response as a parsed javascript object', () => {
        apiClient.put(TEST_URL, VALID_BODY, '').subscribe(
          (response) => {
            expect(response.body).toEqual(VALID_BODY.body);
          },
          (error) => fail('should not reach here' + error)
        );
      });

      it('should insert the eTag from the response into the original resource', () => {
        apiClient.put(TEST_URL, VALID_BODY, '').subscribe(
          (response) => {
            expect(response.meta.eTag).toEqual(RESPONSE_E_TAG);
          },
          (error) => fail('should not reach here' + error)
        );
      });

      it('should accept an empty response without error', () => {
        mockHttp.put = jasmine.createSpy('putEmpty').and.returnValue(Observable.of(VALID_EMPTY_RESPONSE));

        apiClient.put(TEST_URL, VALID_BODY, '').subscribe(
          (response) => expect(response.body).toEqual(VALID_BODY.body),
          (error) => fail('should not reach here')
        );
      });

    });


    describe('and getting an error response', () => {

      it('Should rethrow an error thrown by errorHandler.fail', () => {
        mockHttp.put = jasmine.createSpy('get').and.returnValue(Observable.throw(AN_ERROR));

        apiClient.put(TEST_URL, VALID_BODY, '').subscribe(
          (response) => fail('should not reach here'),
          (error) => expect(errorHandlerMock.fail).toHaveBeenCalled());
      });

      it('Should throw a suppressed error if we call put with suppress errors', () => {
        mockHttp.put = jasmine.createSpy('put').and.returnValue(Observable.throw(AN_ERROR));

        apiClient.put(TEST_URL, VALID_BODY, '', null, false, true).subscribe(
          (response) => fail('should not reach here'),
          (error) => {
            expect(errorHandlerMock.fail).not.toHaveBeenCalled();
            expect(isExceptionType(error, 'SuppressedError')).toBeTruthy();
          });
      });

    });
  });

  describe('when calling apiClient.delete', () => {

    describe('and getting a successful response', () => {

      beforeEach(() => {
        mockHttp.delete = jasmine.createSpy('delete').and.returnValue(Observable.of(VALID_RESPONSE));
      });

      it('should call http.get', () => {
        apiClient.delete(TEST_URL);
        expect(mockHttp.delete).toHaveBeenCalledWith(TEST_URL, jasmine.anything());
      });

      it('should not add token auth header if auth flag is set to false', () => {
        apiClient.setAuthToken(AUTH_TOKEN);
        apiClient.delete(TEST_URL, null, false);
        expect(mockHttp.delete.calls.mostRecent().args[1].headers.get('Authorization')).toBeNull();
      });

      it('should add token auth header if auth token has been set', () => {
        apiClient.setAuthToken(AUTH_TOKEN);
        apiClient.delete(TEST_URL);
        expect(mockHttp.delete.calls.mostRecent().args[1].headers.get('Authorization')).toEqual('Token TOKEN123');
      });

      it('should get response as a parsed javascript object', () => {
        apiClient.delete(TEST_URL).subscribe(
          (response) => expect(response).toEqual(VALID_OBJECT),
          (error) => fail('should not reach here')
        );
      });

      it('should accept an empty response without error', () => {
        mockHttp.delete = jasmine.createSpy('put').and.returnValue(Observable.of(VALID_EMPTY_RESPONSE));

        apiClient.delete(TEST_URL).subscribe(
          (response) => expect(response).toEqual(''),
          (error) => fail('should not reach here')
        );
      });
    });


    describe('and getting an error response', () => {

      it('Should rethrow an error thrown by errorHandler.fail', () => {
        mockHttp.delete = jasmine.createSpy('delete').and.returnValue(Observable.throw(AN_ERROR));

        apiClient.delete(TEST_URL).subscribe(
          (response) => fail('should not reach here'),
          (error) => expect(errorHandlerMock.fail).toHaveBeenCalled());
      });

      it('Should throw a suppressed error if we call delete with suppress errors', () => {
        mockHttp.delete = jasmine.createSpy('delete').and.returnValue(Observable.throw(AN_ERROR));

        apiClient.delete(TEST_URL, null, false, true).subscribe(
          (response) => fail('should not reach here'),
          (error) => {
            expect(errorHandlerMock.fail).not.toHaveBeenCalled();
            expect(isExceptionType(error, 'SuppressedError')).toBeTruthy();
          });
      });

    });

  });

  describe('when calling apiClient.postAndExpectText', () => {

    describe('and getting a successful response', () => {

      beforeEach(() => {
        mockHttp.post = jasmine.createSpy('post').and.returnValue(Observable.of(VALID_RESPONSE));
      });

      it('should call http.get', () => {
        apiClient.postAndExpectText(TEST_URL, VALID_BODY);
        expect(mockHttp.post).toHaveBeenCalledWith(TEST_URL, VALID_BODY, jasmine.anything());
      });

      it('should not add token auth header if auth flag is set to false', () => {
        apiClient.setAuthToken(AUTH_TOKEN);
        apiClient.postAndExpectText(TEST_URL, VALID_BODY, null, false);
        expect(mockHttp.post.calls.mostRecent().args[2].headers.get('Authorization')).toBeNull();
      });

      it('should add token auth header if auth token has been set', () => {
        apiClient.setAuthToken(AUTH_TOKEN);
        apiClient.postAndExpectText(TEST_URL, VALID_BODY);
        expect(mockHttp.post.calls.mostRecent().args[2].headers.get('Authorization')).toEqual('Token TOKEN123');
      });

      it('should get response as plain text', () => {
        mockHttp.post = jasmine.createSpy('post').and.returnValue(Observable.of(PLAIN_TEXT_RESPONSE));
        apiClient.postAndExpectText(TEST_URL, VALID_BODY).subscribe(
          (response) => expect(response).toEqual(PLAIN_TEXT),
          (error) => fail('should not reach here:' + error)
        );
      });
    });


    describe('and getting an error response', () => {

      it('Should rethrow an error thrown by errorHandler.fail', () => {
        mockHttp.post = jasmine.createSpy('post').and.returnValue(Observable.throw(AN_ERROR));

        apiClient.postAndExpectText(TEST_URL, VALID_BODY).subscribe(
          (response) => fail('should not reach here'),
          (error) => expect(errorHandlerMock.fail).toHaveBeenCalled());
      });

      it('Should throw a suppressed error if we call post with suppress errors', () => {
        mockHttp.post = jasmine.createSpy('post').and.returnValue(Observable.throw(AN_ERROR));

        apiClient.postAndExpectText(TEST_URL, VALID_BODY, null, false, true).subscribe(
          (response) => fail('should not reach here'),
          (error) => {
            expect(errorHandlerMock.fail).not.toHaveBeenCalled();
            expect(isExceptionType(error, 'SuppressedError')).toBeTruthy();
          });
      });
    });
  });


});
