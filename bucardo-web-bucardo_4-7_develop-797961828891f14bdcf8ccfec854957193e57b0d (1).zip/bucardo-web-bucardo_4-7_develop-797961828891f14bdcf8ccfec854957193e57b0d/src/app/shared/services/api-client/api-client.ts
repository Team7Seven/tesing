import {Injectable} from '@angular/core';
import {Headers, Http, Request, RequestOptionsArgs, Response, ResponseContentType} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import {ApiErrorHandler} from './api-error-handler';
import {SuppressedError} from '../../exceptions/suppressed.error';
import {getEtagFromMeta} from '../../utils/etag-utils';
import 'rxjs/add/operator/map'
import 'rxjs/add/operator/timeout'
import * as moment from 'moment';

@Injectable()
export class ApiClient {

  private authToken: string;

  constructor(private http: Http, private errorHandler: ApiErrorHandler) {

  }

  // Needs to be set after it is received from Krill
  public setAuthToken(authToken: string) {
    this.authToken = authToken;
  }

  public getAuthToken() {
    return this.authToken;
  }

  public isReady(): boolean {
    return (!!this.authToken);
  }

  // Does a GET and expects json
  get(url: string, options?: RequestOptionsArgs, authenticated = true, suppressErrors = false, timeout: any = false): Observable<any> {
    options = this.addHeaders(authenticated, options, url);

    const request = this.http.get(url, options);

    if (request) {
      request.timeout(timeout);
    }
    return request.map((response: Response) => {
      return this.parseResponseAsJson(response);
    })
      .catch((error) => this.handleErrors(error, url, suppressErrors));
  }


  getFile(url: string, contentType = '', options?: RequestOptionsArgs,
          authenticated = true, suppressErrors = false, timeout: any = false): Observable<any> {
    if (authenticated) {
      options = this.addAuthenticationHeader(url, options);
    }

    if (contentType) {
      options = this.addContentType(url, options, contentType);
    }

    options.responseType = ResponseContentType.Blob;

    const request = this.http.get(url, options);

    if (request) {
      request.timeout(timeout);
    }
    return request.map((response: Response) => {
      return response.blob();
    })
      .catch((error) => this.handleErrors(error, url, suppressErrors));
  }

  // Does a POST and expects json
  post(url: string, body: any, options?: RequestOptionsArgs, authenticated = true,
       suppressErrors = false, timeout: any = false): Observable<any> {
    options = this.addHeaders(authenticated, options, url);

    const request = this.http.post(url, body, options);
    if (timeout) {
      request.timeout(timeout);
    }
    return request.map((response: Response) => this.parseResponseAsJson(response))
      .catch((error) => this.handleErrors(error, url, suppressErrors));
  }

  postAndExpectText(url: string, body: any, options?: RequestOptionsArgs,
                    authenticated = true, suppressErrors = false, timeout: any = false): Observable<any> {
    options = this.addHeaders(authenticated, options, url);

    const request = this.http.post(url, body, options);
    if (timeout) {
      request.timeout(timeout);
    }
    return request.map((response: Response) => this.parseResponseAsText(response))
      .catch((error) => this.handleErrors(error, url, suppressErrors));
  }

  postAndExpectFile(url: string, body: any, contentType: string, options?: RequestOptionsArgs,
                    authenticated = true, suppressErrors = false, timeout: any = false): Observable<any> {
    if (authenticated) {
      options = this.addAuthenticationHeader(url, options);
    }

    if (contentType) {
      options = this.addContentType(url, options, contentType);
    }

    options.responseType = ResponseContentType.Blob;

    const request = this.http.post(url, body, options);

    if (request) {
      request.timeout(timeout);
    }
    return request.map((response: Response) => {
      return response.blob();
    })
      .catch((error) => this.handleErrors(error, url, suppressErrors));
  }

  // Updates a resource and updates the meta data
  put(url: string, body: any, currentUser: string, options?: RequestOptionsArgs, authenticated = true,
      suppressErrors = false, timeout: any = false): Observable<any> {

    const eTag = getEtagFromMeta(body);

    options = this.addHeaders(authenticated, options, url, eTag);

    const request = this.http.put(url, body, options);
    if (timeout) {
      request.timeout(timeout);
    }
    return request.map(
      (response: Response) => this.updateMetaDataAfterUpdate(response, body, currentUser))
      .catch((error) => this.handleErrors(error, url, suppressErrors));
  }

  private updateMetaDataAfterUpdate(response: Response, metaHolder: any, currentUser: string) {
    let eTag = '';

    if (response.headers) {
      eTag = response.headers.get('ETag') || '';
    }

    if (metaHolder) {
      metaHolder.meta = metaHolder.meta || {};
      metaHolder.meta.opr = currentUser;
      metaHolder.meta.oprName = currentUser;
      metaHolder.meta.eTag = eTag;
      metaHolder.meta.lastUpdated = moment().format();
    }

    return metaHolder;
  }

  delete(url: string, options?: RequestOptionsArgs, authenticated = true,
         suppressErrors = false, timeout: any = false): Observable<any> {
    options = this.addHeaders(authenticated, options, url);

    const request = this.http.delete(url, options);
    if (timeout) {
      request.timeout(timeout);
    }
    return request.map((response: Response) => this.parseResponseAsJson(response))
      .catch((error) => this.handleErrors(error, url, suppressErrors));
  }

  private addHeaders(authenticated: boolean, options: RequestOptionsArgs, url: string, etag?: string) {
    if (authenticated) {
      options = this.addAuthenticationHeader(url, options);
    }

    if (etag) {
      options = this.addEtagHeader(etag, options);
    }
    options = this.addContentTypeJsonHeader(url, options);
    return options;
  }


  private addContentTypeJsonHeader(url: string | Request, options: RequestOptionsArgs) {
    return this.addContentType(url, options, 'application/json');
  }

  private addContentType(url: string | Request, options: RequestOptionsArgs, contentType: string) {
    if (typeof url === 'string') {
      if (!options) {
        options = {headers: new Headers()};
      }
      options.headers.set('Content-Type', contentType);
    } else {
      url.headers.set('Content-Type', contentType);
    }
    return options;
  }

  private addAuthenticationHeader(url: string | Request, options: RequestOptionsArgs) {
    if (this.authToken) {
      if (typeof url === 'string') { // meaning we have to add the token to the options, not in url
        if (!options || !options.headers) {
          options = {headers: new Headers()};
        }
        options.headers.set('Authorization', `Token ${this.authToken}`);
        options.headers.set('Content-Type', 'application/json');
      } else {
        // we have to add the token to the url object
        url.headers.set('Authorization', `Token ${this.authToken}`);
        url.headers.set('Content-Type', 'application/json');
      }
    }
    return options;
  }

  private addEtagHeader(etag: string, options: RequestOptionsArgs) {
    if (!options) {
      options = {headers: new Headers()};
    }
    options.headers.append('Access-Control-Expose-Headers', 'etag');
    options.headers.append('If-Match', etag);

    return options;
  }

  private parseResponseAsJson(response: Response): any {
    if (response.status < 200 || response.status > 226) {
      throw response; // To be picked up by handleErrors
    }

    const jsonText: string = this.parseResponseAsText(response);

    if (jsonText.length === 0) {
      return jsonText;
    } else {
      return this.parseResponse(response, 'json');
    }
  }

  private parseResponseAsText(response: Response): any {
    return this.parseResponse(response, 'text');
  }

  private parseResponse(response: Response, asWhat: string): any {
    return response[asWhat]();
  }

  private handleErrors(response: Response | any, url: string, suppressErrors: boolean): Observable<any> {
    if (!suppressErrors) {
      this.errorHandler.fail(response, url);
    } else {
      return Observable.throw(new SuppressedError());
    }
  }


}
