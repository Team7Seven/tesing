import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class PayloadDataService {

  payloadData = new BehaviorSubject<any>(null);

  constructor() { }

  sendPayload(data: any) {
    this.payloadData.next(data);
  }

}
