import {Injectable} from '@angular/core';
import {Subscription} from 'rxjs/Subscription';
import {Observable} from 'rxjs/Observable';
import {WebSocketSubject} from 'rxjs/observable/dom/WebSocketSubject';
import {Router} from '@angular/router';
import {PayloadDataService} from '../payload-data/payload-data.service';
import {ConfigurationService} from '../configuration/configuration.service';
import {UserService} from '../user/user.service';
import {ApiClient} from '../api-client/api-client';

const RETRY_DURATION = 2000;

@Injectable()
export class EventListenerService {

  private webSocketSubject: WebSocketSubject<any>;
  private webSocketSubscription: Subscription;
  private webSocketUrl: string;

  constructor(private router: Router,
              private payloadDataService: PayloadDataService,
              private config: ConfigurationService,
              private userService: UserService,
              private apiService: ApiClient) {
    this.webSocketUrl = config.getConfig().krill_ws;
  }

  public registerSocketListener() {
    if (!this.webSocketSubject && this.webSocketUrl) {
      console.info('Connecting to :', `${this.webSocketUrl}`);
      this.webSocketSubject = Observable.webSocket(`${this.webSocketUrl}`);
      this.webSocketSubject.share();

      this.webSocketSubscription = this.webSocketSubject
        .subscribe(
          data => {
            console.info('Got Event:', data);
            this.handleEvent(data);
            this.payloadDataService.sendPayload(data);
          },
          error => {
            console.error('Got Error: ', error);
            this.retryConnection();
          });
    }
    this.sendBidToServer();
  }

  public sendEvent(data) {
    this.handleEvent(data);
  }

  private handleEvent(data) {
    try {

      switch (data.event) {
        case 'editLabFormats': // code / lab / key_num
          this.router.navigate(['editor', 'body-formats']);
          break;
        case 'editCommonTemplate': // code
          this.router.navigate(['editor', 'templates']);
          break;
        case 'showpatreport':
          this.router.navigate(['cumulative-reports']);
          break;
        case 'clear':
          this.router.navigate(['/']);
          break;
        case 'labNote':
          this.router.navigate([`/lab-notes`]);
          break;
        case 'login':
        case 'browser':
          if (data.payload.token && data.payload.token !== '') {
            this.saveAuthToken(data.payload.token);
          }
          if (data.payload.user && data.payload.user !== '') {
            this.getUserDetails(data.payload.user);
          }
          break;
        case 'menu':
          const navData = data.payload.module.split('/');
          this.router.navigate(navData);
          break;
        case 'document':
          this.router.navigate(['request-scans']);
          break;
        default:
          console.error('Received event in an invalid format:', data);
          break;
      }

      // track pages navigated to for e2e tests
      if ((<any>window).navigatedTo) {
        (<any>window).navigatedTo[data.event] = true;
      }

    } catch (e) {
      console.error('Received event in an invalid format:', data, e);
    }
  }

  private getUserDetails(username: string) {
    this.userService.getUserDetails(username).subscribe(
      () => {
      });
  }

  private sendBidToServer() {
    const bid = localStorage.getItem('BID');
    if (bid !== null && this.webSocketSubject) {
      this.webSocketSubject.next(JSON.stringify({bid: bid}));
    }
  }

  private retryConnection() {
    console.info('retrying connection...');

    if (this.webSocketSubscription) {
      this.webSocketSubscription.unsubscribe();
    }

    this.webSocketSubject.complete();
    this.webSocketSubject = null;
    const retryTime = RETRY_DURATION;

    setTimeout(() => {
      this.registerSocketListener();
    }, retryTime);
  }

  private saveAuthToken(token: string) {
    this.apiService.setAuthToken(token);
    (<any>window).readyForTest = true;
  }

}
