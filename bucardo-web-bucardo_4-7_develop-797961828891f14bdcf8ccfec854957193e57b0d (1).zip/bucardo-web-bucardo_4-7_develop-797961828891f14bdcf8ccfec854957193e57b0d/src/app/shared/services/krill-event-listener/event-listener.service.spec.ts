import {fakeAsync, tick} from '@angular/core/testing';
import {EventListenerService} from './event-listener.service';
import {Observable} from 'rxjs/Observable';
import {Subject} from 'rxjs/Subject';
import {Router} from '@angular/router';
import {PayloadDataService} from '../payload-data/payload-data.service';
import {ConfigurationService} from '../configuration/configuration.service';
import {UserModel} from '../../models/user.model';
import {UserService} from '../user/user.service';
import {ApiClient} from '../api-client/api-client';
import createSpy = jasmine.createSpy;

describe('Service: KrillEventListener', () => {

  const webSocketURL = `ws://krill`;
  const validUser: UserModel = {
    resourceType: 'Login',
    token: 'MTQ4NTg1ODcwMTE0ODU4NTg3MD',
    code: 'bob',
    name: 'Bobert McBobertson',
    login_group: 'systems',
    lab: 'INV',
    department: 'SY',
    entry_type: 'S',
    library_entry: 'C',
    validation_level: '9',
    confidential_access: '*',
    validation_depts: '*',
    initials: 'ash',
    inquiry_log: 'N',
    login_type: ' ',
    status: 'A',
    login_timeout_min: '20',
    login_timeout_warn_min: '19'
  };

  class ApiClientMock {
    setAuthToken = createSpy('setAuthToken');
  }

  class PayloadDataServiceMock {
    sendPayload = createSpy('sendPayload');
  }

  class RouterMock {
    navigate = createSpy('navigate');
  }

  class ConfigServiceMock {
    getConfig = createSpy('getConfig').and.returnValue({krill_ws: webSocketURL});
  }

  class UserServiceMock {
    getUserDetails = jasmine.createSpy('getUserDetails').and.returnValue(Observable.of(validUser));
  }

  let subject: Subject<any>;
  let fakeEvent: any;
  let exceptionToThrow: any;
  let service: EventListenerService;
  let router: RouterMock;
  let payloadDataService: PayloadDataServiceMock;
  let mockConfigService: ConfigServiceMock;
  let userServiceMock: UserServiceMock;
  let apiClientMock: ApiClientMock;

  beforeEach(() => {
    router = new RouterMock();
    payloadDataService = new PayloadDataServiceMock();
    mockConfigService = new ConfigServiceMock();
    apiClientMock = new ApiClientMock();
    userServiceMock = new UserServiceMock();

    service = new EventListenerService(
      <Router><any>router,
      <PayloadDataService><any>payloadDataService,
      <ConfigurationService><any>mockConfigService,
      <UserService><any>userServiceMock,
      <ApiClient><any>apiClientMock
    );

    spyOn(console, 'error');
    spyOn(console, 'info');
  });

  describe('Server is healthy', () => {

    beforeEach(() => {
      subject = new Subject();
      spyOn(Observable, 'webSocket').and.returnValue(subject);
    });

    it('should get the krill url from config', () => {
      expect(mockConfigService.getConfig).toHaveBeenCalled();
    });

    it('should create an observable webSocket subject given the correct url', () => {
      spyOn(localStorage, 'getItem').and.returnValue(1234);
      service.registerSocketListener();

      expect(Observable.webSocket).toHaveBeenCalledWith(webSocketURL);
    });

    const sendFakeData = function (fakeData: any) {
      service.registerSocketListener();
      subject.next(fakeData);
    };

    it('should navigate to editor page on editLabFormat event passed in and pass data into payload data service', () => {
      sendFakeData({event: 'editLabFormats', payload: 'some data'});

      expect(payloadDataService.sendPayload).toHaveBeenCalledWith({event: 'editLabFormats', payload: 'some data'});
    });

    it('should navigate to editor page on editCommonTemplate event passed in and pass data into payload data service', () => {
      sendFakeData({event: 'editCommonTemplate', payload: 'some data'});

      expect(payloadDataService.sendPayload).toHaveBeenCalledWith({event: 'editCommonTemplate', payload: 'some data'});
      expect(router.navigate).toHaveBeenCalledWith(['editor', 'templates']);
    });

    it('should navigate to the root page on clear event passed in', () => {
      sendFakeData({event: 'clear', payload: 'some data'});

      expect(router.navigate).toHaveBeenCalledWith(['/']);
    });

    it('should write error to console if data is empty', () => {
      sendFakeData(null);

      expect(console.error).toHaveBeenCalledWith('Received event in an invalid format:', null, jasmine.anything());
    });

    it('should write error to console if data is incorrect', () => {
      sendFakeData('invalid data');

      expect(console.error).toHaveBeenCalledWith('Received event in an invalid format:', 'invalid data');
    });

    describe('When browser event called', () => {
      beforeEach(() => {
        sendFakeData({event: 'browser', payload: {token: 'token123', user: 'bob123'}});
      });

      it('should set the token on the api client', () => {
        expect(apiClientMock.setAuthToken).toHaveBeenCalledWith('token123');
      });

      it('should call the user service to get the user details for the username', () => {
        expect(userServiceMock.getUserDetails).toHaveBeenCalledWith('bob123');
      });

    });

    describe('When browser opened with no authenication call from GUI made', () => {
      beforeEach(() => {
        sendFakeData({event: 'browser', payload: {token: '', user: ''}});
      });

      it('should NOT set the token on the api client', () => {
        expect(apiClientMock.setAuthToken).not.toHaveBeenCalled();
      });

      it('should NOT make a call to the user service to get the user details for the username', () => {
        expect(userServiceMock.getUserDetails).not.toHaveBeenCalled();
      });

      it('should NOT log anything to the console', () => {
        expect(console.error).not.toHaveBeenCalled();
      });

    });


    describe('When login event called', () => {
      beforeEach(() => {
        sendFakeData({event: 'login', payload: {token: 'token123', user: 'bob123'}});
      });

      it('should set the token on the api client', () => {
        expect(apiClientMock.setAuthToken).toHaveBeenCalledWith('token123');
      });

      it('should call the user service to get the user details for the username', () => {
        expect(userServiceMock.getUserDetails).toHaveBeenCalledWith('bob123');
      });

    });


  });

  describe('Server Encounters Errors', () => {

    beforeEach(() => {
      subject = new Subject();

      spyOn(Observable, 'webSocket').and.callFake(() => {
        if (fakeEvent) {
          const result: any = Observable.of(fakeEvent);
          result.complete = jasmine.createSpy('complete');
          return result;
        } else {
          const result: any = Observable.throw(exceptionToThrow);
          result.complete = jasmine.createSpy('complete');
          return result;
        }
      });

    });

    it('should try to reconnect with a delayed time interval',
      fakeAsync(() => {

        const timeout = spyOn(global, 'setTimeout').and.callThrough();

        exceptionToThrow = 'An error occurred';
        service.registerSocketListener();

        tick(1000);

        fakeEvent = {event: 'editLabFormats', payload: 'some data'};

        tick(2000);

        expect(timeout).toHaveBeenCalledWith(jasmine.any(Function), 2000);
        expect(timeout.calls.count()).toEqual(1);

        expect(router.navigate).toHaveBeenCalledWith(['editor', 'body-formats']);
      }));
  });

});
