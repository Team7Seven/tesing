import {Injectable} from '@angular/core';
import {ApiClient} from '../api-client/api-client';
import {ConfigurationService} from '../configuration/configuration.service';
import {Observable} from 'rxjs/Observable';
import {DateUtilsService} from '../../utils/date-utils.service';

@Injectable()
export class StatusService {

  private labApiUrl: string;
  private pingTimeout: number;

  constructor(private apiClient: ApiClient, private configService: ConfigurationService, private dateUtils: DateUtilsService) {
    this.labApiUrl = configService.getConfig().labapi_url;
    this.pingTimeout = Number(configService.getConfig().w_ping_timeout) || 5000;
  }

  ping(): Observable<any> {
    const startTime = this.dateUtils.getTimeMs();

    return this.apiClient.get(`${this.labApiUrl}/Proc/$ping`, null, false, true, this.pingTimeout).map(() => {
      return {
        elapsedTime: this.dateUtils.getTimeMs() - startTime
      };
    });
  }

}
