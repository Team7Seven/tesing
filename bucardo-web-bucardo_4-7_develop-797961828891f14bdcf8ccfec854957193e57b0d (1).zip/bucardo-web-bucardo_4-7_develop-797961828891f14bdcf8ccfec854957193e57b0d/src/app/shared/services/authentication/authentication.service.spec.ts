import {Response, ResponseOptions} from '@angular/http';
import {AuthenticationService} from './authentication.service';
import {async} from '@angular/core/testing';
import {Login} from '../../../+login/shared/models/login.model';
import {Observable} from 'rxjs/Observable';
import createSpy = jasmine.createSpy;
import Spy = jasmine.Spy;

describe('Authentication Service', () => {

  const LABAPI_URL = 'http://LABAPIURL';
  const TOKEN_VALUE = 'TOKEN_VALUE';

  const validLoginCredentials = new Login('bobert', 'Jumbone', 'Bob', 'McConnell', '');
  const invalidLoginCredentials = new Login('bobert', 'Jumbone123', 'Bob', 'McConnell', '');

  const successResponseObj = {token: TOKEN_VALUE};
  const errorResponse = new Response(new ResponseOptions({body: 'There has been a terrible error', status: 500}));

  const invalidCredsResponseObj = {error: 'Invalid Credentials'};
  const invalidCredsResponse = new Response(new ResponseOptions({body: JSON.stringify(invalidCredsResponseObj)}));

  let service: AuthenticationService;
  let httpMock: MockHttpService;
  let configServiceMock: MockConfigService;

  class MockHttpService {
    post: Function;
  }

  class MockConfigService {
    getConfig = createSpy('getConfig').and.returnValue({
      labapi_url: LABAPI_URL
    });
  }

  beforeEach(() => {
    httpMock = new MockHttpService();
    configServiceMock = new MockConfigService();
    service = new AuthenticationService(<any>httpMock, <any>configServiceMock);
  });

  describe('Login', () => {

    describe('with valid credentials and success server response', () => {

      beforeEach(() => {
        httpMock.post = createSpy('post').and.returnValue(Observable.of(successResponseObj));
      });

      it('should return TOKEN_VALUE', async(() => {
          service.login(validLoginCredentials).subscribe(
            data => {
              expect(data).toBe(TOKEN_VALUE);
            }
          );
        })
      );

      it('should call out to server to log in', async(() => {
          service.login(validLoginCredentials).subscribe(
            () => {
              expect(httpMock.post).toHaveBeenCalled();
            }
          );
        })
      );

      it('should store the auth token and username in localstorage', async(() => {
          spyOn(localStorage, 'setItem');

          service.login(validLoginCredentials).subscribe(
            () => {
              expect((<Spy>localStorage.setItem).calls.allArgs()).toEqual([['token', TOKEN_VALUE], ['username', 'bobert']]);
            }
          );
        })
      );


    }); // Valid Credentials

    describe('with valid credentials and error server response', () => {

      beforeEach(() => {
        httpMock.post = createSpy('post').and.returnValue(Observable.of(errorResponse));
      });

      it('should return a result of falsey', () => {
        spyOn(localStorage, 'setItem');

        service.login(validLoginCredentials).subscribe(
          (result) => {
            expect(result).toBeFalsy();
          }
        );
      });

      it('should not set a token on local storage', () => {
        spyOn(localStorage, 'setItem');

        service.login(validLoginCredentials).subscribe(
          () => {
            expect(localStorage.setItem).not.toHaveBeenCalled();
          }
        );
      });

    }); // Server error

    describe('with invalid credentials', () => {

      beforeEach(() => {
        httpMock.post = createSpy('post').and.returnValue(Observable.from([invalidCredsResponse]));
      });

      it('should return a result of falsey', () => {
        spyOn(localStorage, 'setItem');

        service.login(invalidLoginCredentials).subscribe(
          (result) => {
            expect(result).toBeFalsy();
          }
        );
      });

      it('should not set a token on local storage', () => {
        spyOn(localStorage, 'setItem');

        service.login(invalidLoginCredentials).subscribe(
          () => {
            expect(localStorage.setItem).not.toHaveBeenCalled();
          }
        );
      });

    }); // Invalid credentials
  });

  describe('Logout', () => {

    it('should remove token, username and bid from local storage', () => {
      spyOn(localStorage, 'removeItem');

      service.logout();

      expect((<Spy>localStorage.removeItem).calls.allArgs()).toEqual([['token'], ['username'], ['BID']]);
    });
  });


});
