import {Injectable} from '@angular/core';
import {Headers, RequestOptions} from '@angular/http';
import {Login} from '../../../+login/shared/models/login.model';
import {Observable} from 'rxjs/Observable';
import {ApiClient} from '../api-client/api-client';
import {ConfigurationService} from '../configuration/configuration.service';

/**
 * This class provides the Authentication service with methods to login and logout.
 */

@Injectable()
export class AuthenticationService {
  public LOGIN_TOKEN = 'token';
  public USERNAME_TOKEN = 'username';
  private loggedIn = false;
  private labApiUrl: string;


  constructor(private apiClient: ApiClient, private config: ConfigurationService) {
    this.loggedIn = !!localStorage.getItem(this.LOGIN_TOKEN);
    this.labApiUrl = config.getConfig().labapi_url;
  }

  login(credentials: Login): Observable<string> {

    const loginToken: string = credentials.username + ':' + credentials.password;
    const encodedToken = btoa(loginToken);

    const body = JSON.stringify({username: credentials.username});
    const headers = new Headers({'Content-Type': 'application/json'});
    const authToken = 'Basic ' + encodedToken;
    headers.append('Authorization', authToken);
    const options = new RequestOptions({headers: headers});

    return this.apiClient.post(`${this.labApiUrl}/User/$auth`, body, options, false, false, 5)
      .map((response: any) => {
        try {
          if (response.token) {
            localStorage.setItem(this.LOGIN_TOKEN, response.token);
            localStorage.setItem(this.USERNAME_TOKEN, credentials.username);
            this.loggedIn = true;
            return response.token;
          } else {
            return '';
          }
        } catch (err) {
          console.error('Login Error:', err);
          return '';
        }
      });
  }

  logout() {
    localStorage.removeItem(this.LOGIN_TOKEN);
    localStorage.removeItem(this.USERNAME_TOKEN);
    localStorage.removeItem('BID');
    this.loggedIn = false;
  }

  isLoggedIn() {
    // Disable login for the moment - not needed for HHB
    return localStorage.getItem(this.LOGIN_TOKEN);
  }
}
