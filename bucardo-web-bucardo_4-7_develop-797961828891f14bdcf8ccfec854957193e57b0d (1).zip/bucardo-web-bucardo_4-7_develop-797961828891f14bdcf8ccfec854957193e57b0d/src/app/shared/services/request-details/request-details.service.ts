import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {RequestModel} from '../../models/request.model';
import {ConfigurationService} from '../configuration/configuration.service';
import {ApiClient} from '../api-client/api-client';

@Injectable()
export class RequestDetailsService {
  labAPIUrl: string;

  constructor(private apiClient: ApiClient, private config: ConfigurationService) {
    this.labAPIUrl = config.getConfig().labapi_url;
  }

  getDetails(id: string): Observable<RequestModel> {
    return this.apiClient.get(`${this.labAPIUrl}/Request/${id}`);
  }

}
