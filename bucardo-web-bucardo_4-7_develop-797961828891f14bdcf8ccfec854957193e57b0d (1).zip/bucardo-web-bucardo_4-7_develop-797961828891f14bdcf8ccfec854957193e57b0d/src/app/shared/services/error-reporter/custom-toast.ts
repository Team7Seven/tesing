export class CustomToast {
  title = '';
  body = '';
  timeout = 30000;
  type = 'error';
}
