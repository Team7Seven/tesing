import {ErrorHandler, Inject, Injectable, Injector} from '@angular/core';
import {ApiClient} from '../api-client/api-client';
import {SuppressedError} from '../../exceptions/suppressed.error';
import {isExceptionType} from '../../utils/exception-utils';
import {ToastrService} from 'ngx-toastr';

@Injectable()
export class ErrorReporterService implements ErrorHandler {

  public labApiUrl: string;
  private toastService;

  constructor(private apiClient: ApiClient, @Inject(Injector) private injector: Injector) {
  }

  private get toasterService(): ToastrService {
    if (!this.toastService) {
      this.toastService = this.injector.get(ToastrService);
    }
    return this.toastService;
  }

  handleError(error: any): void {
    if (isExceptionType(error, 'SuppressedError')) {
      return;
    }

    this.reportErrorToTheConsole(error);
    this.reportErrorToTheLabApi(error);

    if (!error.noToast) {
      this.reportErrorAsToastMessage(error);
    }
  }

  public reportErrorToTheConsole(error: any) {
    console.error(error.stack);
  }

  public reportErrorToTheLabApi(error: any) {
    const payload = {
      severity: 'error',
      text: error.message,
      exception: error.stack
    };

    this.apiClient.post(`${this.labApiUrl}/Proc/$logEvent`, payload, null, false, true).subscribe(
      () => console.info('Successfully reported error'),
      (err) => console.error('Failed to report error', err));
  }

  public reportErrorAsToastMessage(error) {
    if (error.customToast) {
      const toast = error.customToast;

      this.toasterService.show(toast.body, toast.title, {
        timeOut: toast.timeout,
        onActivateTick: true
      }, `toast-${toast.type}`);
    } else {
      this.toasterService.error(error.message, 'Error', {onActivateTick: true});
    }
  }
}

