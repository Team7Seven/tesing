import {Component, OnInit, ViewChild, OnDestroy} from '@angular/core';
import {EditorService} from './shared/editor.service';
import {PayloadDataService} from '../shared/services/payload-data/payload-data.service';
import {Subscription} from 'rxjs/Subscription';
import {ItemsSearchCriteriaModel} from './editor-items/items-search-criteria.model';
import {NavbarDataService} from '../shared/components/navigation/navbar/navbar-data-service';
import {HtmlEditorComponent} from '../shared/components/html-editor/html-editor.component';
import {SearchBoxItemModel} from '../shared/components/search-box/search-box-item.model';
import {LoginUtilsService} from '../shared/utils/login-utils.service';
import {ToastrService} from 'ngx-toastr';

@Component({
  selector: 'body-format-editor',
  styleUrls: ['body-format-editor.component.scss'],
  templateUrl: 'body-format-editor.component.html',
  providers: [EditorService]
})
export class BodyFormatEditorComponent implements OnInit, OnDestroy {

  editorContent: string;
  editorReadOnly = true;
  metaData: any;
  selectedLabFormat: any = null;
  selectedTemplateCode = '';
  selectedTemplateStyle: any = null;
  templatesOfStyle = [];
  showItemsList = false;
  generateDisabled = true;
  formatStyles = [];
  items: any;
  permissions: any = {};
  formats = [];

  private payloadDataServiceSub: Subscription;

  @ViewChild('itemsDialog') itemsDialog;
  @ViewChild('htmlEditor') editor: HtmlEditorComponent;

  constructor(private toaster: ToastrService,
              private editorService: EditorService,
              private payloadDataService: PayloadDataService,
              private navbarService: NavbarDataService,
              private loginUtils: LoginUtilsService) {
    navbarService.setPage('Lab Format Editor');
  }

  ngOnDestroy() {
    if (this.payloadDataServiceSub) {
      this.payloadDataServiceSub.unsubscribe();
    }
  }

  ngOnInit() {
    this.subscribeToPayloadService();
  }

  private subscribeToPayloadService() {
    this.payloadDataServiceSub = this.payloadDataService.payloadData.subscribe((eventData) => {
      if (eventData) {
        if (this.isAnEventToStartEditor(eventData)) {
          this.getFormatsIfTheUserHasPermissions(eventData);
        }
      }

      if (this.loginUtils.isUserLoggedIn()) {
        this.getFormatsIfTheUserHasPermissions();
      }
    });
  }

  private isAnEventToStartEditor(eventData: any) {
    return (eventData.event === 'menu' && eventData.payload.module === 'editor/report-format') ||
      eventData.event === 'editLabFormats' || // edit a specific template
      eventData.event === 'browser'; // browser means we just got a token and can now call getTemplatePermissions
  }

  private weShouldLoadSpecificFormat(eventData) {
    return eventData.event === 'editLabFormats';
  }

  private getFormatsIfTheUserHasPermissions(eventData = null) {
    this.editorService.getFormatPermissions().subscribe(
      (permissions) => {
        this.permissions = permissions;
        if (this.permissions.find) {
          this.getTemplateStyles();
          this.refreshListOfLabFormats();

          if (eventData) {
            if (this.weShouldLoadSpecificFormat(eventData)) {
              this.selectedLabFormat = eventData.payload;
              this.getLabFormat(eventData.payload);
            }
          }
        } else {
          this.toaster.warning('You do not have permission to view this page.');
        }
      }
    );
  }

  private getLabFormat(formatData: any) {
    this.editorService.getLabFormat(formatData.code, formatData.lab, formatData.key_num).subscribe(
      (labFormat) => this.setSelectedLabFormat(labFormat),
      (error) => {
        this.setSelectedLabFormat(null);
        throw error;
      }
    );
  }

  private getTemplateStyles() {
    this.editorService.getTemplateStyles('formats').subscribe(
      (styles) => {
        this.formatStyles = styles;
      }
    );
  }

  private refreshListOfLabFormats() {
    this.editorService.getListOfLabFormats().subscribe((formats) => {
      this.formats = formats;
    });
  }

  private setSelectedLabFormat(labFormat) {
    this.selectedLabFormat = labFormat;
    this.resetCreateFromTemplateData();

    if (labFormat) {
      this.setReportContentsAndMetaData(labFormat.body, labFormat.metaData);
      this.editorReadOnly = !(this.permissions.change || this.permissions.add);
    } else {
      this.editorReadOnly = true;
      this.setReportContentsAndMetaData(null, null);
    }
  }

  private resetCreateFromTemplateData() {
    this.selectedTemplateCode = null;
    this.selectedTemplateStyle = null;
    this.templatesOfStyle = [];
  }

  private setReportContentsAndMetaData(html: string, metaData: any) {
    this.editorContent = html;
    this.metaData = metaData;
  }

  public onSavePressed() {
    if (this.selectedLabFormat && this.permissions.change) {
      this.editorContent = this.editor.refreshEditorContent();
      if (this.editorContent.indexOf('ITEM') + 1) {
        this.toaster.warning('You must replace \'ITEM\' placeholders before saving.');
        return;
      }

      this.selectedLabFormat = Object.assign(this.selectedLabFormat, {body: this.editorContent});

      this.editorService.saveLabFormat(this.selectedLabFormat).subscribe(
        (updatedLabFormat) => {
          this.selectedLabFormat = Object.assign({}, updatedLabFormat);
          this.toaster.success('Saved...');
        }
      );

    } else if (!this.permissions.change) {
      this.toaster.warning('You do not have permission to update this resource.');
    }
  }

  public onTemplateSelected(templateCode: string) {
    this.selectedTemplateCode = templateCode;
  }

  public onTemplateStyleSelected(style: any) {
    if (this.selectedTemplateStyle && this.selectedTemplateStyle.code === style.code) {
      return;
    }

    this.selectedTemplateStyle = style;
    this.showItemsList = this.selectedTemplateStyle === 'true';

    this.editorService.getTemplatesFromClassAndStyle('formats', style.code).subscribe(
      (templates) => this.handleTemplatesOfStyleResult(templates)
    );
  }

  public onFormatSelected(format: Array<SearchBoxItemModel>) {
    if (format) {
      this.getLabFormat(format);
    } else {
      this.setSelectedLabFormat(null);
    }
  }


  private handleTemplatesOfStyleResult(templates) {
    this.templatesOfStyle = templates;

    if (templates && templates.length) {
      this.selectedTemplateCode = templates[0].id;
    }
  }

  public onItemSelected(item: string) {
    this.editor.insertHtml(item);
  }

  public onItemsSearch(model: ItemsSearchCriteriaModel) {
    this.editorService.getLabItems(model).subscribe(
      (items) => this.items = items);
  }

  public onLoadInEditorPressed() {
    if (this.selectedTemplateCode) {
      this.editorService.getCommonTemplate(this.selectedTemplateCode).subscribe(
        (content) => {
          if (content) {
            this.editorContent = content.body;
            this.generateDisabled = false;
          }
        }
      );
    }
  }

  public onUseTemplatePressed(items) {
    if (items && this.selectedTemplateCode && !this.generateDisabled) {
      this.editorService.generateFormatFromItems(
        items,
        this.editorContent,
        this.selectedTemplateCode)
        .subscribe(
          (content) => {
            this.editorContent = content.body;
            this.generateDisabled = true;
          }
        );
    }
  }


}
