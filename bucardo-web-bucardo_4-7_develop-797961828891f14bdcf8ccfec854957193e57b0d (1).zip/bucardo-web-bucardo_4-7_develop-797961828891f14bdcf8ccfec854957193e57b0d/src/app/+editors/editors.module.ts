import {BodyFormatEditorComponent} from './body-format-editor.component';
import {EditorRoutes} from './editors.routes';
import {RouterModule} from '@angular/router';
import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {EditorFormatControlsComponent} from './editor-format-controls/editor-format-controls.component';
import {EditorItemsComponent} from './editor-items/editor-items.component';
import {TemplateInfoTableComponent} from './template-info-table/template-info-table.component';
import {SharedModule} from '../shared/shared.module';
import {ModalModule} from 'ngx-bootstrap';
import {EditorPageAreaSelectorComponent} from './editor-page-area-selector/editor-page-area-selector.component';
import {DraggableDirective} from './editor-items/editor-items-draggable.directive';
import {EditorTemplateControlsComponent} from './editor-template-controls/editor-template-controls.component';
import {TemplateEditorComponent} from './template-editor.component';
import {EditorTypeSelectorComponent} from './editor-type-selector/editor-type-selector.component';
import {PageFormatEditorComponent} from './page-format-editor/page-format-editor.component';
import {PanelGroupFormatEditorComponent} from './panel-group-format-editor/panel-group-format-editor.component';
import {SelectBoxModule} from '../shared/components/select-box/select-box.module';

@NgModule({
  declarations: [BodyFormatEditorComponent,
    TemplateEditorComponent,
    EditorItemsComponent,
    EditorFormatControlsComponent,
    EditorTemplateControlsComponent,
    TemplateInfoTableComponent,
    EditorPageAreaSelectorComponent,
    DraggableDirective,
    EditorTypeSelectorComponent,
    PageFormatEditorComponent,
    PanelGroupFormatEditorComponent],
  imports: [RouterModule.forChild(EditorRoutes),
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    SharedModule,
    ModalModule.forRoot(),
    SelectBoxModule],
  exports: [BodyFormatEditorComponent, TemplateEditorComponent]
})
export class EditorsModule {
}
