import {Component, ViewChild, Output, EventEmitter, Input} from '@angular/core';
import {ItemsSearchCriteriaModel} from './items-search-criteria.model';
import {ModalDirective} from 'ngx-bootstrap';
import {DraggableDirective} from './editor-items-draggable.directive';

@Component({
  selector: 'editor-items',
  styleUrls: ['editor-items.component.scss'],
  templateUrl: 'editor-items.component.html',
  providers: [DraggableDirective]
})

export class EditorItemsComponent {
  @ViewChild('itemsListDialog') public itemsListDialog: ModalDirective;
  @Output() selectedItem = new EventEmitter<string>();
  @Output() submitClicked = new EventEmitter<ItemsSearchCriteriaModel>();
  @Input() items: any[];
  model = new ItemsSearchCriteriaModel();

  public showDialog(): void {
    this.itemsListDialog.show();
  }

  public hideDialog(): void {
    this.itemsListDialog.hide();
  }

  public onSubmit() {
    this.submitClicked.emit(this.model);
  }

  public onClick(selectedItem) {
    this.selectedItem.emit(selectedItem);
    this.hideDialog();
  }

}
