import {BodyFormatEditorComponent} from './body-format-editor.component';
import {Observable} from 'rxjs/Observable';
import {fakeAsync, tick} from '@angular/core/testing';
import {EditorService} from './shared/editor.service';
import {PayloadDataService} from '../shared/services/payload-data/payload-data.service';
import {NavbarDataService} from '../shared/components/navigation/navbar/navbar-data-service';
import {ToastrService} from 'ngx-toastr';
import createSpy = jasmine.createSpy;

describe('BodyFormatEditorComponent', () => {

  const STYLE_CODE = 'style_code';
  const TEMPLATE_CODE = 'template_code';
  const TEMPLATE_BODY = 'TEMPLATE_BODY';
  const EDITOR_CONTENT = 'EDITOR_CONTENT';
  const THROWN_ERROR = 'An Error';
  const NEW_ETAG = 'NEW_ETAG';
  const VALID_BODY = {
    body: 'SomeBody',
    meta: {
      eTag: NEW_ETAG
    }
  };

  let component: BodyFormatEditorComponent;
  let navbarServiceMock: NavbarDataServiceMock;
  let toasterServiceMock: ToastrServiceMock;
  let editorServiceMock: EditorServiceMock;
  let payloadDataServiceMock: PayloadDataServiceMock;
  let loginUtils: LoginUtilsMock;

  class ToastrServiceMock {
    warning = createSpy('toastWarning');
    success = createSpy('toastSuccess');
  }

  class EditorServiceMock {
    getCommonTemplate = createSpy('getCommonTemplate').and.returnValue(Observable.of({body: TEMPLATE_BODY}));
    getLabFormat = createSpy('getLabFormat').and.returnValue(Observable.of([]));
    getLabItems = createSpy('getLabItems').and.returnValue(Observable.of([]));
    saveLabFormat = createSpy('saveLabFormat').and.returnValue(Observable.of(VALID_BODY));
    getListOfLabFormats = createSpy('getListOfLabFormats').and.returnValue(Observable.of([]));
    getTemplateStyles = createSpy('getTemplateStyles').and.returnValue(Observable.of([{code: STYLE_CODE}]));
    getTemplatesFromClassAndStyle = createSpy('getTemplatesFromClassAndStyle').and.returnValue(Observable.of([{code: STYLE_CODE}]));
    generateFormatFromItems = createSpy('generateFormatFromItems').and.returnValue(Observable.of(TEMPLATE_BODY));
    getFormatPermissions = createSpy('getPermissions').and.returnValue(Observable.of({find: true, change: true}));
  }

  class PayloadDataServiceMock {
    payloadData: Observable<any> = Observable.of({event: '', payload: {}});
  }

  class NavbarDataServiceMock {
    setPage = createSpy('setPage');
  }

  class EditorComponentMock {
    refreshEditorContent = createSpy('refreshEditorContent').and.returnValue('STUFF');
  }

  class LoginUtilsMock {
    isUserLoggedIn = createSpy('isUserLoggedIn').and.returnValue(true);
  }

  beforeEach(() => {
    spyOn(console, 'error');
    toasterServiceMock = new ToastrServiceMock();
    editorServiceMock = new EditorServiceMock();
    payloadDataServiceMock = new PayloadDataServiceMock();
    navbarServiceMock = new NavbarDataServiceMock();
    loginUtils = new LoginUtilsMock();

    component = new BodyFormatEditorComponent(
      <any>toasterServiceMock,
      <any>editorServiceMock,
      <any>payloadDataServiceMock,
      <any>navbarServiceMock,
      <any>loginUtils);

    component.editor = <any>new EditorComponentMock();

    payloadDataServiceMock.payloadData = Observable.of({event: 'editLabFormats', payload: {}});
  });

  describe('on initialisation', () => {

    it('should subscribe to payload data on initialisation', fakeAsync(() => {
      spyOn(payloadDataServiceMock.payloadData, 'subscribe').and.callThrough();
      component.ngOnInit();
      tick();
      expect(payloadDataServiceMock.payloadData.subscribe).toHaveBeenCalled();
    }));

    it('should get a list of Lab Formats on init when event is \'editLabFormats\'', () => {
      payloadDataServiceMock.payloadData = Observable.of({
        event: 'editLabFormats',
        payload: {code: 'code', lab: 'lab', key_num: 'key_num'}
      });
      component.ngOnInit();

      expect(editorServiceMock.getListOfLabFormats).toHaveBeenCalled();
    });

    it('should not get templates that match the first style on init', () => {
      component.ngOnInit();

      expect(editorServiceMock.getTemplatesFromClassAndStyle).not.toHaveBeenCalledWith('formats', STYLE_CODE);
    });

    it('should make a request to get user permissions', () => {
      component.ngOnInit();
      expect(editorServiceMock.getFormatPermissions).toHaveBeenCalled();
    });


    describe('with restricted permissions', () => {

      beforeEach(() => {
        editorServiceMock.getFormatPermissions = createSpy('getPermissions')
          .and.returnValue(Observable.of({find: false, change: true}));
      });

      it('should not make the requests to get template styles when find permission is false', () => {
        payloadDataServiceMock.payloadData = Observable.of({event: 'editLabFormats', payload: {}});
        component.ngOnInit();
        expect(editorServiceMock.getTemplatesFromClassAndStyle).not.toHaveBeenCalled();
      });

      it('should not make the requests to get lab formats when find permission is false', () => {
        payloadDataServiceMock.payloadData = Observable.of({event: 'editLabFormats', payload: {}});
        component.ngOnInit();
        expect(editorServiceMock.getLabFormat).not.toHaveBeenCalled();
      });

      it('should show a warning toast when find permission is false', () => {
        payloadDataServiceMock.payloadData = Observable.of({event: 'editLabFormats', payload: {}});
        component.ngOnInit();
        expect(toasterServiceMock.warning).toHaveBeenCalledWith('You do not have permission to view this page.');
      });
    });

  });

  describe('On Save Pressed', () => {

    beforeEach(() => {
      component.permissions = {find: true, change: true};
      component.selectedLabFormat = {code: 'code', lab: 'lab', key_num: 'key_num', meta: {eTag: ''}};
    });

    it('should save a Lab Formats template on save when event is \'editLabFormats\'', () => {
      component.onSavePressed();

      expect(editorServiceMock.saveLabFormat).toHaveBeenCalled();
      expect(toasterServiceMock.success).toHaveBeenCalledWith('Saved...');
    });

    it('should not try and save if the selectedLabFormat is falsey', () => {
      component.selectedLabFormat = null;

      component.onSavePressed();

      expect(editorServiceMock.saveLabFormat).not.toHaveBeenCalled();
    });


    it('should update the lab format meta data', () => {
      component.onSavePressed();

      expect(component.selectedLabFormat.meta.eTag).toEqual(NEW_ETAG);
    });

    describe('with restricted permissions', () => {


      it('should not make the requests to get template styles when find permission is false', () => {
        component.permissions = {find: true, change: false};
        component.onSavePressed();
        expect(editorServiceMock.saveLabFormat).not.toHaveBeenCalled();
        expect(toasterServiceMock.success).not.toHaveBeenCalled();
      });
    });

    describe('on save error', () => {

      it('should show a toast message with an error', () => {
        editorServiceMock.saveLabFormat = createSpy('saveLabFormat').and.returnValue(Observable.throw(THROWN_ERROR));

        try {
          component.onSavePressed();
          fail('Should throw and error');
        } catch (error) {
          expect(error).toEqual(THROWN_ERROR);
        }
      });

    });

    describe('on saving before replacing items', () => {

      beforeEach(() => {
        editorServiceMock.saveLabFormat = createSpy('saveLabFormat').and.returnValue(Observable.throw(THROWN_ERROR));
        component.editor.refreshEditorContent = createSpy('refreshEditorContent').and.returnValue('ITEM');
        component.onSavePressed();
      });

      it('should show a toast message with an warning saying you must replace item placeholders', () => {
        expect(toasterServiceMock.warning).toHaveBeenCalledWith('You must replace \'ITEM\' placeholders before saving.');
      });

    });
  });

  describe('On Items Pressed', () => {

    it('should populate items when search on items dialog is pressed', () => {
      const items = [
        {code: 'na', name: 'SODIUM', lab: 'INV', key_num: '1'},
        {code: 'k', name: 'POTASSIUM', lab: 'INV', key_num: '1'},
        {code: 'zn', name: 'ZINC', lab: 'INV', key_num: '1'}
      ];
      editorServiceMock.getLabItems = createSpy('getLabItems').and.returnValue(Observable.of(items));

      component.onItemsSearch({code: '', name: '', lab: '', keyNum: ''});

      expect(editorServiceMock.getLabItems).toHaveBeenCalled();
      expect(component.items).toEqual(items);
    });

    it('should handle failure to get items', () => {
      editorServiceMock.getLabItems = createSpy('getLabItems').and.returnValue(Observable.throw(THROWN_ERROR));

      try {
        component.onItemsSearch({code: '', name: '', lab: '', keyNum: ''});
        fail('Should throw an error');
      } catch (error) {
        expect(error).toEqual(THROWN_ERROR);
      }
    });
  });


  describe('On Template Selected', () => {

    it('should set the selected template code', () => {
      component.onTemplateSelected('bob');

      expect(component.selectedTemplateCode).toEqual('bob');
    });
  });

  describe('On Template Style Selected', () => {

    describe('style is different', () => {

      beforeEach(() => {
        component.onTemplateStyleSelected({code: STYLE_CODE});
      });

      it('should set the selected template style', () => {
        expect(component.selectedTemplateStyle.code).toEqual(STYLE_CODE);
      });

      it('should make a call to retrieve templates of the selected style', () => {
        expect(editorServiceMock.getTemplatesFromClassAndStyle).toHaveBeenCalledWith('formats', STYLE_CODE);
      });
    });

    describe('style is the same as existing style', () => {

      beforeEach(() => {
        component.selectedTemplateStyle = STYLE_CODE;
        component.onTemplateStyleSelected(STYLE_CODE);
      });

      it('should not call the api to retrieve templates', () => {
        expect(editorServiceMock.getTemplatesFromClassAndStyle).not.toHaveBeenCalled();
      });
    });

  });

  describe('On Load In Editor Pressed', () => {

    it('should make a call to the api to get the template if the template code is set', () => {
      component.selectedTemplateCode = TEMPLATE_CODE;
      component.onLoadInEditorPressed();

      expect(editorServiceMock.getCommonTemplate).toHaveBeenCalledWith(TEMPLATE_CODE);
    });

    it('should set the editor content to the body of the template', fakeAsync(() => {
      component.selectedTemplateCode = TEMPLATE_CODE;
      component.onLoadInEditorPressed();

      tick();
      expect(component.editorContent).toEqual(TEMPLATE_BODY);
    }));

    it('should not call the api to get the template if template code is not set', () => {
      component.selectedTemplateCode = null;
      component.onLoadInEditorPressed();

      expect(editorServiceMock.getCommonTemplate).not.toHaveBeenCalled();
    });


    it('sets generateDisabled to false', fakeAsync(() => {
      component.selectedTemplateCode = TEMPLATE_CODE;
      component.onLoadInEditorPressed();
      tick();
      expect(component.generateDisabled).toBeFalsy();
    }));
  });


  describe('On Use Template Pressed', () => {

    it('should call the API to generate format from items if items and template set', () => {
      component.selectedTemplateCode = TEMPLATE_CODE;
      component.editorContent = EDITOR_CONTENT;
      component.generateDisabled = false;

      component.onUseTemplatePressed('items');
      expect(editorServiceMock.generateFormatFromItems).toHaveBeenCalledWith('items', EDITOR_CONTENT, TEMPLATE_CODE);
    });

    it('should not call the API to generate format from items if items isn\'t set', () => {
      component.selectedTemplateCode = TEMPLATE_CODE;
      component.editorContent = EDITOR_CONTENT;
      component.generateDisabled = false;

      component.onUseTemplatePressed(null);
      expect(editorServiceMock.generateFormatFromItems).not.toHaveBeenCalled();
    });

    it('sets generateDisabled to true', fakeAsync(() => {
      component.selectedTemplateCode = TEMPLATE_CODE;
      component.editorContent = EDITOR_CONTENT;
      component.generateDisabled = false;

      component.onUseTemplatePressed('items');
      tick();
      expect(component.generateDisabled).toBeTruthy();
    }));

  });


});
