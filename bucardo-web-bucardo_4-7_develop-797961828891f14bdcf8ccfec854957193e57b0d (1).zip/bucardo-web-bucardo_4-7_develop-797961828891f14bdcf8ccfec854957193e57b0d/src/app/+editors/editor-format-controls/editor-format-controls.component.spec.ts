import {EditorFormatControlsComponent} from './editor-format-controls.component';
import {fakeAsync, tick} from '@angular/core/testing';
import {SimpleChange} from '@angular/core';

describe('EditorFormatControlsComponent', () => {

  const SELECTED_STYLE = 'SELECTED_STYLE';
  const NO_ITEMS_STYLE = 'NO_ITEMS_STYLE';
  const FORMAT_STYLES = [{code: SELECTED_STYLE, items: 'true'}, {code: NO_ITEMS_STYLE, items: 'false'}];

  let component: EditorFormatControlsComponent;

  beforeEach(() => {
    component = new EditorFormatControlsComponent();
  });

  it('should create component', () => {
    expect(component).toBeTruthy();
  });

  describe('OnChanges', () => {

    const NO_CHANGES = {};
    const VALID_LAB_FORMAT = {
      'clazz': 'A',
      meta: {
        lastUpdated: '2017-01-01T00:00:00Z',
        opr: 'bob'
      }
    };

    const labFormatClassA = Object.assign({}, VALID_LAB_FORMAT);
    const labFormatClassB = Object.assign({}, VALID_LAB_FORMAT, {'clazz': 'B'});
    const labFormatClassC = Object.assign({}, VALID_LAB_FORMAT, {'clazz': 'C'});
    const labFormatNoClass = Object.assign({}, VALID_LAB_FORMAT, {'clazz': ''});

    describe('Valid Changes', () => {


      it('should assign all the values to labFormat', () => {
        component.ngOnChanges(getChanges('labFormatInput', labFormatClassA));

        expect(component.labFormat.clazz).toEqual(VALID_LAB_FORMAT.clazz);
        expect(component.labFormat.meta.lastUpdated).toEqual(VALID_LAB_FORMAT.meta.lastUpdated);
      });

      describe('lastModified', () => {

        it('should set last modified if meta->lastUpdated is populated', () => {
          component.ngOnChanges(getChanges('labFormatInput', labFormatClassA));

          expect(component.lastModified).toEqual('01/01/2017 12:00:00 AM');
        });

        it('should NOT set last modified if meta is null', () => {
          const noMetaLabFormat = Object.assign({}, VALID_LAB_FORMAT, {meta: null});
          component.ngOnChanges(getChanges('labFormatInput', noMetaLabFormat));

          expect(component.lastModified).toBeNull();
        });

        it('should NOT set last modified if meta->lastUpdated is not populated', () => {
          const noMetaLabFormat = Object.assign({}, VALID_LAB_FORMAT, {meta: {lastUpdated: null, opr: 'bob'}});
          component.ngOnChanges(getChanges('labFormatInput', noMetaLabFormat));

          expect(component.lastModified).toBeNull();
        });

      });

      describe('Show Items Logic', () => {
        beforeEach(() => {
          component.formatStyles = FORMAT_STYLES;
        });

        it('should show items if style allows it', () => {
          component.selectedTemplateStyleCode = SELECTED_STYLE;
          component.ngOnChanges(getChanges('selectedTemplateStyleCode', SELECTED_STYLE));
          expect(component.showItemsList).toBeTruthy();
        });

        it('should not show items if style allows it', () => {
          component.selectedTemplateStyleCode = NO_ITEMS_STYLE;
          component.ngOnChanges(getChanges('selectedTemplateStyleCode', NO_ITEMS_STYLE));
          expect(component.showItemsList).toBeFalsy();
        });
      });

      describe('daysback', () => {

        it('should show daysback if class is A', () => {
          component.ngOnChanges(getChanges('labFormatInput', labFormatClassA));
          expect(component.showDaysBack).toBeTruthy();
        });

        it('should show daysback if class is B', () => {
          component.ngOnChanges(getChanges('labFormatInput', labFormatClassB));
          expect(component.showDaysBack).toBeTruthy();
        });

        it('should show daysback if class is C', () => {
          component.ngOnChanges(getChanges('labFormatInput', labFormatClassC));
          expect(component.showDaysBack).toBeTruthy();
        });

        it('should not show daysback if class is blank', () => {
          component.ngOnChanges(getChanges('labFormatInput', labFormatNoClass));
          expect(component.showDaysBack).toBeFalsy();
        });

      });

      describe('show count', () => {

        it('should show count if class is A', () => {
          component.ngOnChanges(getChanges('labFormatInput', labFormatClassA));
          expect(component.showCount).toBeTruthy();
        });

        it('should not show count if class is not A', () => {
          component.ngOnChanges(getChanges('labFormatInput', labFormatClassB));
          expect(component.showCount).toBeFalsy();
        });
      });

      describe('showPanelSearchAndSingleComment', () => {

        it('should show showPanelSearchAndSingleComment if class is C', () => {
          component.ngOnChanges(getChanges('labFormatInput', labFormatClassC));
          expect(component.showPanelSearchAndSingleComment).toBeTruthy();
        });

        it('should not show showPanelSearchAndSingleComment if class is not C', () => {
          component.ngOnChanges(getChanges('labFormatInput', labFormatClassB));
          expect(component.showPanelSearchAndSingleComment).toBeFalsy();
        });
      });
    });

    describe('Invalid changes', () => {

      it('should not change labFormat if labFormatInput is not in changes', () => {
        component.ngOnChanges(NO_CHANGES);
        expect(component.labFormat).toEqual({});
      });

      it('should not change labFormat if new labFormat value is null', () => {
        component.ngOnChanges(getChanges('labFormatInput', null));
        expect(component.labFormat).toEqual({});
      });
    });

  });

  function getChanges(field, newValue) {
    const result = {};
    result[field] = new SimpleChange(null, newValue, true);
    return result;
  }

  describe('onTemplateClassSelected', () => {

    let emitted = false;

    beforeEach(() => {
      emitted = false;
      component.formatStyles = FORMAT_STYLES;
      component.templateStyleSelected.subscribe(x => {
        emitted = true;

        expect(x.code).toEqual(SELECTED_STYLE);
      });
    });

    it('should emit selected template style', fakeAsync(() => {
      component.selectedTemplateStyleCode = SELECTED_STYLE;
      component.onTemplateStyleSelected();
      tick();
      expect(emitted).toBe(true);
    }));

    it('should not emit id if there is no selected template style', fakeAsync(() => {
      component.selectedTemplateStyleCode = null;
      component.onTemplateStyleSelected();
      tick();
      expect(emitted).toBe(false);
    }));
  });

  describe('onTemplateSelected', () => {

    const SELECTED_TEMPLATE = 'SELECTED_STYLE';
    let emitted = false;

    beforeEach(() => {
      emitted = false;
      component.templateSelected.subscribe(x => {
        emitted = true;
        expect(x).toEqual(SELECTED_TEMPLATE);
      });
    });

    it('should emit Id of selected template style', fakeAsync(() => {
      component.selectedTemplateCode = SELECTED_TEMPLATE;
      component.onTemplateSelected();
      tick();
      expect(emitted).toBe(true);
    }));

    it('should not emit id if there is no selected template style', fakeAsync(() => {
      component.selectedTemplateCode = null;
      component.onTemplateSelected();
      tick();
      expect(emitted).toBe(false);
    }));
  });


  describe('onSubmit', () => {

    const FORM_VALUE = 'FORM_VALUE';
    const VALID_FORM = {valid: true, value: FORM_VALUE};
    const INVALID_FORM = {valid: false, value: FORM_VALUE};
    let emitted = false;

    beforeEach(() => {
      emitted = false;
      component.savePressed.subscribe(x => {
        emitted = true;
        expect(x).toEqual(FORM_VALUE);
      });
    });

    it('should emit event with form value if form is valid', fakeAsync(() => {
      component.onSubmit(VALID_FORM);
      tick();
      expect(emitted).toBe(true);
    }));

    it('should not emit event if form is falsey', fakeAsync(() => {
      component.onSubmit(null);
      tick();
      expect(emitted).toBe(false);
    }));

    it('should not emit event if form is invalid', fakeAsync(() => {
      component.onSubmit(INVALID_FORM);
      tick();
      expect(emitted).toBe(false);
    }));

  });


});
