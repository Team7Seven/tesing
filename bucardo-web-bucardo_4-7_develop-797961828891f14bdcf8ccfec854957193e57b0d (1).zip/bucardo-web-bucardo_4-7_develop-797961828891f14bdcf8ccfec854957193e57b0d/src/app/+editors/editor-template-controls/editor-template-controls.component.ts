import {
  Component, Input, Output, EventEmitter, OnChanges, SimpleChanges, ElementRef, ViewChild,
  ChangeDetectorRef
} from '@angular/core';
import * as moment from 'moment';

@Component({
  selector: 'editor-template-controls',
  templateUrl: 'editor-template-controls.component.html',
  styleUrls: ['editor-template-controls.component.scss']
})

export class EditorTemplateControlsComponent implements OnChanges {

  @Input() formatsTemplates: any[];
  @Input() template: any = {};
  @Input() templateStyles = [];
  @Input() templateClasses = [];
  @Input() isNew: boolean;
  @Input() permissions: any = {};
  @Output() templateSelected = new EventEmitter();
  @Output() templateClassSelected = new EventEmitter();
  @Output() savePressed = new EventEmitter();
  @Output() newPressed = new EventEmitter();
  @ViewChild('codeInput') codeElement: ElementRef;

  selectedTemplateCode: any = '';
  lastModified = null;
  lastModifiedUser = null;
  savePermission: boolean;

  constructor(private changeDetector: ChangeDetectorRef) {}

  ngOnChanges(changes: SimpleChanges): void {
    if ('template' in changes && changes['template'].currentValue) {
      this.setSelectedTemplate();
      this.setLastModified();
    }

    if ('isNew' in changes) {
      this.setLastModified();
      this.checkForSavePermission(changes['isNew'].currentValue, this.permissions);
      this.forceVariableChange(this.template, 'style'); // Needed for IE
    }

    if ('permissions' in changes) {
      this.checkForSavePermission(this.isNew, changes['permissions'].currentValue);
    }

    if ('templateClasses' in changes) {
      this.forceVariableChange(this.template, 'class');  // Needed for IE
    }
  }

  private forceVariableChange(object: any, variable: string) {
    const temp = object[variable];
    object[variable] = null;
    this.changeDetector.detectChanges();
    object[variable] = temp;
  }

  checkForSavePermission(isNew: Boolean, permissions) {
    if (isNew === true) {
      this.savePermission = permissions.add;
    } else {
      this.savePermission = permissions.change;
    }
  }

  private setSelectedTemplate() {
    this.selectedTemplateCode = this.template.code;
  }

  private setLastModified() {
    if (this.isNew) {
      this.lastModified = null;
      this.lastModifiedUser = null;
    } else {
      this.lastModified = this.getLastModifiedFromMetaData(this.template);
      this.lastModifiedUser = this.getLastModifiedUserFromMetaData(this.template);
    }
  }

  private getLastModifiedFromMetaData(data: any) {
    if (this.hasValidModifiedDate(data)) {
      return moment(data.meta.lastUpdated).format('L LTS');
    } else {
      return null;
    }
  }

  private getLastModifiedUserFromMetaData(data: any) {
    if (this.hasValidModifiedUser(data)) {
      return data.meta.opr;
    } else {
      return null;
    }
  }

  private hasValidModifiedDate(data) {
    return data && data.meta && data.meta.lastUpdated && data.meta.lastUpdated.trim();
  }

  private hasValidModifiedUser(data) {
    return data && data.meta && data.meta.opr && data.meta.opr.trim();
  }

  onTemplateSelected() {
    if (this.selectedTemplateCode) {
      this.templateSelected.emit(this.selectedTemplateCode);
    }
  }

  onTemplateClassSelected() {
    if (this.template['class']) {
      this.templateClassSelected.emit(this.template['class']);
    }
  }

  onNewPressed() {
    this.newPressed.emit();
    this.focusCodeField();
  }

  private focusCodeField() {
    // this.form.get('codeInput').enable(); // We need to enable it otherwise we can't focus
    setTimeout(() => { // IE Nonsense
      this.codeElement.nativeElement.focus();
    }, 10);
  }

  onSubmit() {
    this.savePressed.emit(this.template);
  }

}
