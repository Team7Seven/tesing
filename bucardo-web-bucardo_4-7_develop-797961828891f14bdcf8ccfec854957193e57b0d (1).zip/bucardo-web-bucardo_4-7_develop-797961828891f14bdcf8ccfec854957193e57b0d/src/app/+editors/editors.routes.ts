import {Routes} from '@angular/router';
import {BodyFormatEditorComponent} from './body-format-editor.component';
import {TemplateEditorComponent} from './template-editor.component';
import {PageFormatEditorComponent} from './page-format-editor/page-format-editor.component';
import {PanelGroupFormatEditorComponent} from './panel-group-format-editor/panel-group-format-editor.component';

export const EditorRoutes: Routes = [
  {path: 'templates', component: TemplateEditorComponent},
  {path: 'body-formats', component: BodyFormatEditorComponent},
  {path: 'page-formats', component: PageFormatEditorComponent},
  {path: 'panel-group-formats', component: PanelGroupFormatEditorComponent}
];
