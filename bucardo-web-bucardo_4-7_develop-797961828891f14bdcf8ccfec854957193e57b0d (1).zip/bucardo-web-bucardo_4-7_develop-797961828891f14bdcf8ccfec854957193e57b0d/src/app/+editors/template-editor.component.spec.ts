import {Observable} from 'rxjs/Observable';
import {fakeAsync, tick} from '@angular/core/testing';
import {EditorService} from './shared/editor.service';
import {PayloadDataService} from '../shared/services/payload-data/payload-data.service';
import {NavbarDataService} from '../shared/components/navigation/navbar/navbar-data-service';
import {TemplateEditorComponent} from './template-editor.component';
import {ToastrService} from 'ngx-toastr';
import createSpy = jasmine.createSpy;

describe('ReportTemplateEditorComponent', () => {

  const TEMPLATE_ID = 'TEMPLATE_ID';
  const TEMPLATE_CLASS = 'Class123';

  let component: TemplateEditorComponent;
  let navbarServiceMock: NavbarDataServiceMock;
  let toasterServiceMock: ToastrServiceMock;
  let editorServiceMock: EditorServiceMock;
  let payloadDataServiceMock: PayloadDataServiceMock;
  let loginUtilsMock: LoginUtilsMock;

  class ToastrServiceMock {
    warning = createSpy('toastWarning');
    success = createSpy('toastSuccess');
  }

  class EditorServiceMock {
    getListOfCommonTemplates = createSpy('getListOfCommonTemplates').and.returnValue(Observable.of([]));
    getCommonTemplate = createSpy('getCommonTemplate').and.returnValue(Observable.of([]));
    getLabItems = createSpy('getLabItems').and.returnValue(Observable.of([]));
    saveCommonTemplate = createSpy('saveCommonTemplate').and.returnValue(Observable.of([]));
    getTemplateClasses = createSpy('getTemplateClasses').and.returnValue(Observable.of([]));
    getTemplateStyles = createSpy('getTemplateStyles').and.returnValue(Observable.of([]));
    getTemplatePermissions = createSpy('getTemplatePermissions').and.returnValue(Observable.of({
      find: true,
      add: true,
      change: true
    }));
  }

  class PayloadDataServiceMock {
    payloadData: Observable<any> = Observable.of({event: '', payload: {}});
  }

  class NavbarDataServiceMock {
    setPage = createSpy('setPage');
  }

  class EditorComponentMock {
    refreshEditorContent = createSpy('refreshEditorContent').and.returnValue('STUFF');
  }

  class LoginUtilsMock {
    isUserLoggedIn = createSpy('isUserLoggedIn').and.returnValue(true);
  }

  beforeEach(() => {
    toasterServiceMock = new ToastrServiceMock();
    editorServiceMock = new EditorServiceMock();
    payloadDataServiceMock = new PayloadDataServiceMock();
    navbarServiceMock = new NavbarDataServiceMock();
    loginUtilsMock = new LoginUtilsMock();

    component = new TemplateEditorComponent(
      <any>toasterServiceMock,
      <any>editorServiceMock,
      <any>payloadDataServiceMock,
      <any>navbarServiceMock,
      <any> loginUtilsMock);

    component.editor = <any>new EditorComponentMock();

    payloadDataServiceMock.payloadData = Observable.of({event: 'editCommonTemplate', payload: {}});

    spyOn(console, 'error');
  });

  it('should subscribe to payload data on initialisation', fakeAsync(() => {
    spyOn(payloadDataServiceMock.payloadData, 'subscribe').and.callThrough();
    component.ngOnInit();
    tick();
    expect(payloadDataServiceMock.payloadData.subscribe).toHaveBeenCalled();
  }));

  it('should get a Common template when event \'editCommonTemplate\' is received', () => {
    component.ngOnInit();

    expect(editorServiceMock.getCommonTemplate).toHaveBeenCalled();
  });

  it('should get a list of template classes when event \'editCommonTemplate\' is received', () => {
    component.ngOnInit();

    expect(editorServiceMock.getTemplateClasses).toHaveBeenCalled();
  });

  it('should throw exception on failure to get a Common template', () => {
    editorServiceMock.getCommonTemplate = createSpy('getCommonTemplate').and.returnValue(Observable.throw('An Error'));

    try {
      component.ngOnInit();
      fail('Should throw an error');
    } catch (error) {
      expect(error).toEqual('An Error');
    }

  });

  it('should get a list of common templates on init when event is \'editCommonTemplate\'', () => {
    component.ngOnInit();

    expect(editorServiceMock.getListOfCommonTemplates).toHaveBeenCalled();
  });

  it('should handle failure to get common templates on init', () => {
    editorServiceMock.getListOfCommonTemplates = createSpy('getListOfCommonTemplates')
      .and.returnValue(Observable.throw('An Error'));

    try {
      component.ngOnInit();
      fail('Should throw an error');
    } catch (error) {
      expect(error).toEqual('An Error');
    }
  });

  it('should get a list of common templates on init', () => {
    component.ngOnInit();
    expect(editorServiceMock.getListOfCommonTemplates).toHaveBeenCalled();
  });

  it('should save a Common template on save when event is \'editCommonTemplate\'', () => {
    component.permissions = {add: true, change: true};
    component.onSavePressed(TEMPLATE_ID);

    expect(editorServiceMock.saveCommonTemplate).toHaveBeenCalled();
    expect(component.editor.refreshEditorContent).toHaveBeenCalled();
    expect(toasterServiceMock.success).toHaveBeenCalledWith('Saved...');
  });

  it('should pass on exception when saving a Common template on save when event is \'editCommonTemplate\'', () => {
    component.permissions.add = true;
    editorServiceMock.saveCommonTemplate = createSpy('saveCommonTemplate').and.returnValue(Observable.throw('An Error'));

    try {
      component.onSavePressed(TEMPLATE_ID);
      fail('should have thrown an error');
    } catch (error) {
      expect(error).toEqual('An Error');
    }

  });

  it('should get a common template on apply template pressed', () => {
    editorServiceMock.getCommonTemplate = createSpy('getCommonTemplate')
      .and.returnValue(Observable.of([{html: 'Test Common Template'}]));

    component.onTemplateSelected('Test Template Id');

    expect(editorServiceMock.getCommonTemplate).toHaveBeenCalled();
  });

  it('should bubble up failure to get a common template on apply template pressed', () => {
    editorServiceMock.getCommonTemplate = createSpy('getCommonTemplate').and.returnValue(Observable.throw('An Error'));

    try {
      component.onTemplateSelected('Test Template Id');
      fail('Should throw and error');
    } catch (error) {
      expect(error).toEqual('An Error');
    }
  });

  it('should populate items when search on items dialog is pressed', () => {
    const items = [
      {code: 'na', name: 'SODIUM', lab: 'INV', key_num: '1'},
      {code: 'k', name: 'POTASSIUM', lab: 'INV', key_num: '1'},
      {code: 'zn', name: 'ZINC', lab: 'INV', key_num: '1'}
    ];
    editorServiceMock.getLabItems = createSpy('getLabItems').and.returnValue(Observable.of(items));

    component.onItemsSearch({code: '', name: '', lab: '', keyNum: ''});

    expect(editorServiceMock.getLabItems).toHaveBeenCalled();
    expect(component.items).toEqual(items);
  });

  it('should handle failure to get lab items', () => {
    editorServiceMock.getLabItems = createSpy('getLabItems').and.returnValue(Observable.throw('An Error'));

    try {
      component.onItemsSearch({code: '', name: '', lab: '', keyNum: ''});
      fail('Should throw and error');
    } catch (error) {
      expect(error).toEqual('An Error');
    }
  });

  it('should get a list of template styles depending on the template class that was selected', () => {
    payloadDataServiceMock.payloadData = Observable.of({event: 'editCommonTemplate', payload: {code: TEMPLATE_ID}});
    editorServiceMock.getCommonTemplate = createSpy('getCommonTemplate')
      .and.returnValue(Observable.of({html: 'Test Common Template', 'class': TEMPLATE_CLASS}));

    component.ngOnInit();

    expect(editorServiceMock.getTemplateStyles).toHaveBeenCalledWith(TEMPLATE_CLASS);
  });

  describe('with find permissions disabled', () => {

    beforeEach(() => {
      editorServiceMock.getTemplatePermissions = createSpy('getTemplatePermissions')
        .and.returnValue(Observable.of({find: false, change: true}));
    });

    it('should not make the requests to get template styles when find permission is false', () => {
      payloadDataServiceMock.payloadData = Observable.of({event: 'editCommonTemplate', payload: {}});
      component.ngOnInit();
      expect(editorServiceMock.getListOfCommonTemplates).not.toHaveBeenCalled();
    });

    it('should not make the requests to get lab formats when find permission is false', () => {
      payloadDataServiceMock.payloadData = Observable.of({event: 'editCommonTemplate', payload: {}});
      component.ngOnInit();
      expect(editorServiceMock.getTemplateClasses).not.toHaveBeenCalled();
    });

    it('should show a warning toast when find permission is false', () => {
      payloadDataServiceMock.payloadData = Observable.of({event: 'editCommonTemplate', payload: {}});
      component.ngOnInit();
      expect(toasterServiceMock.warning).toHaveBeenCalledWith('You do not have permission to view this page.');
    });
  });

  describe('checking permissions when saving', () => {
    it('allows save when brandnew is set to true and adding is enabled', () => {
      component.editingBrandNewTemplate = true;
      component.permissions = {add: true};

      component.onSavePressed(TEMPLATE_ID);

      expect(editorServiceMock.saveCommonTemplate).toHaveBeenCalled();
      expect(component.editor.refreshEditorContent).toHaveBeenCalled();
      expect(toasterServiceMock.success).toHaveBeenCalledWith('Saved...');
    });


    it('does not allow save when brandnew is set to true and adding is disabled', () => {
      component.editingBrandNewTemplate = true;
      component.permissions = {add: false};

      component.onSavePressed(TEMPLATE_ID);

      expect(editorServiceMock.saveCommonTemplate).not.toHaveBeenCalled();
      expect(component.editor.refreshEditorContent).not.toHaveBeenCalled();
      expect(toasterServiceMock.success).not.toHaveBeenCalled();
    });

    it('allows save when brandnew is set to false and changing is enabled', () => {
      component.editingBrandNewTemplate = false;
      component.permissions = {change: true};

      component.onSavePressed(TEMPLATE_ID);

      expect(editorServiceMock.saveCommonTemplate).toHaveBeenCalled();
      expect(component.editor.refreshEditorContent).toHaveBeenCalled();
      expect(toasterServiceMock.success).toHaveBeenCalledWith('Saved...');
    });


    it('allows save when brandnew is set to true and adding is enabled', () => {
      component.editingBrandNewTemplate = false;
      component.permissions = {change: false};

      component.onSavePressed(TEMPLATE_ID);

      expect(editorServiceMock.saveCommonTemplate).not.toHaveBeenCalled();
      expect(component.editor.refreshEditorContent).not.toHaveBeenCalled();
      expect(toasterServiceMock.success).not.toHaveBeenCalled();
    });

  });

});
