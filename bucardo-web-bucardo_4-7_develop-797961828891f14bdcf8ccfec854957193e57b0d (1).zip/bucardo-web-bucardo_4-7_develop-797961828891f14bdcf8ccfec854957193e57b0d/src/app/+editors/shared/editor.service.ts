import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {ConfigurationService} from '../../shared/services/configuration/configuration.service';
import {ItemsSearchCriteriaModel} from '../editor-items/items-search-criteria.model';
import {ApiClient} from '../../shared/services/api-client/api-client';
import * as _ from 'lodash';
import {DuplicateKeyError} from '../../shared/exceptions/duplicate-key.error';
import {getEtagFromMeta} from '../../shared/utils/etag-utils';
import {UserService} from '../../shared/services/user/user.service';

// no tests, as this code mostly should be implemented in lab api
@Injectable()
export class EditorService {

  private apiUrl;
  private currentUser;

  constructor(private apiClient: ApiClient,
              private config: ConfigurationService,
              private userService: UserService) {
    this.apiUrl = config.getConfig().labapi_url;
    userService.user.subscribe((user) => {
      if (user) {
        this.currentUser = user.code;
      }
    });
  }

  getLabFormat(code: string, lab: string, keyNum: string): Observable<any> {
    return this.apiClient.get(
      `${this.apiUrl}/PatRptFormat/${encodeURIComponent(code + '~' + lab + '~' + keyNum)}`);
  }

  getCommonTemplate(code: string): Observable<any> {
    return this.apiClient.get(`${this.apiUrl}/PatRptTemplate/${encodeURIComponent(code)}`);
  }

  getTemplateClasses(): Observable<any> {
    return this.apiClient.get(`${this.apiUrl}/PatRptTemplate/$classList`);
  }

  getTemplateStyles(clazz: string): Observable<any> {
    return this.apiClient.get(`${this.apiUrl}/PatRptTemplate/$styleList?class=${encodeURIComponent(clazz)}`);
  }

  getListOfLabFormats(): Observable<any> {
    return this.apiClient.get(`${this.apiUrl}/PatRptFormat?_summary=id`)
      .map((formats) => {
        const mappedResult = this.mapFormatResult(formats);
        return _.sortBy(mappedResult, 'name');
      });
  }

  getTemplatesFromClassAndStyle(clazz: string, style: string): Observable<any> {
    return this.apiClient
      .get(`${this.apiUrl}/PatRptTemplate?class=${encodeURIComponent(clazz)}&style=${encodeURIComponent(style)}&_summary=short`)
      .map(this.mapTemplateResult);
  }

  getLabItems(criteria: ItemsSearchCriteriaModel): Observable<any> {
    return this.apiClient.get(`${this.apiUrl}/Items`).map((items: any) => {
      const filteredItems = items.entry.filter((item) => {
        return item.resource.code.toLowerCase().startsWith(criteria.code.toLowerCase()) &&
          item.resource.name.toLowerCase().startsWith(criteria.name.toLowerCase()) &&
          item.resource.lab.toLowerCase().startsWith(criteria.lab.toLowerCase()) &&
          item.resource.key_num.startsWith(criteria.keyNum);
      });

      return filteredItems.map((item) => {
        return {
          code: item.resource.code,
          name: item.resource.name,
          lab: item.resource.lab,
          keyNum: item.resource.key_num
        };
      });

    });
  }

  getListOfCommonTemplates(): Observable<any[]> {
    return this.apiClient.get(`${this.apiUrl}/PatRptTemplate?_summary=short`).map(this.mapTemplateResult);
  }

  saveLabFormat(labFormat): Observable<any> {
    return this.apiClient
      .put(`${this.apiUrl}/PatRptFormat/${encodeURIComponent(labFormat.code + '~' + labFormat.lab + '~' + labFormat.key_num)}`,
        labFormat, this.currentUser);
  }

  saveCommonTemplate(template: any, isNew: boolean): Observable<any> {
    if (isNew) {
      return this.apiClient.post(`${this.apiUrl}/PatRptTemplate`, template)
        .catch((e) => this.handleDuplicateKeyError(e, 'Template'));
    } else {
      return this.apiClient.put(`${this.apiUrl}/PatRptTemplate/${encodeURIComponent(template.code)}`, template, this.currentUser);
    }
  }

  handleDuplicateKeyError(e, type): Observable<any> {
    if (e instanceof DuplicateKeyError) {
      const errorReport = {
        message: `${type} code already exists`,
        stack: ''
      };

      throw errorReport;
    } else {
      throw e;
    }
  }

  generateFormatFromItems(items: string, body: string, templateCode: string): Observable<any> {
    return this.apiClient.post(`${this.apiUrl}/PatRptFormat/$templateToFormat`, {
      body: body,
      template: templateCode,
      items: items,
      use_script: ''
    });
  }

  private mapTemplateResult(templates: any) {
    return templates.entry.map(template => {
      return {id: template.resource.code, name: template.resource.name};
    });
  }

  private mapFormatResult(formats: any) {
    return formats.entry.map(format => {
      const result = _.clone(format.resource);
      result.name = `${result.code}, ${result.name}`;
      return result;
    });
  }

  getTemplatePermissions() {
    return this.apiClient.get(`${this.apiUrl}/PatRptTemplate/$perms`);
  }

  getFormatPermissions() {
    return this.apiClient.get(`${this.apiUrl}/PatRptFormat/$perms`);
  }

}
