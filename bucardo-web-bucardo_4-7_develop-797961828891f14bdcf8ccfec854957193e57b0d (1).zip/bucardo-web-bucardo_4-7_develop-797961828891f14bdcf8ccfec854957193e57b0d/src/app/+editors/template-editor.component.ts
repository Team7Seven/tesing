import {Component, OnDestroy, OnInit, ViewChild, HostListener} from '@angular/core';
import {EditorService} from './shared/editor.service';
import {PayloadDataService} from '../shared/services/payload-data/payload-data.service';
import {Subscription} from 'rxjs/Subscription';
import {ItemsSearchCriteriaModel} from './editor-items/items-search-criteria.model';
import {NavbarDataService} from '../shared/components/navigation/navbar/navbar-data-service';
import {HtmlEditorComponent} from '../shared/components/html-editor/html-editor.component';
import {LoginUtilsService} from '../shared/utils/login-utils.service';
import {unsub} from '../shared/utils/subsription-utils';
import {ToastrService} from 'ngx-toastr';


@Component({
  selector: 'template-editor',
  styleUrls: ['template-editor.component.scss'],
  templateUrl: 'template-editor.component.html',
  providers: [EditorService]
})
export class TemplateEditorComponent implements OnInit, OnDestroy {

  editorContent: string;
  selectedTemplate: any = {};
  templateStyles = [];
  templateClasses = [];
  editingBrandNewTemplate = true;
  formatsTemplates: any[];
  permissions: any = {};

  private getTemplateSub: Subscription;
  private payloadDataServiceSub: Subscription;
  private getTemplateListSub: Subscription;

  items: any[];

  @ViewChild('itemsDialog') itemsDialog;
  @ViewChild('htmlEditor') editor: HtmlEditorComponent;

  constructor(private toaster: ToastrService,
              private editorService: EditorService,
              private payloadDataService: PayloadDataService,
              private navbarService: NavbarDataService,
              private loginUtilsService: LoginUtilsService) {
    navbarService.setPage('HTML Template Editor');
  }

  ngOnDestroy() {
    if (this.payloadDataServiceSub) {
      this.payloadDataServiceSub.unsubscribe();
    }
  }

  ngOnInit() {
    this.subscribeToPayloadService();
  }

  private subscribeToPayloadService() {
    this.payloadDataServiceSub = this.payloadDataService.payloadData.subscribe((eventData) => {
      if (eventData) {
        if (this.isAnEventToStartEditor(eventData)) {
          this.getTemplatesIfTheUserHasPermissions(eventData);
        }
      }
    });

    if (this.loginUtilsService.isUserLoggedIn()) {
      this.getTemplatesIfTheUserHasPermissions();
    }
  }

  private getTemplatesIfTheUserHasPermissions(eventData = null) {
    this.editorService.getTemplatePermissions().subscribe(
      (permissions) => {
        this.permissions = permissions;
        if (this.permissions.find) {
          this.getListOfTemplateClasses();
          this.refreshListOfCommonTemplates();
          if (this.shouldASpecificTemplateBeLoaded(eventData)) {
            this.getCommonTemplate(eventData.payload.code);
          }
        } else {
          this.toaster.warning('You do not have permission to view this page.');
        }
      }
    );
  }

  private shouldASpecificTemplateBeLoaded(eventData) {
    return eventData && eventData.event === 'editCommonTemplate';
  }

  private isAnEventToStartEditor(eventData: any) {
    return (eventData.event === 'menu' && eventData.payload.module === 'editor/template') ||
      eventData.event === 'editCommonTemplate' || // edit a specific template
      eventData.event === 'browser'; // browser means we just got a token and can now call getTemplatePermissions
  }

  private getListOfTemplateClasses() {
    this.editorService.getTemplateClasses().subscribe(
      (classes) => this.templateClasses = classes,
      (error) => {
        this.clearPage();
        throw error;
      }
    );
  }

  @HostListener('window:focus')
  private refreshListOfCommonTemplates() {
    this.getTemplateListSub = this.editorService.getListOfCommonTemplates().subscribe(
      (templates) => this.formatsTemplates = templates,
      (error) => {
        this.clearPage();
        throw error;
      }
    );
  }

  private clearPage() {
    unsub(this.getTemplateSub);
    unsub(this.getTemplateListSub);

    this.editingBrandNewTemplate = true;
    this.selectedTemplate = {
      code: '',
      name: '',
      'class': '',
      style: '',
      script: ''
    };


    setTimeout(() => {
      this.editorContent = '';
    });
  }

  private getCommonTemplate(templateCode: any) {
    this.getTemplateSub = this.editorService.getCommonTemplate(templateCode).subscribe(
      (template) => this.setSelectedTemplate(template),
      (error) => {
        this.clearPage();
        throw error;
      }
    );
  }

  private setSelectedTemplate(template) {
    this.editingBrandNewTemplate = false;
    this.selectedTemplate = template;

    if (this.selectedTemplate && this.selectedTemplate['class']) {
      this.getTemplateStylesFromClass(this.selectedTemplate['class']);
    }

    this.editorContent = template.body;
  }

  private getTemplateStylesFromClass(clazz: string) {
    this.editorService.getTemplateStyles(clazz).subscribe(
      (styles) => {
        this.templateStyles = styles;
        if (styles.length && !this.selectedTemplate.style) {
          this.selectedTemplate.style = styles[0].code;
        }
      },
      (error) => {
        this.clearPage();
        throw error;
      }
    );
  }

  public onSavePressed(template) {
    if (
      (this.editingBrandNewTemplate && !this.permissions.add)
      || (!this.editingBrandNewTemplate && !this.permissions.change)) {
      this.toaster.warning('You do not have permission to update this resource.');
      return;
    }
    if (template) {
      this.editorContent = this.editor.refreshEditorContent();
      const templateWithEditorBody = Object.assign(template, {body: this.editorContent});

      this.editorService.saveCommonTemplate(templateWithEditorBody, this.editingBrandNewTemplate).subscribe(
        (savedTemplate) => {
          this.toaster.success('Saved...');
          this.editingBrandNewTemplate = false;
          if (savedTemplate) { // Update items return an empty string
            this.selectedTemplate = Object.assign({}, savedTemplate);
          } else { // refetch template to get updated timestamp
            this.getCommonTemplate((<any>templateWithEditorBody).code);
          }
          this.refreshListOfCommonTemplates();
        }
      );
    }
  }

  public onNewPressed() {
    if (!this.permissions.add) {
      this.toaster.warning('You do not have permission to add a template.');
      return;
    }

    this.clearPage();
  }

  public onTemplateSelected(templateCode: string) {
    if (this.selectedTemplate && this.selectedTemplate.code === templateCode) {
      return;
    }

    this.getCommonTemplate(templateCode);
  }

  public onTemplateClassSelected(clazz: string) {
    this.getTemplateStylesFromClass(clazz);
  }

  public onItemSelected(item: string) {
    this.editor.insertHtml(item);
  }

  public onItemsSearch(model: ItemsSearchCriteriaModel) {
    this.editorService.getLabItems(model).subscribe(
      (items) => {
        this.items = items;
      });
  }

}
