import {Component, Input} from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'editor-type-selector',
  template: `
                    <div class="form-group">
                      <select focusAtStart title="Select Editor"
                              [(ngModel)]="editorType"
                              (ngModelChange)="onEditorTypeSelected($event)"
                              class="form-control" data-style="btn-primary">
                        <option value="/editor/body-formats">Body Formats</option>
                        <option value="/editor/page-formats">Page Formats</option>
                        <option value="/editor/panel-group-formats">Panel Group Formats</option>
                        <option value="/editor/templates">Templates</option>
                      </select>
                    </div>
  `,
  styles: [`
    select, select option {
        font-weight: bold;
        font-size: 16px;
    }
  `]
})
export class EditorTypeSelectorComponent  {

  public editorType;

  constructor(private router: Router) {
    this.editorType = this.router.url;
  }

  onEditorTypeSelected(type) {
    this.router.navigate([type]);
  }

}
