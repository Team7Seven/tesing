import { Component, OnInit } from '@angular/core';
import {NavbarDataService} from '../../shared/components/navigation/navbar/navbar-data-service';

@Component({
  selector: 'panel-group-format-editor',
  template: `
      <div class="fullLength main-content" *ngIf="permissions.find">
          <div id="left-column" class="col-sm-3 fullLength">
              <div id="info-panel" class="fullLength">

                  <editor-type-selector></editor-type-selector>

              </div>

          </div>
          <div class="col-sm-9 fullLength">
              <html-editor #htmlEditor [(ngModel)]="editorContent"
                           [readOnly]="!(permissions.change || permissions.add)"></html-editor>
          </div>
      </div>
  `,
  styles: []
})
export class PanelGroupFormatEditorComponent implements OnInit {

  permissions: any = { find: true};
  editorContent: string;

  constructor(private navbarService: NavbarDataService) {
    navbarService.setPage('Panel Group Format Editor');
  }

  ngOnInit() {
  }

}
