import {Component, EventEmitter, Input, Output} from '@angular/core';
import {DocumentModel} from '../document.model';

@Component({
  selector: 'document-list',
  template: `
    <div class="doc-list">
      <div class="form-group">
        <h2>{{heading}}</h2>
        <ul [style.height.px]="height" role="listbox">
          <li *ngFor="let doc of documents" [ngClass]="{'selected': selectedDocument && doc.ri === selectedDocument.ri}"
              (click)="toggleSelection(doc)" role="option">{{doc.name}}
          </li>
        </ul>
      </div>
    </div>
  `,
  styles: [`

    ul {
      border: 1px solid lightgray;
      width: 100%;
      overflow-y: scroll;
      list-style-type: none;
      padding: 0 4px;
    }

    ul li {
      cursor: pointer;
      padding: 4px;
    }

    ul li.selected {
      border-radius: 3px;
      background: linear-gradient(#2A373E, #4E656D);
      color: #fff;
    }

    h2 {
      margin-top: 10px;
      margin-bottom: 10px;
      font-size: 19px;

    }

  `]
})
export class DocumentListComponent {

  @Input() documents: DocumentModel[] = [];
  @Input() selectedDocument: DocumentModel;
  @Input() heading = '';
  @Input() height = 150;

  @Output() documentChanged = new EventEmitter<DocumentModel>();

  toggleSelection(document: DocumentModel) {
    if (this.selectedDocument && this.selectedDocument.ri === document.ri) {
      this.selectedDocument = null;
    } else {
      this.selectedDocument = document;
    }

    this.documentChanged.emit(this.selectedDocument);
  }
}

