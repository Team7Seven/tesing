export interface DocumentModel {
  barcode: string;
  device: string;
  lab: string;
  mt: string;
  name: string;
  op: string;
  path: string;
  request: string;
  resourceType: string;
  ri: string;
  status: string;
  tiebreaker: string;
}
