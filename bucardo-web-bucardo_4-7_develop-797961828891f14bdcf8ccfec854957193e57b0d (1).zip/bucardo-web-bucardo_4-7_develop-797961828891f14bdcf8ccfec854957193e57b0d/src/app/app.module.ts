import {NgModule, APP_INITIALIZER, ErrorHandler, Injector} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {RouterModule} from '@angular/router';
import {HttpModule, Http} from '@angular/http';
import {FormsModule} from '@angular/forms';
import {ConfigurationService} from './shared/services/configuration/configuration.service';
import {AppComponent} from './app.component';
import {routes} from './app.routes';
import {HomeModule} from './+home/home.module';
import {SharedModule} from './shared/shared.module';
import {LoginModule} from './+login/login.module';
import {ApiClient} from './shared/services/api-client/api-client';
import {ToastrModule, ToastrService} from 'ngx-toastr';
import {ApiErrorHandler} from './shared/services/api-client/api-error-handler';
import {ErrorReporterService} from './shared/services/error-reporter/error-reporter.service';
import {HotkeyModule} from 'angular2-hotkeys';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

export function loadPreconfiguration(config: ConfigurationService, errorHandler: ErrorHandler) {
  return () => config.loadPreconfiguration(errorHandler, location.search.substr(1));
}

export function createApiClient(http: Http, errorHandler: ApiErrorHandler) {
  return new ApiClient(http, errorHandler);
}

@NgModule({
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    RouterModule.forRoot(routes),
    HomeModule,
    SharedModule.forRoot(),
    LoginModule,
    ToastrModule.forRoot(),
    HotkeyModule.forRoot(),
    BrowserAnimationsModule
  ],
  declarations: [AppComponent],
  bootstrap: [AppComponent],
  providers: [
    ConfigurationService,
    {
      provide: APP_INITIALIZER,
      useFactory: loadPreconfiguration,
      deps: [ConfigurationService, ErrorHandler],
      multi: true
    },
    {
      useFactory: createApiClient,
      provide: ApiClient,
      deps: [Http, ApiErrorHandler]
    },
    {
      provide: ErrorHandler,
      useClass: ErrorReporterService,
      deps: [ApiClient, Injector]
    }
  ]

})

export class AppModule {
}
